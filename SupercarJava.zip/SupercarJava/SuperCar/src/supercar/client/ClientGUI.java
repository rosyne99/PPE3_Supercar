package supercar.client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;
import java.util.regex.Pattern;
import java.awt.EventQueue;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import supercar.login.AdminAccount;
import supercar.login.Dashboard;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class ClientGUI {

	private JFrame frame;
	private JTextField NOM;
	private JTextField PRENOM;
	private JTextField LICENCE;
	private JTextField ADRESSE;
	private JTextField EMAIL;
	private JTextField TEL;
	private JTable table;
	private AdminAccount account = new AdminAccount();

	/**
	 * Launch the application.
	 */
	public static void main(String login) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/supercarjava", "root", "");
			Statement smt = cn.createStatement();

			String q = "Select * from client";

			ResultSet rs = smt.executeQuery(q);

			if (!rs.next()) {
				JOptionPane.showMessageDialog(null, "Record Not Found...");
			}
			cn.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientGUI window = new ClientGUI(login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ClientGUI(String login) {
		initialize(login);
		table_update();
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void table_update() {
		int c;
		try {
			Connection conn;
			PreparedStatement insert;
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/supercarjava", "root", "");
			insert = conn.prepareStatement("select * from client");
			ResultSet rs = insert.executeQuery();
			ResultSetMetaData Rss = (ResultSetMetaData) rs.getMetaData();
			c = Rss.getColumnCount();

			DefaultTableModel tab = (DefaultTableModel) table.getModel();

			tab.setRowCount(0);
			while (rs.next()) {

				Vector v2 = new Vector();

				for (int a = 1; a <= c; a++) {

					v2.add(rs.getString("ID_CLIENT"));
					v2.add(rs.getString("NOM"));
					v2.add(rs.getString("PRENOM"));
					v2.add(rs.getString("LICENCE"));
					v2.add(rs.getString("ADRESSE"));
					v2.add(rs.getString("EMAIL"));
					v2.add(rs.getString("TEL"));

				}

				tab.addRow(v2);
			}

		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		} catch (Exception e1) {

			e1.printStackTrace();
		}

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String login) {
		account.DatabaseConnexion(login, null, null, frame);
		frame = new JFrame();
		frame.setBounds(100, 100, 1000, 537);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JLabel lblClient = new JLabel("Client");
		lblClient.setFont(new Font("Times New Roman", Font.BOLD, 35));

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Registration", TitledBorder.LEADING, TitledBorder.TOP, null, null));

		JPanel panel_1 = new JPanel();

		JButton btnRetour = new JButton("retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClientGUI.this.frame.setVisible(false);
				Dashboard.main(login);
			}
		});
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(Alignment.LEADING).addGroup(groupLayout
				.createSequentialGroup()
				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup().addGap(290).addComponent(lblClient))
						.addGroup(groupLayout.createSequentialGroup().addContainerGap()
								.addComponent(panel, GroupLayout.PREFERRED_SIZE, 378, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 592, Short.MAX_VALUE))
						.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
								.addContainerGap(915, Short.MAX_VALUE).addComponent(btnRetour)))
				.addContainerGap()));
		groupLayout.setVerticalGroup(groupLayout.createParallelGroup(Alignment.TRAILING).addGroup(Alignment.LEADING,
				groupLayout.createSequentialGroup().addContainerGap().addComponent(lblClient).addGap(20)
						.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(panel, 0, 0, Short.MAX_VALUE)
								.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 343, Short.MAX_VALUE))
						.addPreferredGap(ComponentPlacement.RELATED, 41, Short.MAX_VALUE).addComponent(btnRetour)
						.addGap(23)));

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setAlignmentX(Component.RIGHT_ALIGNMENT);

		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				DefaultTableModel tab = (DefaultTableModel) table.getModel();
				int selectedIndex = table.getSelectedRow();

				NOM.setText(tab.getValueAt(selectedIndex, 1).toString());

				PRENOM.setText(tab.getValueAt(selectedIndex, 2).toString());
				LICENCE.setText(tab.getValueAt(selectedIndex, 3).toString());

				ADRESSE.setText(tab.getValueAt(selectedIndex, 4).toString());

				EMAIL.setText(tab.getValueAt(selectedIndex, 5).toString());

				TEL.setText(tab.getValueAt(selectedIndex, 6).toString());
			}
		});
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "ID", "Nom", "Pr\u00E9nom", "Licence", "Addresse", "Email", "Tel" }));
		scrollPane.setViewportView(table);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
				gl_panel_1.createParallelGroup(Alignment.LEADING).addGroup(gl_panel_1.createSequentialGroup()
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE).addContainerGap()));
		gl_panel_1.setVerticalGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup().addGap(5)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
								GroupLayout.PREFERRED_SIZE)
						.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		panel_1.setLayout(gl_panel_1);
		JLabel g = new JLabel("");
		JLabel P = new JLabel("");
		JLabel N = new JLabel("");
		JLabel lblNom = new JLabel("Nom");
		lblNom.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblPrnom = new JLabel("Pr\u00E9nom");
		lblPrnom.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblLicence = new JLabel("Licence");
		lblLicence.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblAdresse = new JLabel("Adresse");
		lblAdresse.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblEmail = new JLabel("E-mail");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblTlphone = new JLabel("T\u00E9l\u00E9phone");
		lblTlphone.setFont(new Font("Tahoma", Font.PLAIN, 14));

		NOM = new JTextField();
		NOM.setColumns(10);

		PRENOM = new JTextField();
		PRENOM.setColumns(10);

		LICENCE = new JTextField();
		LICENCE.setColumns(10);

		ADRESSE = new JTextField();
		ADRESSE.setColumns(10);

		EMAIL = new JTextField();
		EMAIL.setColumns(10);

		TEL = new JTextField();
		TEL.setColumns(10);

		JButton btnAnnuler = new JButton("Supprimer");
		btnAnnuler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection conn;
				PreparedStatement insert;
				DefaultTableModel tab = (DefaultTableModel) table.getModel();
				int selectedIndex = table.getSelectedRow();
				try {
					int ID_CLIENT = Integer.parseInt(tab.getValueAt(selectedIndex, 0).toString());
					int dialogResult = JOptionPane.showConfirmDialog(null, "Voulez- vous vraiment effacer cette donn�s",
							"warning", JOptionPane.YES_NO_OPTION);
					if (dialogResult == JOptionPane.YES_OPTION) {
						Class.forName("com.mysql.cj.jdbc.Driver");
						conn = DriverManager.getConnection("jdbc:mysql://localhost/supercarjava", "root", "");
						insert = conn.prepareStatement("delete from client where ID_CLIENT=? ");

						insert.setInt(1, ID_CLIENT);
						insert.executeUpdate();
						JOptionPane.showMessageDialog(btnAnnuler, this, "Record Deleted", dialogResult);
						table_update();
					}

				} catch (ClassNotFoundException e1) {

					e1.printStackTrace();
				} catch (Exception e1) {

					e1.printStackTrace();
				}
			}
		});

		JButton btnSave = new JButton("Ajouter");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (NOM.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "champs Nom est vide ");
				}
				if (PRENOM.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "champs Prenom est vide ");
				}
				if (ADRESSE.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "champs Adresse est vide ");
				}
				if (LICENCE.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "champs LICENCE est vide ");
				}
				if (EMAIL.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "champs Email est vide ");
				}
				if (TEL.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "champs Telephone est vide ");
				}
				if (Pattern.matches("[a-zA-Z\\s\\-]+", NOM.getText()) == false) { 
					JOptionPane.showMessageDialog(null, NOM.getText()+" Le champ nom peut pas contenir de chiffres et/ou characteres spécials");
				}
				if (Pattern.matches("[a-zA-Z\\s\\-]+", PRENOM.getText()) == false) { 
					JOptionPane.showMessageDialog(null, PRENOM.getText()+" Le champ prénom peut pas contenir de chiffres et/ou characteres spécials");
				}
				if (Pattern.matches("^(.+)@(.+)$", EMAIL.getText()) == false) { 
					JOptionPane.showMessageDialog(null, EMAIL.getText()+" Le champ 'e-mail' n'est pas valide (xxxxx@xxxx.com)");
				}
				else {

					try {
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/supercarjava",
								"root", "");
						PreparedStatement ps = conn.prepareStatement(
								"insert into client(NOM, PRENOM, LICENCE,ADRESSE,EMAIL,TEL) values(?,?,?,?,?,?)");
						ps.setString(1, NOM.getText());
						ps.setString(2, PRENOM.getText());
						ps.setString(3, LICENCE.getText());
						ps.setString(4, ADRESSE.getText());
						ps.setString(5, EMAIL.getText());
						ps.setString(6, TEL.getText());

						int x = ps.executeUpdate();
						if (x > 0) {
							JOptionPane.showMessageDialog(null, "Record Added");
						} else {
							JOptionPane.showMessageDialog(null, "Record Deleted");
						}
					} catch (Exception e1) {
						System.out.println(e1);
					}
					table_update();
				}
			}
		});

		JButton btnEdit = new JButton("Modifier");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Connection conn;
				PreparedStatement insert;
				DefaultTableModel tab = (DefaultTableModel) table.getModel();
				int selectedIndex = table.getSelectedRow();

				try {
					int ID_CLIENT = Integer.parseInt(tab.getValueAt(selectedIndex, 0).toString());
					String nom = NOM.getText();
					String prenom = PRENOM.getText();
					String licence = LICENCE.getText();
					String adresse = ADRESSE.getText();
					String email = EMAIL.getText();
					String tel = TEL.getText();

					Class.forName("com.mysql.cj.jdbc.Driver");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/supercarjava", "root", "");
					insert = conn.prepareStatement(
							"update client set NOM=?,PRENOM=?,LICENCE=?,ADRESSE=?,EMAIL=?,TEL=? where ID_CLIENT=? ");
					insert.setString(1, nom);
					insert.setString(2, prenom);
					insert.setString(3, licence);
					insert.setString(4, adresse);

					insert.setString(5, email);
					insert.setString(6, tel);

					insert.setInt(7, ID_CLIENT);
					insert.executeUpdate();

				} catch (ClassNotFoundException e1) {

					e1.printStackTrace();
				} catch (Exception e1) {

					e1.printStackTrace();
				}
				table_update();
			}
		});

		N.setForeground(Color.RED);

		P.setForeground(Color.RED);

		g.setForeground(Color.RED);
		
		JButton btnSave_1 = new JButton("Annuler");
		btnSave_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NOM.setText("");
				PRENOM.setText("");
				EMAIL.setText("");
				LICENCE.setText("");
				ADRESSE.setText("");
				TEL.setText("");
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap(49, Short.MAX_VALUE)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel.createSequentialGroup()
									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_panel.createSequentialGroup()
											.addComponent(lblNom)
											.addPreferredGap(ComponentPlacement.UNRELATED)
											.addComponent(N))
										.addComponent(lblEmail)
										.addComponent(lblTlphone)
										.addGroup(gl_panel.createSequentialGroup()
											.addComponent(lblPrnom)
											.addPreferredGap(ComponentPlacement.RELATED)
											.addComponent(P)))
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(g)
									.addGap(18)
									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
										.addComponent(TEL, GroupLayout.PREFERRED_SIZE, 145, GroupLayout.PREFERRED_SIZE)
										.addComponent(EMAIL, GroupLayout.PREFERRED_SIZE, 145, GroupLayout.PREFERRED_SIZE)
										.addComponent(PRENOM, GroupLayout.PREFERRED_SIZE, 145, GroupLayout.PREFERRED_SIZE)
										.addComponent(NOM, GroupLayout.PREFERRED_SIZE, 145, GroupLayout.PREFERRED_SIZE)
										.addComponent(LICENCE, GroupLayout.PREFERRED_SIZE, 145, GroupLayout.PREFERRED_SIZE)
										.addComponent(ADRESSE, GroupLayout.PREFERRED_SIZE, 145, GroupLayout.PREFERRED_SIZE)))
								.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
									.addComponent(lblAdresse)
									.addComponent(lblLicence))))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(btnAnnuler)
							.addGap(31)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
								.addComponent(btnSave, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnSave_1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addGap(27)
							.addComponent(btnEdit)))
					.addGap(39))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(46)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNom)
						.addComponent(NOM, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(N))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPrnom)
						.addComponent(PRENOM, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(P))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblLicence)
						.addComponent(LICENCE, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAdresse)
						.addComponent(ADRESSE, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblEmail)
						.addComponent(EMAIL, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(g))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTlphone)
						.addComponent(TEL, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(32)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAnnuler)
						.addComponent(btnEdit)
						.addComponent(btnSave))
					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(btnSave_1))
		);
		panel.setLayout(gl_panel);
		frame.getContentPane().setLayout(groupLayout);
	}
}
