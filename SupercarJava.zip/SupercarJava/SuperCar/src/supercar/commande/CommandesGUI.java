package supercar.commande;

import java.awt.EventQueue;
import java.sql.SQLException;
import java.text.ParseException;
import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JTable;
import supercar.login.AdminAccount;
import supercar.login.Dashboard;
import supercar.utilities.DBUtilStock;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

/**
 * class CommandeGUI : GUI for 'Commandes'
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
public class CommandesGUI {

	private JFrame frame;
	private JFrame errorFrame;
	private JTable table;
	private JLabel lblCommandes;
	private Timer timer;
	private JButton btnRetour;
	private JLabel lblCoutTotalCommandes;
	private JLabel lblTotalCommandes;
	private JScrollPane scrollPane;
	private AdminAccount account = new AdminAccount();
	private DBUtilStock affichage = new DBUtilStock();

	/**
	 * Launch the application.
	 * @param login: login of the Authentified User.
	 */
	public static void main(String login) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CommandesGUI window = new CommandesGUI(login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Import stock database data in the table model using DBUtilStock's method
	 * 'graphicGetAllCommandes'
	 * 
	 * Table composed of ("ID", "Modele", "Entrepot", "Nombre de véhicule", "Prix de
	 * commandes")
	 *
	 * Set the total price of 'Commandes' in the label lblTotalCommandes
	 * 
	 * @param table table of data
	 * @throws SQLException
	 */
	public void printTableAffichage(JTable table) throws SQLException {
		affichage.graphicGetAllCommandes(table);
		affichage.getTotalCommandes(lblTotalCommandes);
	}

	/**
	 * Create the application.
	 * @param : login of the Authentified User.
	 * 
	 * @throws ParseException
	 * @throws SQLException
	 *  @param login : login of the Authentified User.
	 */
	public CommandesGUI(String login) throws ParseException, SQLException {
		initialize(login);
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * 'account.DatabaseConnexion' that will help for the authenticated
	 * to see all of his informations / disconnnect if the user is not in the
	 * database.
	 * 
	 * Table (table) with auto-refresh features (the table will auto-refresh with
	 * the database every 10 seconds (10000ms) ).
	 * 
	 * Button (btnRetour) 'retour' that will make the user return into the
	 * 'Dashboard' Page.
	 * 
	 * @param login : login of the Authentified User.
	 * 
	 * @throws ParseException.
	 * @throws SQLException.
	 */

	private void initialize(String login) throws ParseException, SQLException {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 906, 734);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		account.DatabaseConnexion(login, null, null, frame);

		scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setBounds(10, 100, 878, 483);
		frame.getContentPane().add(scrollPane);
		table = new JTable();

		table.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "ID", "Modele", "Entrepot", "Nombre de véhicule", "Prix de commandes" }));
		table.getColumnModel().getColumn(0).setPreferredWidth(80);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(2).setPreferredWidth(200);
		table.getColumnModel().getColumn(3).setPreferredWidth(200);
		table.getColumnModel().getColumn(4).setPreferredWidth(200);
		table.setEnabled(false);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setCellSelectionEnabled(true);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		scrollPane.setViewportView(table);

		timer = new Timer(0, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					printTableAffichage(table);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE D'ACTUALISER LA LISTE !!");
				}
			}
		});

		timer.setDelay(10000);
		timer.start();

		lblCommandes = new JLabel("Commandes");
		lblCommandes.setFont(new Font("Dialog", Font.BOLD, 25));
		lblCommandes.setHorizontalAlignment(SwingConstants.CENTER);
		lblCommandes.setBounds(335, 42, 154, 48);
		frame.getContentPane().add(lblCommandes);

		lblTotalCommandes = new JLabel("");
		lblTotalCommandes.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotalCommandes.setBounds(643, 610, 234, 26);
		frame.getContentPane().add(lblTotalCommandes);

		lblCoutTotalCommandes = new JLabel("Cout Total Commandes :");
		lblCoutTotalCommandes.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCoutTotalCommandes.setBounds(411, 610, 222, 26);
		frame.getContentPane().add(lblCoutTotalCommandes);

		btnRetour = new JButton("retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CommandesGUI.this.frame.setVisible(false);
				Dashboard.main(login);
			}
		});
		btnRetour.setBounds(778, 656, 99, 26);
		frame.getContentPane().add(btnRetour);
	}
}
