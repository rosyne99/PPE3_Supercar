package supercar.constants;
/**
 * Enum CRUDMode :ADD,UPDATE,DELETE,REDUCE
 * @author gregb
 *
 */
public enum CRUDMode {
	ADD, 
	UPDATE, 
	DELETE,
	REDUCE
	
}
