package supercar.db;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Class ConnectionFactory : class that connect the application JDBC driver to
 * the mysql server database
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
public class ConnectionFactory {
	private static String connectionUrl;
	private static String dbUser;
	private static String dbPassword;

	/**
	 * Retrive the information of dbconfig.propreties to connect into the mysql
	 * server database
	 */
	private final static Properties dbProperties = new Properties();
	static {
		try (InputStream input = new FileInputStream("dbconfig.properties")) {
			dbProperties.load(input);

			dbProperties.getProperty("driver-class-name");
			connectionUrl = dbProperties.getProperty("connection-url");
			dbUser = dbProperties.getProperty("user");
			dbPassword = dbProperties.getProperty("password");
		} catch (IOException ioex) {
			ioex.printStackTrace();
		}
	}

	/**
	 * Connection to the MySql server database method
	 * 
	 * @return conn
	 * @throws SQLException
	 */
	public static Connection getConnection() throws SQLException {
		Connection conn = null;
		conn = DriverManager.getConnection(connectionUrl, dbUser, dbPassword);
		return conn;
	}
}
