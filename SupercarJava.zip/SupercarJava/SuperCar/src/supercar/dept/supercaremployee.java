package supercar.dept;

/***

 * Auteur: Rosine Laridain
 * Groupe: F-society
 * Developer: En Mars-Avril
 */

/***
 * Consiste a developp� une interface pour le humaine ressources, pour gerer la partie employ�
 */
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Window;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;
import java.util.Vector;
import java.util.regex.Pattern;

import javax.swing.JPanel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import supercar.login.AdminAccount;
import supercar.login.Dashboard;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.security.SecureRandom;
import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.regex.*;

public class supercaremployee {

	private JFrame frame;
	private AdminAccount account = new AdminAccount();
	private JTextField nom;
	private JTextField prenom;
	private JTextField adresse;
	private JTextField salaire;
	private JTextField date_entree;
	private JTextField mail;
	private JTextField tel;
	private JTable table;
	private JComboBox deptcombobox;
	private JTextField txtId;

	/**
	 * Launch the application.
	 */

	public static void supercaremployee(String login) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					supercaremployee window = new supercaremployee(login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * pour pouvoir ouvrir la page employee cette page
	 * 
	 * @param login
	 */
	public static void main(String login) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					supercaremployee window = new supercaremployee(login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public supercaremployee(String login) {
		initialize(login);
		/**
		 * pour mettre a jour la table employ�
		 */
		table_update();
	}

	/**
	 * Pour mettre a jour la table employ�
	 * 
	 */
	private void table_update() {
		int c;
		try {
			Connection conn;
			PreparedStatement insert;
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/supercarjava", "root", "");
			insert = conn.prepareStatement(
					"select * from employe,dept where employe.id_dept = dept.id_dept and dept.Active = 1");
			ResultSet rs = insert.executeQuery();
			ResultSetMetaData Rss = (ResultSetMetaData) rs.getMetaData();
			c = Rss.getColumnCount();

			DefaultTableModel tab = (DefaultTableModel) table.getModel();

			tab.setRowCount(0);
			while (rs.next()) {

				Vector v2 = new Vector();

				for (int a = 1; a <= c; a++) {
					/**
					 * pour afficher les donn�es qui sont dans la base de donn�es
					 */
					v2.add(rs.getString("ID_EMPLOYE"));
					v2.add(rs.getString("employe.NOM"));
					v2.add(rs.getString("PRENOM"));
					v2.add(rs.getString("employe.ADRESSE"));
					v2.add(account.decryptInString(rs.getString("SALAIRE"), account.getMasterKey()));
					v2.add(rs.getString("DATE_ENTREE"));
					v2.add(rs.getString("EMAIL"));
					v2.add(rs.getString("TEL"));
					v2.add(rs.getString("employe.TYPE"));
					v2.add(rs.getString("DEPT.nom"));

				}

				tab.addRow(v2);
			}

		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		} catch (Exception e1) {

			e1.printStackTrace();
		}

	}

	public void close() {
		frame.setVisible(false);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void initialize(String login) {
		account.DatabaseConnexion(login, null, null, frame);
		frame = new JFrame();
		frame.setBounds(100, 100, 1300, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JLabel lblEmploye = new JLabel("Employ\u00E9e");
		lblEmploye.setFont(new Font("Tahoma", Font.BOLD, 37));

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Registration", TitledBorder.LEADING, TitledBorder.TOP, null, null));

		JPanel panel_1 = new JPanel();
		/**
		 * pour retourner en arriers
		 */
		JButton button = new JButton("Go Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/**
				 * pour fermer la page supercaremployee
				 */
				close();

				/**
				 * et ouvrir la page hr
				 */
				Dashboard.main(login);

			}
		});
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup().addContainerGap()
						.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
								.addGroup(groupLayout.createSequentialGroup()
										.addComponent(button, GroupLayout.PREFERRED_SIZE, 108,
												GroupLayout.PREFERRED_SIZE)
										.addGap(343))
								.addGroup(groupLayout.createSequentialGroup()
										.addComponent(panel, GroupLayout.PREFERRED_SIZE, 445,
												GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(ComponentPlacement.UNRELATED)))
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup().addGap(68).addComponent(lblEmploye))
								.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 820, GroupLayout.PREFERRED_SIZE))));
		groupLayout.setVerticalGroup(groupLayout.createParallelGroup(Alignment.TRAILING).addGroup(groupLayout
				.createSequentialGroup().addContainerGap()
				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup().addComponent(lblEmploye)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 355, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
								.addComponent(button, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(panel, GroupLayout.PREFERRED_SIZE, 497, GroupLayout.PREFERRED_SIZE)))
				.addGap(18)));

		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
				gl_panel_1.createParallelGroup(Alignment.LEADING).addGroup(gl_panel_1.createSequentialGroup()
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 810, Short.MAX_VALUE).addContainerGap()));
		gl_panel_1.setVerticalGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 402, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		table = new JTable();
		table.setModel(new DefaultTableModel(
				new Object[][] { { null, null, null, null, null, null, null, null, null, null, null, null }, },
				new String[] { "ID", "Nom", "Pr\u00E9nom", "Adresse", "Salaire", "Date_Entr\u00E9e", "E-mail", "Tel",
						"Dept", "Active/Inactive" }));
		table.getColumnModel().getColumn(11).setPreferredWidth(0);
		table.getColumnModel().getColumn(11).setMinWidth(0);
		table.getColumnModel().getColumn(11).setMaxWidth(0);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				/**
				 * pour afficher les donn�es selectionner
				 */
				DefaultTableModel tab = (DefaultTableModel) table.getModel();
				int selectedIndex = table.getSelectedRow();
				txtId.setText(tab.getValueAt(selectedIndex, 0).toString());
				nom.setText(tab.getValueAt(selectedIndex, 1).toString());
				prenom.setText(tab.getValueAt(selectedIndex, 2).toString());
				adresse.setText(tab.getValueAt(selectedIndex, 3).toString());
				salaire.setText(tab.getValueAt(selectedIndex, 4).toString());
				date_entree.setText(tab.getValueAt(selectedIndex, 5).toString());
				mail.setText(tab.getValueAt(selectedIndex, 6).toString());
				tel.setText(tab.getValueAt(selectedIndex, 7).toString());
				deptcombobox.setToolTipText(tab.getValueAt(selectedIndex, 8).toString());

			}
		});
		scrollPane.setViewportView(table);
		panel_1.setLayout(gl_panel_1);
		JLabel s = new JLabel("");
		s.setForeground(Color.RED);
		JLabel d = new JLabel("");
		d.setForeground(Color.RED);

		JLabel g = new JLabel("");
		g.setForeground(Color.RED);

		JLabel p = new JLabel("");
		JLabel q = new JLabel("");
		JLabel lblNewLabel = new JLabel("Pr\u00E9nom");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblAdresse = new JLabel("Adresse");
		lblAdresse.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblSalaire = new JLabel("Salaire");
		lblSalaire.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblDateentre = new JLabel("Date_Entr\u00E9e");
		lblDateentre.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblMail = new JLabel("Mail");
		lblMail.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblTel = new JLabel("Tel");
		lblTel.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblIddept = new JLabel("Dept");
		lblIddept.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblNom = new JLabel("Nom");
		lblNom.setFont(new Font("Tahoma", Font.PLAIN, 14));

		nom = new JTextField();
		nom.addKeyListener(new KeyAdapter() {

			public void keyReleased(KeyEvent e) {

				String PATTERN = "^[a-zA-Z]{0,45}";
				Pattern patt = Pattern.compile(PATTERN);
				Matcher match = patt.matcher(nom.getText());

				if (!match.matches()) {
					q.setText("pas de chiffres!!");
				} else {
					q.setText(null);
				}

			}
		});
		nom.setColumns(10);

		prenom = new JTextField();
		prenom.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {

				String PATTERN = "^[a-zA-Z]{0,45}";
				Pattern patt = Pattern.compile(PATTERN);
				Matcher match = patt.matcher(prenom.getText());

				if (!match.matches()) {
					p.setText("pas de chiffres!!");
				} else {
					p.setText(null);
				}

			}

		});
		prenom.setColumns(10);

		adresse = new JTextField();
		adresse.setColumns(10);

		salaire = new JTextField();
		salaire.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {

				String PATTERN = "^[0-9]{0,30}$";
				Pattern patt = Pattern.compile(PATTERN);
				Matcher match = patt.matcher(salaire.getText());

				if (!match.matches()) {
					s.setText("pas de lettre!!");
				} else {
					s.setText(null);
				}

			}
		});
		salaire.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {

				if (salaire.getText().equals("e.g 12.00")) {
					salaire.setText("");
					salaire.setForeground(new Color(153, 153, 153));
				}
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (salaire.getText().equals("")) {
					salaire.setText("e.g 12.00");
					salaire.setForeground(new Color(153, 153, 153));
				}

			}
		});
		salaire.setForeground(Color.LIGHT_GRAY);
		salaire.setText("e.g 12.00");
		salaire.setColumns(10);

		date_entree = new JTextField();
		date_entree.addKeyListener(new KeyAdapter() {

			public void keyReleased(KeyEvent e) {

			}
		});
		/**
		 * pour afficher la fason donc les utilisateur doivent ecrire
		 */
		date_entree.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (date_entree.getText().equals("yyyy-mm-dd")) {
					date_entree.setText("");
					date_entree.setForeground(new Color(153, 153, 153));
				}
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (date_entree.getText().equals("")) {
					date_entree.setText("yyyy-mm-dd");
					date_entree.setForeground(new Color(153, 153, 153));
				}
			}
		});
		date_entree.setForeground(Color.LIGHT_GRAY);
		date_entree.setText("yyyy-mm-dd");
		date_entree.setColumns(10);

		mail = new JTextField();
		mail.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {

				String PATTERN = "^[a-zA-Z0-9]{0,30}[@][a-zA-Z]{0,10}[.][a-zA-Z]{0,10}$";
				Pattern patt = Pattern.compile(PATTERN);
				Matcher match = patt.matcher(mail.getText());

				if (!match.matches()) {
					g.setText("incorect!!");
				} else {
					g.setText(null);
				}
			}

		});
		mail.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (mail.getText().equals("john@gmail.com")) {
					mail.setText("");
					mail.setForeground(new Color(153, 153, 153));
				}

			}

			@Override
			public void focusLost(FocusEvent e) {
				if (mail.getText().equals("")) {
					mail.setText("john@gmail.com");
					mail.setForeground(new Color(153, 153, 153));
				}

			}
		});
		mail.setForeground(Color.LIGHT_GRAY);
		mail.setText("john@gmail.com");
		mail.setColumns(10);

		tel = new JTextField();
		tel.setColumns(10);

		deptcombobox = new JComboBox();
		try {
			Connection conn;
			PreparedStatement insert;
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/supercarjava", "root", "");
			insert = conn.prepareStatement("select * from dept");
			DefaultComboBoxModel theModel = (DefaultComboBoxModel) deptcombobox.getModel();
			ResultSet rs = insert.executeQuery();
			theModel.removeAllElements();
			while (rs.next()) {
				theModel.addElement(rs.getString("ID_DEPT") + " - " + rs.getString("NOM"));
			}
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		/***
		 * pour ajouter les donn�es
		 */
		JButton btnAjouter = new JButton("Ajouter");
		btnAjouter.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				try {

					Connection conn;
					PreparedStatement insert;
					String NOM = nom.getText();
					String PRENOM = prenom.getText();
					String ADRESSE = adresse.getText();
					String SALAIRE = salaire.getText();
					String DATE_ENTREE = date_entree.getText();
					String EMAIL = mail.getText();
					String TEL = tel.getText();
					String[] deptArray = deptcombobox.getSelectedItem().toString().split("-");
					String ID_DEPT = deptArray[0];

					/**
					 * pour crypter la parti salaire
					 */
					SALAIRE = account.encryptInString(SALAIRE, account.getMasterKey());

					/**
					 * si le champs est vide, on va aficher un erreur
					 */
					if (NOM.equals("")) {
						JOptionPane.showMessageDialog(null, "champs Nom est vide ");
					}
					if (PRENOM.equals("")) {
						JOptionPane.showMessageDialog(null, "champs Prenom est vide ");
					}
					if (ADRESSE.equals("")) {
						JOptionPane.showMessageDialog(null, "champs Adresse est vide ");
					}
					if (SALAIRE.equals("")) {
						JOptionPane.showMessageDialog(null, "champs Salaire est vide ");
					}
					if (DATE_ENTREE.equals("")) {
						JOptionPane.showMessageDialog(null, "champs date est vide ");
					}
					if (EMAIL.equals("")) {
						JOptionPane.showMessageDialog(null, "champs Email est vide ");
					}
					if (TEL.equals("")) {
						JOptionPane.showMessageDialog(null, "champs Telephone est vide ");
					}

					/**
					 * afficher des erreurs si contient des chiffres
					 */
					if (!NOM.matches("[A-Za-z]+")) {
						JOptionPane.showMessageDialog(null, "Le champs Nom peut pas contenir des chiffres");
					}
					if (!PRENOM.matches("[a-zA-Z]+")) {
						JOptionPane.showMessageDialog(null, "Le champs Prenom peut pas contenir des chiffres");
					}
					/**
					 * pour afficher des erreurs si le champs contient des lettres
					 */
					if (!SALAIRE.matches("[0-9]+")) {
						JOptionPane.showMessageDialog(null, "Le champs Salaire peut pas contenir des chiffres");
					}
					/**
					 * pour voir si la parti emal est ecrit correctement
					 */
					if (!EMAIL.matches("[a-zA-Z0-9]{0,30}[@][a-zA-Z]{0,10}[.][a-zA-Z]{0,10}+")) {
						JOptionPane.showMessageDialog(null, "Le champs Email incorrect");
					} else {

						/**
						 * cette partie on ajoute les donn�es dans la base de dpnn�es
						 */

						Class.forName("com.mysql.cj.jdbc.Driver");
						conn = DriverManager.getConnection("jdbc:mysql://localhost/supercarjava", "root", "");
						insert = conn.prepareStatement(
								"insert into employe(NOM,PRENOM,ADRESSE,SALAIRE,DATE_ENTREE,EMAIL,TEL,TYPE,ID_DEPT,ACTIVE)values(?,?,?,?,?,?,?,?,?,?,1)");
						insert.setString(1, NOM);
						insert.setString(2, PRENOM);
						insert.setString(3, ADRESSE);
						insert.setString(4, SALAIRE);
						insert.setString(5, DATE_ENTREE);
						insert.setString(6, EMAIL);
						insert.setString(7, TEL);
						insert.setString(8, ID_DEPT);

						insert.executeUpdate();
						JOptionPane.showMessageDialog(btnAjouter, this, "Record Added", 0);

					}
				} catch (ClassNotFoundException e1) {

					e1.printStackTrace();
				} catch (Exception e1) {

					e1.printStackTrace();
				}

				table_update();

			}
		});
		btnAjouter.setFont(new Font("Tahoma", Font.BOLD, 15));
		/***
		 * pour modifier une donn�es
		 */
		JButton btnModifier = new JButton("Modifier");
		btnModifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection conn;
					PreparedStatement insert;
					String NOM = nom.getText();
					String PRENOM = prenom.getText();
					String ADRESSE = adresse.getText();
					String SALAIRE = salaire.getText();
					String DATE_ENTREE = date_entree.getText();
					String EMAIL = mail.getText();
					String TEL = tel.getText();
					String[] deptArray = deptcombobox.getSelectedItem().toString().split("-");
					String ID_DEPT = deptArray[0];

					SALAIRE = account.encryptInString(SALAIRE, account.getMasterKey());
					int ID_EMPLOYE = Integer.parseInt(txtId.getText());
					Class.forName("com.mysql.cj.jdbc.Driver");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/supercarjava", "root", "");
					insert = conn.prepareStatement(
							"update employe set NOM=?,PRENOM=?,ADRESSE=?,SALAIRE=?,DATE_ENTREE=?,EMAIL=?,TEL=?,ID_DEPT=?,ACTIVE=1 where ID_EMPLOYE=? ");
					insert.setString(1, NOM);
					insert.setString(2, PRENOM);
					insert.setString(3, ADRESSE);
					insert.setString(4, SALAIRE);
					insert.setString(5, DATE_ENTREE);
					insert.setString(6, EMAIL);
					insert.setString(7, TEL);
					insert.setString(8, ID_DEPT);
					insert.setInt(9, ID_EMPLOYE);
					insert.executeUpdate();
					JOptionPane.showMessageDialog(null, "Record Updated");

				} catch (ClassNotFoundException e1) {

					e1.printStackTrace();
				} catch (Exception e1) {

					e1.printStackTrace();
				}

				table_update();
			}
		});
		btnModifier.setFont(new Font("Tahoma", Font.BOLD, 15));
		/***
		 * pour effaser les donn�e du formulaire
		 */
		JButton btnAnnuler = new JButton("Annuler");
		btnAnnuler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nom.setText("");
				prenom.setText("");
				adresse.setText("");
				salaire.setText("");
				date_entree.setText("");
				mail.setText("");
				tel.setText("");
			}
		});
		btnAnnuler.setFont(new Font("Tahoma", Font.BOLD, 15));

		q.setFont(new Font("Tahoma", Font.ITALIC, 12));
		q.setForeground(Color.RED);

		p.setForeground(Color.RED);

		JButton btnSupprimer = new JButton("Supprimer");
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (account.getAccountType() == "2") {
						Connection conn;
						PreparedStatement insert;
						int ID_EMPLOYE = Integer.parseInt(txtId.getText());
						Class.forName("com.mysql.cj.jdbc.Driver");
						conn = DriverManager.getConnection("jdbc:mysql://localhost/supercarjava", "root", "");
						insert = conn.prepareStatement("update employe set ACTIVE=0 where ID_EMPLOYE=? ");
						insert.setInt(1, ID_EMPLOYE);
						insert.executeUpdate();
						insert = conn.prepareStatement("update login set ACTIVE=0 where ID_EMPLOYE=? ");
						insert.setInt(1, ID_EMPLOYE);
						insert.executeUpdate();
						JOptionPane.showMessageDialog(null, "Record Deleted");
					} else {
						JOptionPane.showMessageDialog(null, "vous n'avez pas les privilieges...");
					}
				} catch (Exception E) {
					E.printStackTrace();
				}
				table_update();
			}
		});
		btnSupprimer.setFont(new Font("Tahoma", Font.BOLD, 13));

		JLabel lblId = new JLabel("Id");
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 14));

		txtId = new JTextField();
		txtId.setEditable(false);
		txtId.setColumns(10);

		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(gl_panel.createParallelGroup(Alignment.LEADING).addGroup(gl_panel
				.createSequentialGroup()
				.addGroup(gl_panel.createParallelGroup(Alignment.LEADING).addGroup(gl_panel.createSequentialGroup()
						.addComponent(btnAjouter).addPreferredGap(ComponentPlacement.RELATED).addComponent(btnModifier)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnAnnuler, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE).addGap(12)
						.addComponent(btnSupprimer, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup().addGap(141).addComponent(q))
						.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
								.addGroup(gl_panel.createSequentialGroup()
										.addComponent(lblIddept, GroupLayout.PREFERRED_SIZE, 135,
												GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(deptcombobox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
								.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup().addGroup(gl_panel
										.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_panel.createSequentialGroup().addGroup(gl_panel
												.createParallelGroup(Alignment.TRAILING, false)
												.addComponent(lblNewLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
														GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
												.addComponent(lblNom, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 48,
														Short.MAX_VALUE)
												.addComponent(lblAdresse, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
														GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
												.addComponent(lblSalaire, Alignment.LEADING))
												.addPreferredGap(ComponentPlacement.RELATED)
												.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
														.addComponent(s).addComponent(p)))
										.addGroup(gl_panel.createSequentialGroup()
												.addComponent(lblDateentre, GroupLayout.PREFERRED_SIZE, 85,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED).addComponent(d))
										.addGroup(gl_panel.createSequentialGroup().addGroup(gl_panel
												.createParallelGroup(Alignment.TRAILING, false)
												.addComponent(lblTel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
														GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
												.addComponent(lblMail, Alignment.LEADING))
												.addPreferredGap(ComponentPlacement.RELATED).addComponent(g))
										.addComponent(lblId, GroupLayout.PREFERRED_SIZE, 49,
												GroupLayout.PREFERRED_SIZE))
										.addGap(18)
										.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
												.addComponent(txtId, GroupLayout.PREFERRED_SIZE, 178,
														GroupLayout.PREFERRED_SIZE)
												.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
														.addComponent(tel, GroupLayout.DEFAULT_SIZE, 178,
																Short.MAX_VALUE)
														.addComponent(mail, GroupLayout.DEFAULT_SIZE, 178,
																Short.MAX_VALUE)
														.addComponent(date_entree, GroupLayout.DEFAULT_SIZE, 178,
																Short.MAX_VALUE)
														.addComponent(salaire, GroupLayout.DEFAULT_SIZE, 178,
																Short.MAX_VALUE)
														.addComponent(adresse, GroupLayout.DEFAULT_SIZE, 178,
																Short.MAX_VALUE)
														.addComponent(prenom, GroupLayout.DEFAULT_SIZE, 178,
																Short.MAX_VALUE)
														.addComponent(nom, GroupLayout.DEFAULT_SIZE, 178,
																Short.MAX_VALUE))))))
				.addContainerGap(50, Short.MAX_VALUE)));
		gl_panel.setVerticalGroup(gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup().addGap(21)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblId, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
								.addComponent(txtId, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE))
						.addGap(18)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNom, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
								.addComponent(nom, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
								.addComponent(q, GroupLayout.PREFERRED_SIZE, 0, GroupLayout.PREFERRED_SIZE))
						.addGap(2)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
								.addComponent(prenom, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
								.addComponent(p))
						.addPreferredGap(ComponentPlacement.UNRELATED)
						.addGroup(gl_panel.createParallelGroup(Alignment.LEADING).addGroup(gl_panel
								.createSequentialGroup()
								.addComponent(lblAdresse, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.UNRELATED)
								.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
										.addComponent(lblSalaire, GroupLayout.PREFERRED_SIZE, 31,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(s))
								.addPreferredGap(ComponentPlacement.UNRELATED)
								.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
										.addComponent(lblDateentre, GroupLayout.PREFERRED_SIZE, 31,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(d))
								.addPreferredGap(ComponentPlacement.RELATED)
								.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
										.addComponent(lblMail, GroupLayout.PREFERRED_SIZE, 24,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(g))
								.addGap(18)
								.addComponent(lblTel, GroupLayout.PREFERRED_SIZE, 24, GroupLayout.PREFERRED_SIZE))
								.addGroup(
										gl_panel.createSequentialGroup()
												.addComponent(adresse, GroupLayout.PREFERRED_SIZE, 29,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(salaire, GroupLayout.PREFERRED_SIZE, 29,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(date_entree, GroupLayout.PREFERRED_SIZE, 29,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.UNRELATED)
												.addComponent(mail, GroupLayout.PREFERRED_SIZE, 29,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.UNRELATED).addComponent(tel,
														GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(ComponentPlacement.RELATED)
						.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblIddept, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
								.addComponent(deptcombobox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addGap(43)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(btnAjouter)
								.addComponent(btnModifier, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnAnnuler, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnSupprimer, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE))
						.addGap(55)));
		panel.setLayout(gl_panel);
		frame.getContentPane().setLayout(groupLayout);
	}
}
