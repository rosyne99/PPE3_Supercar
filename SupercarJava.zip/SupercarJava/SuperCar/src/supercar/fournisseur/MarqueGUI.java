package supercar.fournisseur;

import java.awt.EventQueue;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.EmptyStackException;
import java.util.regex.Pattern;
import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JTable;
import supercar.constants.CRUDMode;
import supercar.login.AdminAccount;
import supercar.login.Dashboard;
import supercar.model.Marque;
import supercar.utilities.DBUtilMarque;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;

/**
 * class MarqueGUI : GUI for 'Marque' && 'Fournisseurs'
 * 
 * @SuppressWarnings("rawtypes") added for JcomboBox 'idDropdown' warning
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
@SuppressWarnings("rawtypes")
public class MarqueGUI {

	private JFrame frame;
	private JFrame errorFrame;
	private JFrame retourFrame;
	private Timer timer;
	private JTable table;
	private boolean error;
	private JLabel lblId;
	private JLabel lblMarque;
	private JLabel lblNouvelMarque;
	private JPanel panel;
	private JLabel lblNom;
	private JLabel lblOrigine;
	private JLabel lblFournisseur;
	private JLabel lblContact;
	private JLabel lblEmail;
	private JButton btnSupprimer;
	private JButton btnRetour;
	private JButton btnModifier;
	private JButton btnAjouter;
	private JButton btnAnnuler;
	private JComboBox idDropdown;
	private static String idString;
	private static String marqueString;
	private static String origineString;
	private static String fournisseurString;
	private static String contactString;
	private static String emailString;
	private JTextField txtNom;
	private JTextField txtOrigine;
	private JTextField txtFournisseur;
	private JTextField txtContact;
	private JTextField txtEmail;
	private DBUtilMarque affichage = new DBUtilMarque();;
	private AdminAccount account = new AdminAccount();
	private JScrollPane scrollPane;

	/**
	 * Launch the application.
	 *  @param login : login of the Authentified User.
	 */
	public static void main(String login) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MarqueGUI window = new MarqueGUI(login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Method that put all the information into the variables of the model.Marque
	 * Class for insertion or update in the Database
	 * 
	 * @param mode
	 * @return marque : Model object of class Marque
	 */
	private static Marque retrieveInputGUI(CRUDMode mode) {
		Marque marque = new Marque();
		if (mode.equals(CRUDMode.ADD) || mode.equals(CRUDMode.UPDATE)) {
			if (mode.equals(CRUDMode.UPDATE)) {
				marque.setID_MARQUE(idString);
			}
			marque.setNom(marqueString);
			marque.setOrigine(origineString);
			marque.setFournisseur(fournisseurString);
			marque.setContact(contactString);
			marque.setEmail(emailString);
		} else if (mode.equals(CRUDMode.DELETE)) {
			marque.setID_MARQUE(idString);
		}
		return marque;

	}

	/**
	 * Import voiture database data in the table model using DBUtilMarque's method
	 * 'graphicGetAllMarque'
	 * 
	 * Table composed of ("ID", "Marque", "Origine", "Fournisseur", "Contact",
	 * "Email")
	 * 
	 * @param table
	 * @throws SQLException
	 */
	public void printTableAffichage(JTable table) throws SQLException {
		affichage.graphicGetAllMarque(table);
	}

	/**
	 * method that verify every variables used to update / created a 'marque' using
	 * pattern if one of the variable is wrong, verification is "true", the user
	 * will need to correct his mistakes otherwise the data are saved in the
	 * database
	 * 
	 * @param error
	 * @param type
	 * @return error
	 */
	private boolean Verification(boolean error, String type) {
		errorFrame = new JFrame();
		if (type.equals("add") || type.equals("update")) {
			if (type.equals("update")) {
				if (idString == "") {
					txtNom.setText("");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR, ID INVALIDE");
					error = true;
				}
			}
			if (Pattern.matches("[A-Za-zÀ-ȕ]([\\w -]*[A-Za-zÀ-ȕ])*", marqueString) == false
					|| marqueString.equalsIgnoreCase("")) {
				txtNom.setText("");
				JOptionPane.showMessageDialog(errorFrame, "ERREUR, NOM INVALIDE");
				error = true;
			}
			if (Pattern.matches("[A-Za-zÀ-ȕ]([\\w -]*[A-Za-zÀ-ȕ])*", origineString) == false
					|| origineString.equalsIgnoreCase("")) {
				txtOrigine.setText("");
				JOptionPane.showMessageDialog(errorFrame, "ERREUR, ORIGINE INVALIDE");
				error = true;
			}
			if (Pattern.matches("[A-Za-zÀ-ȕ]([\\w -]*[A-Za-zÀ-ȕ])*", fournisseurString) == false
					|| fournisseurString.equalsIgnoreCase("")) {
				txtFournisseur.setText("");
				JOptionPane.showMessageDialog(errorFrame, "ERREUR, FOURNISSEUR INVALIDE");
				error = true;
			}
			if (Pattern.matches("^(.+)@(.+)$", emailString) == false || emailString.equalsIgnoreCase("")) {
				txtEmail.setText("");
				JOptionPane.showMessageDialog(errorFrame, "ERREUR, MAIL INVALIDE");
				error = true;
			}
		}
		return error;
	}

	/**
	 * Create the application.
	 * 
	 * @throws ParseException
	 * @throws SQLException
	 *  @param login : login of the Authentified User.
	 */
	public MarqueGUI(String login) throws ParseException, SQLException {
		initialize(login);
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * 'account.DatabaseConnexion' that will help for the authenticated to see all
	 * of his informations / disconnnect if the user is not in the database.
	 * 
	 * Table (table) with auto-refresh features (the table will auto-refresh with
	 * the database every 10 seconds (10000ms) ) and row selectable for updating an
	 * existing marque.
	 *
	 * Button (btnModifier) 'Modifier' that will update a selected 'marque' to the
	 * database using the ID (if the user works in admin) if the verification
	 * doesn't give any error
	 * 
	 * Button (btnAjouter) 'Ajouter' that will add a new 'marque' to the database
	 * (if the user works in admin) if the verification doesn't give any error
	 * 
	 * Dropdown (idDropdown) 'id' that shows all the existing id
	 * 
	 * TextField (txtNom) 'nom' that will show the brand or let the user write a
	 * brand
	 * 
	 * TextField (txtOrigine) that will show the origin country or let the user
	 * write an origin country
	 * 
	 * TextField (txtFournisseur) that will show the manufacturer name or let the
	 * user write a manufacturer name
	 * 
	 * TextField (txtContact) that will show the manufacturer contact person or let
	 * the user write a manufacturer contact person
	 * 
	 * TextField (txtEmail) that will show the manufacturer contact person mail or
	 * let the user write a manufacturer contact person mail
	 * 
	 * Button (btnSupprimer) 'Supprimer' that will desactivate the 'marque' to the
	 * database using the ID (if the user works in admin and is a manager) if the
	 * verification doesn't give any error
	 *
	 * Button (btnAnnuler) 'Annuler' that will clear every inputs.
	 *
	 * Button (btnRetour) 'Retour' that will make the user return into the
	 * 'Dashboard' Page.
	 * 
	 * @SuppressWarnings("rawtypes") added for JcomboBox 'idDropdown' warning.
	 * 
	 * @param login : login of the Authentified User.
	 * 
	 * @throws ParseException.
	 * @throws SQLException.
	 */

	private void initialize(String login) throws ParseException, SQLException {

		account.DatabaseConnexion(login, null, null, frame);

		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 1366, 768);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setBounds(459, 142, 878, 538);
		frame.getContentPane().add(scrollPane);
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				int row = table.rowAtPoint(e.getPoint());
				try {
					affichage.JcomboId(idDropdown, table, row, "update");
					affichage.JTextFieldNom(txtNom, table, row);
					affichage.JTextFieldOrigine(txtOrigine, table, row);
					affichage.JTextFieldFournisseur(txtFournisseur, table, row);
					affichage.JTextFieldContact(txtContact, table, row);
					affichage.JTextFieldEmail(txtEmail, table, row);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER LA LIGNE !!");
				}
			}
		});
		table.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "ID", "Marque", "Origine", "Fournisseur", "Contact", "Email" }));
		table.getColumnModel().getColumn(0).setPreferredWidth(70);
		table.getColumnModel().getColumn(1).setPreferredWidth(140);
		table.getColumnModel().getColumn(2).setPreferredWidth(130);
		table.getColumnModel().getColumn(3).setPreferredWidth(150);
		table.getColumnModel().getColumn(4).setPreferredWidth(200);
		table.getColumnModel().getColumn(5).setPreferredWidth(200);
		table.setEnabled(false);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setCellSelectionEnabled(true);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		scrollPane.setViewportView(table);

		timer = new Timer(0, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					printTableAffichage(table);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE D'ACTUALISER LA LISTE !!");
				}
			}
		});

		timer.setDelay(10000);
		timer.start();

		panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(12, 142, 435, 538);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		lblId = new JLabel("Id");
		lblId.setFont(new Font("Dialog", Font.BOLD, 15));
		lblId.setBounds(12, 116, 55, 21);
		panel.add(lblId);

		idDropdown = new JComboBox();
		idDropdown.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboId(idDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UN ID !!");
				}
			}
		});

		idDropdown.setBounds(123, 116, 300, 25);
		panel.add(idDropdown);

		btnModifier = new JButton("Modifier");
		btnModifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean error = false;
				idString = idDropdown.getSelectedItem().toString();
				marqueString = txtNom.getText();
				origineString = txtOrigine.getText();
				fournisseurString = txtFournisseur.getText();
				contactString = txtContact.getText();
				emailString = txtEmail.getText();
				if (account.dept.contains("ADMIN")) {
					if (Verification(error, "update") == false) {
						try {
							DBUtilMarque.updateMarque(retrieveInputGUI(CRUDMode.UPDATE));
							retourFrame = new JFrame("retour");
							printTableAffichage(table);
							JOptionPane.showMessageDialog(retourFrame, "Marque modifié");
							affichage.JcomboId(idDropdown, table, 0, null);
							txtNom.setText("");
							txtOrigine.setText("");
							txtFournisseur.setText("");
							txtContact.setText("");
							txtEmail.setText("");
						} catch (Exception E) {
							errorFrame = new JFrame("error");
							JOptionPane.showMessageDialog(frame,
									"ERREUR IMPOSSIBLE DE MODIFIER CETTE MARQUE ET FOURNISSEUR");
						}
					}
				} else {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(frame,
							"ERREUR, vous n'avez pas les privileges de modifier un fourniseur");
				}
			}
		});
		btnModifier.setBounds(309, 468, 114, 26);
		panel.add(btnModifier);

		lblNouvelMarque = new JLabel("Nouvelle/modification Marque");
		lblNouvelMarque.setFont(new Font("Dialog", Font.ITALIC, 15));
		lblNouvelMarque.setHorizontalAlignment(SwingConstants.CENTER);
		lblNouvelMarque.setBounds(31, 12, 392, 51);
		panel.add(lblNouvelMarque);

		btnAnnuler = new JButton("Annuler");
		btnAnnuler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					affichage.JcomboId(idDropdown, table, 0, null);
					txtNom.setText("");
					txtOrigine.setText("");
					txtFournisseur.setText("");
					txtContact.setText("");
					txtEmail.setText("");

				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE REINITIALISER LES CHAMPS");
				}
			}
		});
		btnAnnuler.setBounds(160, 502, 114, 26);
		panel.add(btnAnnuler);

		btnAjouter = new JButton("Ajouter");
		btnAjouter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				error = false;
				marqueString = txtNom.getText();
				origineString = txtOrigine.getText();
				fournisseurString = txtFournisseur.getText();
				contactString = txtContact.getText();
				emailString = txtEmail.getText();
				if (account.dept.contains("ADMIN")) {
					if (Verification(error, "add") == false) {
						try {
							DBUtilMarque.addMarque(retrieveInputGUI(CRUDMode.ADD));
							retourFrame = new JFrame("retour");
							printTableAffichage(table);
							JOptionPane.showMessageDialog(retourFrame, "Marque ajouté");
							affichage.JcomboId(idDropdown, table, 0, null);
							txtNom.setText("");
							txtOrigine.setText("");
							txtFournisseur.setText("");
							txtContact.setText("");
							txtEmail.setText("");
						} catch (Exception E) {
							errorFrame = new JFrame("error");
							JOptionPane.showMessageDialog(errorFrame,
									"ERREUR IMPOSSIBLE D'AJOUTER CETTE OPTION ET FOURNISSEUR");
						}
					}
				} else {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame,
							"ERREUR vous n'avez pas les privileges d'ajouter un fournisseur");
				}

			}
		});
		btnAjouter.setBounds(160, 468, 114, 26);
		panel.add(btnAjouter);

		lblNom = new JLabel("Nom");
		lblNom.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNom.setBounds(12, 172, 92, 13);
		panel.add(lblNom);

		lblOrigine = new JLabel("Origine");
		lblOrigine.setFont(new Font("Dialog", Font.BOLD, 15));
		lblOrigine.setBounds(12, 222, 92, 18);
		panel.add(lblOrigine);

		lblFournisseur = new JLabel("Fournisseur");
		lblFournisseur.setFont(new Font("Dialog", Font.BOLD, 15));
		lblFournisseur.setBounds(12, 272, 92, 13);
		panel.add(lblFournisseur);

		lblContact = new JLabel("Contact");
		lblContact.setFont(new Font("Dialog", Font.BOLD, 15));
		lblContact.setBounds(12, 322, 92, 13);
		panel.add(lblContact);

		lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Dialog", Font.BOLD, 15));
		lblEmail.setBounds(12, 372, 92, 13);
		panel.add(lblEmail);

		txtNom = new JTextField();
		txtNom.setBounds(123, 171, 300, 25);
		panel.add(txtNom);
		txtNom.setColumns(10);

		txtOrigine = new JTextField();
		txtOrigine.setBounds(123, 221, 300, 25);
		panel.add(txtOrigine);
		txtOrigine.setColumns(10);

		txtFournisseur = new JTextField();
		txtFournisseur.setBounds(123, 271, 300, 25);
		panel.add(txtFournisseur);
		txtFournisseur.setColumns(10);

		txtContact = new JTextField();
		txtContact.setBounds(123, 321, 300, 25);
		panel.add(txtContact);
		txtContact.setColumns(10);

		txtEmail = new JTextField();
		txtEmail.setBounds(123, 371, 300, 25);
		panel.add(txtEmail);
		txtEmail.setColumns(10);

		btnSupprimer = new JButton("Supprimer");
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (account.dept.contains("ADMIN") && account.getAccountType().contains("2")) {
					try {
						idString = idDropdown.getSelectedItem().toString();
						if (idString == "") {
							throw new EmptyStackException();
						}
						if (JOptionPane.showConfirmDialog(frame, "Voulez-vous reelement supprimer ce fournisseur?",
								"Supercar", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
							DBUtilMarque.deleteMarque(retrieveInputGUI(CRUDMode.DELETE));
							retourFrame = new JFrame("retour");
							printTableAffichage(table);
							JOptionPane.showMessageDialog(retourFrame, "Stock Supprimé");
						}
					} catch (Exception E) {
						errorFrame = new JFrame("error");
						JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SUPPRIMER CE FOURNISSEUR");
					}

				} else {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame,
							"ERREUR vous n'avez pas les privileges de supprimer un fournisseur");
				}
			}
		});
		btnSupprimer.setBounds(10, 468, 114, 26);
		panel.add(btnSupprimer);

		lblMarque = new JLabel("Marque");
		lblMarque.setFont(new Font("Dialog", Font.BOLD, 25));
		lblMarque.setHorizontalAlignment(SwingConstants.CENTER);
		lblMarque.setBounds(559, 67, 154, 48);
		frame.getContentPane().add(lblMarque);

		btnRetour = new JButton("retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MarqueGUI.this.frame.setVisible(false);
				Dashboard.main(login);
			}
		});
		btnRetour.setBounds(1238, 702, 99, 26);
		frame.getContentPane().add(btnRetour);
	}
}
