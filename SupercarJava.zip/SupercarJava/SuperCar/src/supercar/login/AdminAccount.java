/**
 * 
 */
package supercar.login;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.Key;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * Class AdminAccount inherit UserAccount
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 * 
 */
public class AdminAccount extends UserAccount {
	private Key masterKey;

	/**
	 * getter method for masterKey
	 * 
	 * @return masterKey
	 */
	public Key getMasterKey() {
		return masterKey;
	}

	/**
	 * setter method for masterKey
	 * 
	 * @param masterKey
	 */
	public void setMasterKey(Key masterKey) {
		this.masterKey = masterKey;
	}

	/**
	 * method that read the file where the hexadecimal key is saved, decode it and
	 * set it to a blowfish masterKey using setMasterKey method
	 * 
	 * @throws IOException
	 */
	public void decryptKey() throws IOException {
		String chaine = new String(Files.readAllBytes(Paths.get("key.cryp")));
		byte[] decodedKey = Base64.getDecoder().decode(chaine);
		setMasterKey(new SecretKeySpec(decodedKey, 0, decodedKey.length, "blowfish"));
	}

	/**
	 * Méthode qui peut Chiffrer n'importe qyu'elle donnée et le met en format
	 * octets son appel dans une autre classe se fait par ApiBlowfish.generateKey()
	 *
	 * @param textClair: tout type de donnés pouvant être codé em obctets
	 * @param clef:      la clé de chifremment à utiliser
	 * @return : retourne le cryptage sous forme d'octets
	 * @throws Exception
	 * @author didiers
	 */
	public static byte[] encryptInByte(byte[] textClair, Key clef) throws Exception {

		Cipher chiffre = Cipher.getInstance("Blowfish");

		chiffre.init(Cipher.ENCRYPT_MODE, clef);

		return chiffre.doFinal(textClair); // retourne au format tableau d'octets
	}

	/**
	 * Méthode qui déchiffre les donnée déjà chiffrées son appel dans une autre
	 * classe se fait par ApiBlowfish.decryptInByte(..)
	 *
	 * @param textChiffre: les octets à déchiffrer
	 * @param clef         doit être la même clé utilisée pour chiffrer
	 * @return
	 * @throws Exception
	 * @author didiers
	 */

	public static byte[] decryptInByte(byte[] textChiffre, Key clef) throws Exception {

		Cipher dechiffre = Cipher.getInstance("Blowfish");

		dechiffre.init(Cipher.DECRYPT_MODE, clef);

		byte[] textDechiffre = dechiffre.doFinal(textChiffre);

		return textDechiffre;// retourne au format octet
	}

	/**
	 * Méthode qui peut Chiffrer uniquement une chaîne de caractères son appel dans
	 * une autre classe se fait par ApiBlowfish.encryptInString(..)
	 *
	 * @param textClair
	 * @param clef
	 * @return sous un format encodé affichable dans la console
	 * @throws Exception
	 * @author didiers
	 */

	public static String encryptInString(String textClair, Key clef) throws Exception {

		byte[] chiffre = textClair.getBytes();

		chiffre = encryptInByte(chiffre, clef);

		return Base64.getEncoder().encodeToString(chiffre);

	}

	/**
	 * Méthode qui peut Chiffrer uniquement une chaîne de caractères en utiliant la
	 * même clé que pour chiffrer on l'appel par ApiBlowfish.decryptInString(..)
	 *
	 * @param textChiffre
	 * @param clef        : doit être crée préalablement
	 * @return la chaine chiffrée
	 * @throws Exception
	 * @author didiers
	 */

	public static String decryptInString(String textChiffre, Key clef) throws Exception {

		// doit décoder la chaine en base64

		byte[] dechiffre = Base64.getDecoder().decode(textChiffre);

		dechiffre = decryptInByte(dechiffre, clef);

		return new String(dechiffre); // retourne au format chaine normal
	}

	/**
	 * Junit testing for user authentification to the database
	 * 
	 * @param login
	 * @param password
	 * @return
	 * @throws SQLException
	 */
	public String connectionTest(String login, String password) throws SQLException {

		String conclusion = null;

		Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/supercarjava", "root",
				"");

		PreparedStatement st = (PreparedStatement) connection
				.prepareStatement("Select * from login where USERNAME=? and PWD=?");

		st.setString(1, login);
		st.setString(2, hashPassword(password));

		ResultSet rs = st.executeQuery();
		if (rs.next()) {
			conclusion = "user exist";
		} else {
			conclusion = "user does not exist";
		}

		return conclusion;
	}

	/**
	 * method that connect into the MySql database and establish a connection to
	 * open the program if the type is "login" then it will compare the user and
	 * password input to data in the database if it exists and it's verified the
	 * user will be connected the user into the Dashboard (Connected.java)
	 * 
	 * if type is "change" it will update the user Password and disconnect the user
	 * 
	 * else it will pull the information of the authentified user from database with
	 * the help of his login
	 * 
	 * @param login    : login of the user
	 * @param password : password
	 * @param type     : login page or else
	 * @param frame
	 * @author gregb
	 */
	public void DatabaseConnexion(String login, String password, String type, JFrame frame) {
		if (type == "login") {
			try {
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/supercarjava",
						"root", "");

				PreparedStatement st = (PreparedStatement) connection
						.prepareStatement("Select * from login where USERNAME=? and PWD=?");

				st.setString(1, login);
				st.setString(2, getPassword());

				ResultSet rs = st.executeQuery();
				if (rs.next()) {
					frame.setVisible(false);
					Dashboard.main(login);
				} else {
					JOptionPane.showMessageDialog(null, "erreur, login ou mot de passe invalide");
					frame.setVisible(false);
					Login.main(null);
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "erreur impossible de se connecter au serveur");
				frame.setVisible(false);
			}
		}
		if (type == "change") {
			try {
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/supercarjava",
						"root", "");

				PreparedStatement st = (PreparedStatement) connection
						.prepareStatement("UPDATE `login` SET `PWD`=?  WHERE `USERNAME`=?");

				st.setString(1, password);
				st.setString(2, login);

				st.executeUpdate();

				JOptionPane.showMessageDialog(null, "mot de passe modifié,vous allez maintenant etre deconnecté");
				frame.setVisible(false);
				Login.main(null);

			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "erreur impossible de modifier le mot de passe");
				frame.setVisible(false);
			}

		} else {
			try {
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/supercarjava",
						"root", "");

				PreparedStatement st = (PreparedStatement) connection.prepareStatement(
						"Select * from login,employe,dept where USERNAME=? and login.ID_EMPLOYE = employe.ID_EMPLOYE AND employe.ID_DEPT = dept.ID_DEPT");

				st.setString(1, login);

				ResultSet rs = st.executeQuery();
				if (rs.next()) {
					setAccountType(rs.getString("login.TYPE"));
					setId(rs.getString("employe.ID_EMPLOYE"));
					name = rs.getString("PRENOM");
					surname = rs.getString("NOM");
					dept = rs.getString("dept.NOM");
					setPassword(rs.getString("PWD"));
					decryptKey();
					setSalary(decryptInString(rs.getString("SALAIRE"), getMasterKey()));
				} else {
					Login.main(null);
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "erreur impossible de se connecter au serveur");
				Login.main(null);
			}
		}
	}
}
