package supercar.login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;

/**
 * Class ChangePassword : change password GUI
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
public class ChangePassword {

	private JFrame frame;
	private JPasswordField newPwd;
	private JPasswordField oldPwd;
	private static final String PASSWORD_PATTERN = "\\A(?=\\S*?[0-9])(?=\\S*?[a-z])(?=\\S*?[A-Z])(?=\\S*?[?!@#$%^&+=])\\S{12,}\\z";
	private JPasswordField confirmPwd;
	private AdminAccount account = new AdminAccount();
	private AdminAccount change = new AdminAccount();
	private Pattern pattern;
	private Matcher matcher;
	private JFrame errorFrame;
	private JLabel lblTitle;
	private JLabel lblPwd;
	private JButton btnChanger;
	private JLabel lblPhoto;
	private JButton btnRetour;
	private JLabel lblOld;
	private JLabel lblConfirmPwd;
	private int dialogButton;
	private int dialogResult;

	/**
	 * Launch the application.
	 * @param login : login of the authentified user
	 */
	public static void main(String login) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChangePassword window = new ChangePassword(login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 
	 * Method that will compare the database password with the hash of oldPwd
	 * TextField :
	 * 
	 * if they are the same then it will compare the new password and the confirm
	 * password and the password has all the requirements :
	 * 
	 * if the are the same then it will change the password into the database and
	 * disconnect the user using the AdminAccount's method DatabaseConnection
	 * 
	 * @param login : login of the authentified user
	 */
	public void changePwd(String login) {
		pattern = Pattern.compile(PASSWORD_PATTERN);
		if (account.getPassword().equals(account.hashPassword((String.copyValueOf(oldPwd.getPassword()))))) {
			change.setPassword((String.copyValueOf(newPwd.getPassword())));
			matcher = pattern.matcher(change.getPassword());
			change.setPassword(change.hashPassword(change.getPassword()));
			if (change.getPassword().equals(change.hashPassword((String.copyValueOf(confirmPwd.getPassword()))))) {
				if ((matcher.matches()) == false || change.getPassword().equalsIgnoreCase("")) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame,
							"erreur, nouveau mot de passe invalide (au moins un chiffre, une lettre en capitale, un charactere special(?!@#$%^&+=) et min 12 characteres");
				} else {
					try {
						change.DatabaseConnexion(login, change.getPassword(), "change", ChangePassword.this.frame);
					} catch (Exception sqlException) {
						sqlException.printStackTrace();
					}
				}
			} else {
				errorFrame = new JFrame("error");
				JOptionPane.showMessageDialog(errorFrame, "Les deux mots de passe ne se correspondent pas...");
			}

		} else {
			errorFrame = new JFrame("error");
			JOptionPane.showMessageDialog(errorFrame, "l'ancien mot de passe n'est pas valide");
		}
	}

	/**
	 * Create the application.
	 * @param login : login of the authentified user
	 */
	public ChangePassword(String login) {
		initialize(login);
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * PasswordField (newPwd) new pwd : new password input
	 * 
	 * PasswordField (oldPwd) old pwd : old password input
	 * 
	 * PasswordField (confirmPwd) confirm : confirm new password input
	 * 
	 * Button (btnChanger) changer : change the password
	 * 
	 * Button (btnAnnuler) annuler : cancel the changing password and return to
	 * 'Dashboard' page
	 * 
	 */
	private void initialize(String login) {
		account.DatabaseConnexion(login, null, null, frame);
		frame = new JFrame();
		frame.setBounds(100, 100, 673, 411);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		lblTitle = new JLabel("SuperCar");
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setBounds(201, 25, 249, 64);
		frame.getContentPane().add(lblTitle);

		lblPwd = new JLabel("NEW PWD");
		lblPwd.setHorizontalAlignment(SwingConstants.CENTER);
		lblPwd.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPwd.setBounds(10, 190, 88, 32);
		frame.getContentPane().add(lblPwd);

		btnChanger = new JButton("changer");
		btnChanger.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				changePwd(login);
			}
		});
		btnChanger.setBounds(452, 340, 119, 21);
		frame.getContentPane().add(btnChanger);

		newPwd = new JPasswordField();
		newPwd.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					changePwd(login);
				}
			}
		});
		newPwd.setBounds(108, 190, 342, 32);
		frame.getContentPane().add(newPwd);

		lblPhoto = new JLabel("");
		lblPhoto.setIcon(new ImageIcon(ChangePassword.class.getResource("/client.png")));
		lblPhoto.setHorizontalAlignment(SwingConstants.CENTER);
		lblPhoto.setBounds(444, 132, 184, 116);
		frame.getContentPane().add(lblPhoto);

		btnRetour = new JButton("retour");
		btnRetour.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				dialogButton = JOptionPane.YES_NO_OPTION;
				dialogResult = JOptionPane.showConfirmDialog(null,
						"Souhaitez-vous vraiment annuler " + account.name + " ?", "Warning", dialogButton);
				if (dialogResult == JOptionPane.YES_OPTION) {
					ChangePassword.this.frame.setVisible(false);
					Dashboard.main(login);
				}
			}
		});
		btnRetour.setBounds(161, 340, 119, 21);
		frame.getContentPane().add(btnRetour);

		lblOld = new JLabel("OLD PWD");
		lblOld.setHorizontalAlignment(SwingConstants.CENTER);
		lblOld.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblOld.setBounds(10, 120, 88, 32);
		frame.getContentPane().add(lblOld);

		oldPwd = new JPasswordField();
		oldPwd.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					changePwd(login);
				}
			}
		});
		oldPwd.setBounds(108, 120, 342, 32);
		frame.getContentPane().add(oldPwd);

		lblConfirmPwd = new JLabel("CONFIRM");
		lblConfirmPwd.setHorizontalAlignment(SwingConstants.CENTER);
		lblConfirmPwd.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblConfirmPwd.setBounds(10, 260, 88, 32);
		frame.getContentPane().add(lblConfirmPwd);

		confirmPwd = new JPasswordField();
		confirmPwd.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					changePwd(login);
				}
			}
		});
		confirmPwd.setBounds(108, 260, 342, 32);
		frame.getContentPane().add(confirmPwd);
	}
}
