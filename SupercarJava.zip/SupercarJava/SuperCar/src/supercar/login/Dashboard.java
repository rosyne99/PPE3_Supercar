package supercar.login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import supercar.dept.recrutement;
import supercar.admin.Admin;
import supercar.dept.calculate_salary;
import supercar.dept.dept;
import supercar.dept.supercaremployee;
import supercar.client.ClientGUI;
import supercar.commande.CommandesGUI;
import supercar.fournisseur.MarqueGUI;
import supercar.modele.ModeleGUI;
import supercar.options.OptionsGUI;
import supercar.rapport.RapportGUI;
import supercar.stock.StockGUI;
import supercar.vente.VenteGUI;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Class Dashboard
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
public class Dashboard {

	private JFrame frame;
	private AdminAccount account = new AdminAccount();
	private JLabel lblHome;
	private JLabel lblconnected;
	private JLabel lblMessage;
	private JButton btnLogOut;
	private JButton btnEdit;
	private JButton btnRapportDeVente;
	private JButton btnClient;
	private JButton btnListeDesModeles;
	private JButton btnCommande;
	private JButton btnFournisseur;
	private JButton btnRapportFinancierMensuel;
	private JButton btnListeComptes;
	private JButton btnOptions;
	private int dialogButton;
	private int dialogResult;
	private JButton btnDept;
	private JButton btnListeEmploye;
	private JButton btnFicheSalaire;
	private JButton btnTodolist;

	/**
	 * Launch the application.
	 * 
	 * @param login : login of the authentified user
	 * 
	 */
	public static void main(String login) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dashboard window = new Dashboard(login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * 
	 * @param login : login of the authentified user
	 */
	public Dashboard(String login) {
		initialize(login);
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * 'account.DatabaseConnexion' that will help for the authenticated to see all
	 * of his informations / disconnnect if the user is not in the database.
	 * 
	 * 
	 * If the user account dept is 'vente' then :
	 * 
	 * - Button (btnRapportDeVente) rapport de vente : to see the 'vente' page
	 * 
	 * - Button (btnClient) Liste des clients : to see the 'client' page
	 * 
	 * - Button (btnListeDesModeles) Listes des modeles : to see the 'modele' page
	 * 
	 * - Button (btnCommande) Stock de Supercar : to see the 'stock' page
	 * 
	 * 
	 * 
	 * If the user account dept is 'finance' then :
	 * 
	 * - Button (btnRapportDeVente) rapport de vente : to see the 'vente' page
	 * 
	 * - Button (btnCommande) Commandes de Supercar : to see the 'commandes' page
	 * 
	 * - Button (btnRapportFinancierMensuel) rapport mensuel : to see the 'rapport'
	 * page
	 * 
	 * 
	 * 
	 * If the user account dept is 'stock' then :
	 * 
	 * - Button (btnListeDesModeles) Listes des modeles : to see the 'modele' page
	 * 
	 * - Button (btnCommande) Stock de Supercar : to see the 'stock' page
	 * 
	 * - Button (btnRapportDeVente) rapport de vente : to see the 'vente' page
	 * 
	 * 
	 * 
	 * If the user account dept is 'admin' then :
	 * 
	 * - Button (btnListeDesModeles) Listes des modeles : to see the 'modele' page
	 * 
	 * - Button (btnCommande) Stock de Supercar : to see the 'stock' page
	 * 
	 * - Button btnListeComptes (Comptes Supercar) : to see the 'admin' page
	 * 
	 * - Button btnOptions (Options Disponible) : to see the 'options' page
	 * 
	 * - Button btnFournisseur (Fournisseur/marque) : to see the 'marque' page
	 * 
	 * 
	 * button (btnEdit) changer de mot de passe? to change the password of the
	 * authentified user
	 * 
	 * button (logout) deconnexion to quit the program and log out
	 * 
	 * @param login login is the login of the authentified User
	 */

	private void initialize(String login) {
		frame = new JFrame();
		frame.setBounds(100, 100, 651, 821);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		lblHome = new JLabel("");
		lblHome.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblHome.setHorizontalAlignment(SwingConstants.CENTER);
		lblHome.setBounds(10, 38, 333, 46);
		frame.getContentPane().add(lblHome);

		lblconnected = new JLabel("");
		lblconnected.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblconnected.setHorizontalAlignment(SwingConstants.RIGHT);
		lblconnected.setBounds(364, 38, 261, 22);
		frame.getContentPane().add(lblconnected);
		account.DatabaseConnexion(login, null, null, frame);
		lblconnected.setText("Bonjour," + account.name + " " + account.surname);

		lblMessage = new JLabel("Que souhaitez-vous consulter?");

		lblMessage.setHorizontalAlignment(SwingConstants.RIGHT);
		lblMessage.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMessage.setBounds(364, 56, 261, 22);
		frame.getContentPane().add(lblMessage);

		btnLogOut = new JButton("Déconnexion");
		btnLogOut.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				dialogButton = JOptionPane.YES_NO_OPTION;
				dialogResult = JOptionPane.showConfirmDialog(null,
						"Souhaitez-vous vraiment vous déconnecter " + account.name + " ?", "Warning", dialogButton);
				if (dialogResult == JOptionPane.YES_OPTION) {
					Dashboard.this.frame.setVisible(false);
					Login.main(null);
				}
			}
		});
		btnLogOut.setBounds(251, 733, 123, 26);
		frame.getContentPane().add(btnLogOut);

		btnEdit = new JButton("Changer de mot de passe?");
		btnEdit.setFont(new Font("Dialog", Font.BOLD, 9));
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				ChangePassword.main(login);
			}
		});
		btnEdit.setBounds(419, 82, 204, 26);
		frame.getContentPane().add(btnEdit);

		if (account.dept.contains("VENTE")) {

			lblHome.setText("Vente");

			btnRapportDeVente = new JButton("Rapport de Vente");
			btnRapportDeVente.setHorizontalTextPosition(SwingConstants.CENTER);
			btnRapportDeVente.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnRapportDeVente.setIcon(new ImageIcon(Dashboard.class.getResource("/sale.png")));
			btnRapportDeVente.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					VenteGUI.main(login);
				}
			});
			btnRapportDeVente.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnRapportDeVente.setBounds(55, 126, 213, 166);
			frame.getContentPane().add(btnRapportDeVente);

			btnClient = new JButton("Liste des Clients");
			btnClient.setIcon(new ImageIcon(Dashboard.class.getResource("/client.png")));
			btnClient.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnClient.setHorizontalTextPosition(SwingConstants.CENTER);
			btnClient.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					ClientGUI.main(login);
				}
			});
			btnClient.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnClient.setBounds(360, 126, 213, 166);
			frame.getContentPane().add(btnClient);

			btnListeDesModeles = new JButton("Liste des modèles");
			btnListeDesModeles.setHorizontalTextPosition(SwingConstants.CENTER);
			btnListeDesModeles.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnListeDesModeles.setIcon(new ImageIcon(Dashboard.class.getResource("/car.png")));
			btnListeDesModeles.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					ModeleGUI.main(login);
				}
			});
			btnListeDesModeles.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnListeDesModeles.setBounds(55, 351, 213, 166);
			frame.getContentPane().add(btnListeDesModeles);

			btnCommande = new JButton("Stock de Supercar");
			btnCommande.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnCommande.setIcon(new ImageIcon(Dashboard.class.getResource("/inventory.png")));
			btnCommande.setHorizontalTextPosition(SwingConstants.CENTER);
			btnCommande.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					StockGUI.main(login);
				}
			});
			btnCommande.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnCommande.setBounds(360, 345, 213, 166);
			frame.getContentPane().add(btnCommande);

			btnFournisseur = new JButton("Fournisseurs/ Marque");
			btnFournisseur.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					MarqueGUI.main(login);
				}
			});
			btnFournisseur.setIcon(new ImageIcon(Dashboard.class.getResource("/shake.png")));
			btnFournisseur.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnFournisseur.setHorizontalTextPosition(SwingConstants.CENTER);
			btnFournisseur.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnFournisseur.setBounds(208, 555, 213, 166);
			frame.getContentPane().add(btnFournisseur);
		}

		if (account.dept.contains("FINANCE")) {
			lblHome.setText("Département Finance");

			btnRapportDeVente = new JButton("Rapport de Vente");
			btnRapportDeVente.setHorizontalTextPosition(SwingConstants.CENTER);
			btnRapportDeVente.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnRapportDeVente.setIcon(new ImageIcon(Dashboard.class.getResource("/sale.png")));
			btnRapportDeVente.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					VenteGUI.main(login);
				}
			});
			btnRapportDeVente.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnRapportDeVente.setBounds(55, 126, 213, 166);
			frame.getContentPane().add(btnRapportDeVente);

			btnCommande = new JButton("Commandes ");
			btnCommande.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnCommande.setIcon(new ImageIcon(Dashboard.class.getResource("/order.png")));
			btnCommande.setHorizontalTextPosition(SwingConstants.CENTER);
			btnCommande.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					CommandesGUI.main(login);
				}
			});
			btnCommande.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnCommande.setBounds(204, 343, 221, 174);
			frame.getContentPane().add(btnCommande);

			btnRapportFinancierMensuel = new JButton("Rapport Mensuel");
			btnRapportFinancierMensuel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					RapportGUI.main(login);
				}
			});
			btnRapportFinancierMensuel.setIcon(new ImageIcon(Dashboard.class.getResource("/reports.png")));
			btnRapportFinancierMensuel.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnRapportFinancierMensuel.setHorizontalTextPosition(SwingConstants.CENTER);
			btnRapportFinancierMensuel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnRapportFinancierMensuel.setBounds(360, 126, 213, 166);
			frame.getContentPane().add(btnRapportFinancierMensuel);

		}

		if (account.dept.contains("STOCK")) {

			btnRapportDeVente = new JButton("Rapport de Vente");
			btnRapportDeVente.setHorizontalTextPosition(SwingConstants.CENTER);
			btnRapportDeVente.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnRapportDeVente.setIcon(new ImageIcon(Dashboard.class.getResource("/sale.png")));
			btnRapportDeVente.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					VenteGUI.main(login);
				}
			});
			btnRapportDeVente.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnRapportDeVente.setBounds(200, 451, 213, 166);
			frame.getContentPane().add(btnRapportDeVente);

			lblHome.setText("ENTREPOT");
			btnListeDesModeles = new JButton("Liste des modèles");
			btnListeDesModeles.setHorizontalTextPosition(SwingConstants.CENTER);
			btnListeDesModeles.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnListeDesModeles.setIcon(new ImageIcon(Dashboard.class.getResource("/car.png")));
			btnListeDesModeles.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					ModeleGUI.main(login);
				}
			});
			btnListeDesModeles.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnListeDesModeles.setBounds(56, 218, 213, 166);
			frame.getContentPane().add(btnListeDesModeles);

			btnCommande = new JButton("Stock de Supercar");
			btnCommande.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnCommande.setIcon(new ImageIcon(Dashboard.class.getResource("/inventory.png")));
			btnCommande.setHorizontalTextPosition(SwingConstants.CENTER);
			btnCommande.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					StockGUI.main(login);
				}
			});
			btnCommande.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnCommande.setBounds(364, 218, 213, 166);
			frame.getContentPane().add(btnCommande);

		}
		if (account.dept.contains("ADMIN")) {
			lblHome.setText("Administration");

			btnListeDesModeles = new JButton("Liste des modèles");
			btnListeDesModeles.setHorizontalTextPosition(SwingConstants.CENTER);
			btnListeDesModeles.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnListeDesModeles.setIcon(new ImageIcon(Dashboard.class.getResource("/car.png")));
			btnListeDesModeles.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					ModeleGUI.main(login);
				}
			});
			btnListeDesModeles.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnListeDesModeles.setBounds(56, 132, 213, 166);
			frame.getContentPane().add(btnListeDesModeles);

			btnCommande = new JButton("Stock de Supercar");
			btnCommande.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnCommande.setIcon(new ImageIcon(Dashboard.class.getResource("/inventory.png")));
			btnCommande.setHorizontalTextPosition(SwingConstants.CENTER);
			btnCommande.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					StockGUI.main(login);
				}
			});
			btnCommande.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnCommande.setBounds(364, 132, 213, 166);
			frame.getContentPane().add(btnCommande);

			btnOptions = new JButton("Options disponibles");
			btnOptions.setIcon(new ImageIcon(Dashboard.class.getResource("/option.png")));
			btnOptions.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					OptionsGUI.main(login);
				}
			});
			btnOptions.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnOptions.setHorizontalTextPosition(SwingConstants.CENTER);
			btnOptions.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnOptions.setBounds(364, 330, 213, 166);
			frame.getContentPane().add(btnOptions);

			btnFournisseur = new JButton("Fournisseurs/ Marque");
			btnFournisseur.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					MarqueGUI.main(login);
				}
			});
			btnFournisseur.setIcon(new ImageIcon(Dashboard.class.getResource("/shake.png")));
			btnFournisseur.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnFournisseur.setHorizontalTextPosition(SwingConstants.CENTER);
			btnFournisseur.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnFournisseur.setBounds(56, 330, 213, 166);
			frame.getContentPane().add(btnFournisseur);
			
			btnDept = new JButton("Département");
			btnDept.setIcon(new ImageIcon(Dashboard.class.getResource("/dept.jpg")));
			btnDept.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					dept.main(login);
				}
			});
			
			btnDept.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnDept.setHorizontalTextPosition(SwingConstants.CENTER);
			btnDept.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnDept.setBounds(216, 529, 213, 166);
			frame.getContentPane().add(btnDept);

		}
		
		if (account.dept.contains("RH")) {
			lblHome.setText("Ressource Humaines");
			
			btnDept = new JButton("Département");
			btnDept.setIcon(new ImageIcon(Dashboard.class.getResource("/dept.jpg")));
			btnDept.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					dept.main(login);
				}
			});
			
			btnDept.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnDept.setHorizontalTextPosition(SwingConstants.CENTER);
			btnDept.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnDept.setBounds(390, 445, 213, 166);
			frame.getContentPane().add(btnDept);
			
			btnListeEmploye = new JButton("Employé Supercar");
			btnListeEmploye.setIcon(new ImageIcon(Dashboard.class.getResource("/client.png")));
			btnListeEmploye.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Dashboard.this.frame.setVisible(false);
					supercaremployee.main(login);
					
				}
			});
			btnListeEmploye.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnListeEmploye.setHorizontalTextPosition(SwingConstants.CENTER);
			btnListeEmploye.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnListeEmploye.setBounds(25, 182, 213, 166);
			frame.getContentPane().add(btnListeEmploye);
			
			btnFicheSalaire = new JButton("Fiche de paie");
			btnFicheSalaire.setIcon(new ImageIcon(Dashboard.class.getResource("/pays.jpg")));
			btnFicheSalaire.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Dashboard.this.frame.setVisible(false);
					calculate_salary.main(login);
				}
			});
			btnFicheSalaire.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnFicheSalaire.setHorizontalTextPosition(SwingConstants.CENTER);
			btnFicheSalaire.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnFicheSalaire.setBounds(390, 182, 213, 166);
			frame.getContentPane().add(btnFicheSalaire);
			
			btnTodolist = new JButton("To-do List");
			btnTodolist.setIcon(new ImageIcon(Dashboard.class.getResource("/a.jpg")));
			btnTodolist.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Dashboard.this.frame.setVisible(false);
					recrutement.main(login);
				}
			});
			btnTodolist.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnTodolist.setHorizontalTextPosition(SwingConstants.CENTER);
			btnTodolist.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnTodolist.setBounds(25, 445, 213, 166);
			frame.getContentPane().add(btnTodolist);

		}
		if (account.dept.contains("IT")) {
			lblHome.setText("Informatique");
			btnListeComptes = new JButton("Comptes Supercar");
			btnListeComptes.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnListeComptes.setIcon(new ImageIcon(Dashboard.class.getResource("/client.png")));
			btnListeComptes.setHorizontalTextPosition(SwingConstants.CENTER);
			btnListeComptes.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (account.getAccountType().contains("3")) {
						frame.setVisible(false);
						Admin.main(login);
					}
				}
			});
			btnListeComptes.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
			btnListeComptes.setBounds(204, 342, 213, 166);
			frame.getContentPane().add(btnListeComptes);
			
		}
	}
}
