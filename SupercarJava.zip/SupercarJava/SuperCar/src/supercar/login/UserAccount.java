package supercar.login;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * Class UserAccount
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
public class UserAccount {
	private static final String PASSWORD_PATTERN = "\\A(?=\\S*?[0-9])(?=\\S*?[a-z])(?=\\S*?[A-Z])(?=\\S*?[?!@#$%^&+=])\\S{12,}\\z";
	public String name;
	public String surname;
	public String login;
	public String dept;
	private String password;
	private String accountType;
	private String id;
	private String salary;

	/**
	 * getter method for password
	 * 
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * setter method for password
	 * 
	 * @param textPwd
	 */
	public void setPassword(String textPwd) {
		this.password = textPwd;
	}

	/**
	 * getter method for id
	 * 
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * setter method for id
	 * 
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * getter method for accountType (1 == salarié, 2 == manager, 3 == admin)
	 * 
	 * @return accountType
	 */
	public String getAccountType() {
		return accountType;
	}

	/**
	 * setter method for accountType
	 * 
	 * @param accountType
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	/**
	 * getter method for salary
	 * 
	 * @return salary
	 */
	public String getSalary() {
		return salary;
	}

	/**
	 * setter method for salary
	 * 
	 * @param salary
	 */
	public void setSalary(String salary) {
		this.salary = salary;
	}

	/**
	 * method that verify every variables used to created a new account using
	 * pattern if one of the variable is wrong, verification is "true", the user
	 * will need to correct his mistakes otherwise the data are saved in the
	 * database
	 * 
	 * @return error
	 */
	public boolean verification(String type) {
		boolean error = false;
		Pattern pattern = Pattern.compile(PASSWORD_PATTERN);
		Matcher matcher;
		matcher = pattern.matcher(password);

		if (Pattern.matches("[a-z]*", name.substring(1, name.length())) == false
				|| Pattern.matches("[A-Z]", name.substring(0, 1)) == false || name.equalsIgnoreCase("")) {
			JFrame frame = new JFrame("error");
			JOptionPane.showMessageDialog(frame, "erreur, prénom invalide (Xxxxx)");
			error = true;
		}
		if (Pattern.matches("[a-z]*", surname.substring(1, surname.length())) == false
				|| Pattern.matches("[A-Z]", surname.substring(0, 1)) == false || surname.equalsIgnoreCase("")) {
			JFrame frame = new JFrame("error");
			JOptionPane.showMessageDialog(frame, "erreur,  nom invalide (Xxxxx)");
			error = true;
		}
		if (Pattern.matches("^[a-z0-9-.]+@[a-z0-9]+\\.[a-z0-9-.]+$", login) == false || login.equalsIgnoreCase("")) {
			error = true;
			JFrame frame = new JFrame("error");
			JOptionPane.showMessageDialog(frame, "erreur,login invalide (xxxx@xxx.com");
		}
		if ((matcher.matches()) == false || password.equalsIgnoreCase("")) {
			error = true;
			JFrame frame = new JFrame("error");
			JOptionPane.showMessageDialog(frame,
					"erreur mot de passe invalide (au moins un chiffre, une lettre en capitale et un charactere special et min 12 characteres");
		}
		if (Pattern.matches("\\d+(\\.\\d{1,2})?", getSalary()) == false || getSalary().equalsIgnoreCase("")) {
			JFrame frame = new JFrame("error");
			JOptionPane.showMessageDialog(frame, "erreur, salaire invalide");
			error = true;

		}
		return error;
	}

	/**
	 * method that will use SHA encryption to hash a password into a hexadecimal
	 * string
	 * 
	 * @param chaine
	 * @return chaine as an hexadecimal string
	 */
	public String hashPassword(String chaine) {
		try {
			byte[] donneeOctet = chaine.getBytes();
			MessageDigest monHash = MessageDigest.getInstance("SHA");
			monHash.update(donneeOctet);
			byte[] condenser = monHash.digest();
			chaine = new BigInteger(condenser).toString(16);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return chaine;
	}

}
