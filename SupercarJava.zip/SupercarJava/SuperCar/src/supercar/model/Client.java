package supercar.model;
/**
 * Class Client : model of Client
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
public class Client {
	private String ID_CLIENT;
	private String NOM;
	private String PRENOM;
	private String LICENCE;
	private String ADRESSE;
	private String EMAIL;
	private String TEL;
	
	/**
	 * constuctor method Client without parameters
	 */
	public Client() {
	}
	/**
	 * constuctor method Client with parameters
	 * @param nom
	 * @param prenom
	 * @param licence
	 * @param adresse
	 * @param email
	 * @param tel
	 */
	public Client(String nom,String prenom, String licence,String adresse,String email,String tel) {
		this.NOM = nom;
		this.PRENOM = prenom;
		this.LICENCE = licence;
		this.ADRESSE = adresse;
		this.EMAIL = email;
		this.TEL = tel;
	}
	/**
	 * getter method for ID_CLIENT
	 * @return ID_CLIENT
	 */
	public String getID_CLIENT() {
		return ID_CLIENT;
	}
	/**
	 * setter method for ID_CLIENT
	 * @param ID_CLIENT
	 */
	public void setID_CLIENT(String ID_CLIENT) {
		this.ID_CLIENT = ID_CLIENT;
	}
	/**
	 * getter method for NOM
	 * @return NOM
	 */
	public String getNom() {
		return NOM;
	}
	/**
	 * setter method for NOM
	 * @param NOM
	 */
	public void setNom(String NOM) {
		this.NOM = NOM;
	}
	/**
	 * getter method for PRENOM
	 * @return PRENOM
	 */
	public String getPrenom() {
		return PRENOM;
	}
	/**
	 * setter method for PRENOM
	 * @param PRENOM
	 */
	public void setPrenom(String PRENOM) {
		this.PRENOM = PRENOM;
	}
	/**
	 * getter method for LICENCE
	 * @return LICENCE
	 */
	public String getLicence() {
		return LICENCE;
	}
	/**
	 * setter method for LICENSE
	 * @param LICENCE
	 */
	public void setLicence(String LICENCE) {
		this.LICENCE = LICENCE;
	}
	/**
	 * getter method for ADRESSE
	 * @return ADRESSE
	 */
	public String getAdresse() {
		return ADRESSE;
	}
	/**
	 * setter method for ADRESSE
	 * @param ADRESSE
	 */
	public void setAdresse(String ADRESSE) {
		this.ADRESSE = ADRESSE;
	}
	/**
	 * getter method for EMAIL
	 * @return EMAIl
	 */
	public String getEmail() {
		return EMAIL;
	}
	/**
	 * setter method for EMAIL
	 * @param EMAIL
	 */
	public void setEmail(String EMAIL) {
		this.EMAIL = EMAIL;
	}
	/**
	 * getter method for TEL
	 * @return TEL
	 */
	public String getTel() {
		return TEL;
	}
	/**
	 * setter method for TEL
	 * @param TEL
	 */
	public void setTel(String TEL) {
		this.TEL = TEL;
	}
}
