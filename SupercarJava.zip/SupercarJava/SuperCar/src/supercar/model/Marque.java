package supercar.model;

/**
 * Class Marque : model of Marque
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */

public class Marque {
	private String ID_MARQUE;
	private String NOM;
	private String ORIGINE;
	private String FOURNISSEUR;
	private String CONTACT;
	private String EMAIL;

	/**
	 * constuctor method Marque without parameters
	 */
	public Marque() {
	}

	/**
	 * constuctor method Marque with parameters
	 * 
	 * @param NOM
	 * @param ORIGINE
	 * @param FOURNISSEUR
	 * @param CONTACT
	 * @param EMAIL
	 */
	public Marque(String NOM, String ORIGINE, String FOURNISSEUR, String CONTACT, String EMAIL) {
		this.NOM = NOM;
		this.ORIGINE = ORIGINE;
		this.FOURNISSEUR = FOURNISSEUR;
		this.CONTACT = CONTACT;
		this.EMAIL = EMAIL;
	}

	/**
	 * getter method for ID_MARQUE
	 * 
	 * @return ID_MARQUE
	 */
	public String getID_MARQUE() {
		return ID_MARQUE;
	}

	/**
	 * setter method for ID_MARQUE
	 * 
	 * @param ID_MARQUE
	 */
	public void setID_MARQUE(String ID_MARQUE) {
		this.ID_MARQUE = ID_MARQUE;
	}

	/**
	 * getter method for NOM
	 * 
	 * @return NOM
	 */
	public String getNom() {
		return NOM;
	}

	/**
	 * setter method for NOM
	 * 
	 * @param NOM
	 */
	public void setNom(String NOM) {
		this.NOM = NOM;
	}

	/**
	 * getter method for ORIGINE
	 * 
	 * @return ORIGINE
	 */
	public String getOrigine() {
		return ORIGINE;
	}

	/**
	 * setter method for ORIGINE
	 * 
	 * @param ORIGINE
	 */
	public void setOrigine(String ORIGINE) {
		this.ORIGINE = ORIGINE;
	}

	/**
	 * getter method for FOURNISSEUR
	 * 
	 * @return FOURNISSEUR
	 */
	public String getFournisseur() {
		return FOURNISSEUR;
	}

	/**
	 * setter method for FOURNISSEUR
	 * 
	 * @param FOURNISSEUR
	 */
	public void setFournisseur(String FOURNISSEUR) {
		this.FOURNISSEUR = FOURNISSEUR;
	}

	/**
	 * getter method for CONTACT
	 * 
	 * @return CONTACT
	 */
	public String getContact() {
		return CONTACT;
	}

	/**
	 * setter method for CONTACT
	 * 
	 * @param CONTACT
	 */
	public void setContact(String CONTACT) {
		this.CONTACT = CONTACT;
	}

	/**
	 * getter method for EMAIL
	 * 
	 * @return EMAIL
	 */
	public String getEmail() {
		return EMAIL;
	}

	/**
	 * setter method for EMAIL
	 * 
	 * @param EMAIL
	 */
	public void setEmail(String EMAIL) {
		this.EMAIL = EMAIL;
	}
}
