package supercar.model;

/**
 * Class Modele : model of Modele
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */

public class Modele {
	private String ID_MODELE;
	private String ID_MARQUE;
	private String NOM;
	private String COULEUR;
	private String MOTEUR;
	private String BV;
	private String PRIX;

	/**
	 * constuctor method Modele without parameters
	 */
	public Modele() {

	}

	/**
	 * constructor method Modele without parameters
	 * 
	 * @param ID_MARQUE
	 * @param NOM
	 * @param COULEUR
	 * @param MOTEUR
	 * @param BV
	 * @param PRIX
	 */
	public Modele(String ID_MARQUE, String NOM, String COULEUR, String MOTEUR, String BV, String PRIX) {
		this.ID_MARQUE = ID_MARQUE;
		this.NOM = NOM;
		this.COULEUR = COULEUR;
		this.MOTEUR = MOTEUR;
		this.BV = BV;
		this.PRIX = PRIX;
	}

	/**
	 * getter method for ID_MODELE
	 * 
	 * @return ID_MODELE
	 */
	public String getID_MODELE() {
		return ID_MODELE;
	}

	/**
	 * setter method for ID_MODELE
	 * 
	 * @param iD_MODELE
	 */
	public void setID_MODELE(String iD_MODELE) {
		ID_MODELE = iD_MODELE;
	}

	/**
	 * getter method for ID_MARQUE
	 * 
	 * @return ID_MARQUE
	 */
	public String getID_MARQUE() {
		return ID_MARQUE;
	}

	/**
	 * setter method for ID_MARQUE
	 * 
	 * @param iD_MARQUE
	 */
	public void setID_MARQUE(String iD_MARQUE) {
		ID_MARQUE = iD_MARQUE;
	}

	/**
	 * getter method for NOM
	 * 
	 * @return NOM
	 */
	public String getNOM() {
		return NOM;
	}

	/**
	 * setter method for NOM
	 * 
	 * @param nOM
	 */
	public void setNOM(String nOM) {
		NOM = nOM;
	}

	/**
	 * getter method for COULEUR
	 * 
	 * @return COULEUR
	 */
	public String getCOULEUR() {
		return COULEUR;
	}

	/**
	 * setter method for COULEUR
	 * 
	 * @param cOULEUR
	 */
	public void setCOULEUR(String cOULEUR) {
		COULEUR = cOULEUR;
	}

	/**
	 * getter method for MOTEUR
	 * 
	 * @return MOTEUR
	 */
	public String getMOTEUR() {
		return MOTEUR;
	}

	/**
	 * setter method for MOTEUR
	 * 
	 * @param mOTEUR
	 */
	public void setMOTEUR(String mOTEUR) {
		MOTEUR = mOTEUR;
	}

	/**
	 * getter method for BV
	 * 
	 * @return BV
	 */
	public String getBV() {
		return BV;
	}

	/**
	 * setter method for BV
	 * 
	 * @param bV
	 */
	public void setBV(String bV) {
		BV = bV;
	}

	/**
	 * getter method for PRIX
	 * 
	 * @return PRIX
	 */
	public String getPRIX() {
		return PRIX;
	}

	/**
	 * setter method for PRIX
	 * 
	 * @param pRIX
	 */
	public void setPRIX(String pRIX) {
		PRIX = pRIX;
	}

}
