package supercar.model;

/**
 * Class Options : model of Options
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */

public class Options {
	private String ID_OPTIONS;
	private String nomOptions;
	private String detailOptions;
	private String prixOptions;
	private String typeOptions;

	/**
	 * constuctor method Options without parameters
	 */
	public Options() {

	}

	/**
	 * constuctor method Options with parameters
	 * 
	 * @param nomOptions
	 * @param detailOptions
	 * @param prixOptions
	 * @param Options
	 */
	public Options(String nomOptions, String detailOptions, String prixOptions, String Options) {
		this.nomOptions = nomOptions;
		this.detailOptions = detailOptions;
		this.prixOptions = prixOptions;
		this.typeOptions = Options;
	}

	/**
	 * getter method for ID_OPTIONS
	 * 
	 * @return ID_OPTIONS
	 */
	public String getID_OPTIONS() {
		return this.ID_OPTIONS;
	}

	/**
	 * setter method for ID_OPTIONS
	 * 
	 * @param ID_OPTIONS
	 */
	public void setID_OPTIONS(String ID_OPTIONS) {
		this.ID_OPTIONS = ID_OPTIONS;
	}

	/**
	 * getter method for NomOptions
	 * 
	 * @return NomOptions
	 */
	public String getNomOptions() {
		return this.nomOptions;
	}

	/**
	 * setter method for nomOptions
	 * 
	 * @param nomOptions
	 */
	public void setNomOptions(String nomOptions) {
		this.nomOptions = nomOptions;
	}

	/**
	 * getter method for detailOptions
	 * 
	 * @return detailsOptions
	 */
	public String getDetailOptions() {
		return this.detailOptions;
	}

	/**
	 * setter method for detailOptions
	 * 
	 * @param detailOptions
	 */
	public void setDetailOptions(String detailOptions) {
		this.detailOptions = detailOptions;
	}

	/**
	 * getter method for prixOptions
	 * 
	 * @return prixOptions
	 */
	public String getPrixOptions() {
		return this.prixOptions;
	}

	/**
	 * setter method for prixOptions
	 * 
	 * @param prixOptions
	 */
	public void setPrixOptions(String prixOptions) {
		this.prixOptions = prixOptions;
	}

	/**
	 * getter method for typeOptions
	 * 
	 * @return typeOptions
	 */
	public String getTypeOptions() {
		return this.typeOptions;
	}

	/**
	 * setter method for typeOptions
	 * 
	 * @param typeOptions
	 */
	public void setTypeOptions(String typeOptions) {
		this.typeOptions = typeOptions;
	}
}
