package supercar.model;

/**
 * Class Stock : model of Stock
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */

public class Stock {
	private String ID_STOCK;
	private String ID_MODELE;
	private String ID_DEPT;
	private String STOCK;
	private String STATUT;

	/**
	 * constuctor method Stock without parameters
	 */
	public Stock() {

	}

	/**
	 * constuctor method Stock with parameters
	 * 
	 * @param ID_MODELE
	 * @param ID_DEPT
	 * @param STOCK
	 * @param STATUT
	 */
	public Stock(String ID_MODELE, String ID_DEPT, String STOCK, String STATUT) {
		this.ID_MODELE = ID_MODELE;
		this.ID_DEPT = ID_DEPT;
		this.STOCK = STOCK;
		this.STATUT = STATUT;
	}

	/**
	 * getter method for ID_STOCK
	 * 
	 * @return ID_STOCK
	 */
	public String getID_STOCK() {
		return ID_STOCK;
	}

	/**
	 * setter method for ID_STOCK
	 * 
	 * @param ID_STOCK
	 */
	public void setID_STOCK(String ID_STOCK) {
		this.ID_STOCK = ID_STOCK;
	}

	/**
	 * getter method for ID_MODELE
	 * 
	 * @return ID_MODELE
	 */
	public String getID_MODELE() {
		return ID_MODELE;
	}

	/**
	 * setter method for ID_MODELE
	 * 
	 * @param ID_MODELE
	 */
	public void setID_MODELE(String ID_MODELE) {
		this.ID_MODELE = ID_MODELE;
	}

	/**
	 * getter method for ID_DEPT
	 * 
	 * @return ID_DEPT
	 */
	public String getID_DEPT() {
		return ID_DEPT;
	}

	/**
	 * setter method for ID_DEPT
	 * 
	 * @param ID_DEPT
	 */
	public void setID_DEPT(String ID_DEPT) {
		this.ID_DEPT = ID_DEPT;
	}

	/**
	 * getter method for STOCK
	 * 
	 * @return STOCK
	 */
	public String getSTOCK() {
		return STOCK;
	}

	/**
	 * setter method for STOCK
	 * 
	 * @param STOCK
	 */
	public void setSTOCK(String STOCK) {
		this.STOCK = STOCK;
	}

	/**
	 * getter method for STATUT
	 * 
	 * @return STATUT
	 */
	public String getSTATUT() {
		return STATUT;
	}

	/**
	 * setter method for STATUT
	 * 
	 * @param STATUT
	 */
	public void setSTATUT(String STATUT) {
		this.STATUT = STATUT;
	}
}
