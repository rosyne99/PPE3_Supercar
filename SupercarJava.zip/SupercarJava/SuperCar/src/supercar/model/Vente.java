package supercar.model;

/**
 * Class Vente : model of Vente
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
public class Vente {
	private String ID_VENTE;
	private String PRIX_VENTE;
	private String ID_CLIENT;
	private String ID_EMPLOYE;
	private String ID_MODELE;
	private String ID_OPTIONS;
	private String STATUT;
	private String COMMISSION;

	/**
	 * constuctor method Vente without parameters
	 * 
	 */
	public Vente() {
	}

	/**
	 * constuctor method Vente with parameters
	 * 
	 * @param PRIX_VENTE
	 * @param ID_CLIENT
	 * @param ID_EMPLOYE
	 * @param ID_MODELE
	 * @param ID_OPTIONS
	 * @param STATUT
	 * @param COMMISSION
	 */
	public Vente(String PRIX_VENTE, String ID_CLIENT, String ID_EMPLOYE, String ID_MODELE, String ID_OPTIONS,
			String STATUT, String COMMISSION) {
		this.PRIX_VENTE = PRIX_VENTE;
		this.ID_CLIENT = ID_CLIENT;
		this.ID_EMPLOYE = ID_EMPLOYE;
		this.ID_MODELE = ID_MODELE;
		this.ID_OPTIONS = ID_OPTIONS;
		this.STATUT = STATUT;
		this.COMMISSION = COMMISSION;
	}

	/**
	 * getter method for ID_VENTE
	 * 
	 * @return ID_VENTE
	 */
	public String getID_VENTE() {
		return ID_VENTE;
	}

	/**
	 * setter method for ID_VENTE
	 * 
	 * @param ID_VENTE
	 */
	public void setID_VENTE(String ID_VENTE) {
		this.ID_VENTE = ID_VENTE;
	}

	/**
	 * getter method for PRIX_VENTE
	 * 
	 * @return PRIX_VENTE
	 */
	public String getPrix_Vente() {
		return PRIX_VENTE;
	}

	/**
	 * setter method for PRIX_VENTE
	 * 
	 * @param PRIX_VENTE
	 */
	public void setPrix_Vente(String PRIX_VENTE) {
		this.PRIX_VENTE = PRIX_VENTE;
	}

	/**
	 * getter method for ID_CLIENT
	 * 
	 * @return ID_CLIENT
	 */
	public String getID_CLIENT() {
		return ID_CLIENT;
	}

	/**
	 * setter method for ID_CLIENT
	 * 
	 * @param ID_CLIENT
	 */
	public void setID_CLIENT(String ID_CLIENT) {
		this.ID_CLIENT = ID_CLIENT;
	}

	/**
	 * getter method for ID_EMPLOYE
	 * 
	 * @return ID_EMPLOYE
	 */
	public String getID_EMPLOYE() {
		return ID_EMPLOYE;
	}

	/**
	 * setter method for ID_EMPLOYE
	 * 
	 * @param ID_EMPLOYE
	 */
	public void setID_EMPLOYE(String ID_EMPLOYE) {
		this.ID_EMPLOYE = ID_EMPLOYE;
	}

	/**
	 * getter method for ID_MODELE
	 * 
	 * @return ID_MODELE
	 */
	public String getID_MODELE() {
		return ID_MODELE;
	}

	/**
	 * setter method for ID_MODELE
	 * 
	 * @param ID_MODELE
	 */
	public void setID_MODELE(String ID_MODELE) {
		this.ID_MODELE = ID_MODELE;
	}

	/**
	 * getter method for ID_OPTIONS
	 * 
	 * @return ID_OPTIONS
	 */
	public String getID_OPTIONS() {
		return ID_OPTIONS;
	}

	/**
	 * setter method for ID_OPTIONS
	 * 
	 * @param ID_OPTIONS
	 */
	public void setID_OPTIONS(String ID_OPTIONS) {
		this.ID_OPTIONS = ID_OPTIONS;
	}

	/**
	 * getter method for STATUT
	 * 
	 * @return STATUT
	 */
	public String getStatut() {
		return STATUT;
	}

	/**
	 * setter method for STATUT
	 * 
	 * @param STATUT
	 */
	public void setStatut(String STATUT) {
		this.STATUT = STATUT;
	}

	/**
	 * getter method for COMMISSION
	 * 
	 * @return COMMISSION
	 */
	public String getCommission() {
		return COMMISSION;
	}

	/**
	 * setter method for COMMISSIOn
	 * 
	 * @param COMMISSION
	 */
	public void setCommission(String COMMISSION) {
		this.COMMISSION = COMMISSION;
	}
}
