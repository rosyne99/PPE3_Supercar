package supercar.modele;

import java.awt.EventQueue;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.EmptyStackException;
import java.util.regex.Pattern;
import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JTable;
import supercar.constants.CRUDMode;
import supercar.login.AdminAccount;
import supercar.login.Dashboard;
import supercar.model.Modele;
import supercar.utilities.DBUtilModele;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;

/**
 * class ModeleGUI : GUI for 'Modele'
 * 
 * @SuppressWarnings("rawtypes") added for JcomboBoxs warning
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
@SuppressWarnings("rawtypes")
public class ModeleGUI {

	private JFrame frame;
	private JFrame errorFrame;
	private JFrame retourFrame;
	private JTable table;
	private JLabel lblId;
	private JLabel lblModele;
	private JLabel lblNouvelModele;
	private JLabel lblMarque;
	private JLabel lblNom;
	private JLabel lblCouleur;
	private JLabel lblMoteur;
	private JLabel lblBV;
	private JLabel lblPrix;
	private Timer timer;
	private JPanel panel;
	private JScrollPane scrollPane;
	private JButton btnModifier;
	private JComboBox idDropdown;
	private JComboBox marqueDropdown;
	private JComboBox moteurDropdown;
	private JComboBox bvDropdown;
	private JButton btnAjouter;
	private JButton btnSupprimer;
	private JButton btnRetour;
	private JButton btnAnnuler;
	private static String idString;
	private static String idMarqueString;
	private static String nomString;
	private static String couleurString;
	private static String moteurString;
	private static String bvString;
	private static String prixString;
	private String marque;
	private JTextField textFieldNom;
	private JTextField textFieldCouleur;
	private JTextField textFieldPrix;
	private DBUtilModele affichage = new DBUtilModele();
	private AdminAccount account = new AdminAccount();

	/**
	 * Launch the application.
	 *  @param login : login of the Authentified User.
	 */
	public static void main(String login) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModeleGUI window = new ModeleGUI(login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Method that put all the information into the variables of the model.Modele
	 * Class for insertion or update in the Database
	 * 
	 * @param mode
	 * @return modele : Model object of class Modele
	 */
	private static Modele retrieveInputGUI(CRUDMode mode) {
		Modele modele = new Modele();
		if (mode.equals(CRUDMode.ADD) || mode.equals(CRUDMode.UPDATE)) {
			if (mode.equals(CRUDMode.UPDATE)) {
				modele.setID_MODELE(idString);
			}
			modele.setID_MARQUE(idMarqueString);
			modele.setNOM(nomString);
			modele.setCOULEUR(couleurString);
			modele.setMOTEUR(moteurString);
			modele.setBV(bvString);
			modele.setPRIX(prixString);
		} else if (mode.equals(CRUDMode.DELETE)) {
			modele.setID_MODELE(idString);
		}
		return modele;

	}

	/**
	 * Import modele database data in the table model using DBUtilMarque's method
	 * 'graphicGetAllModele'
	 * 
	 * Table composed of ("ID", "Marque", "Modele", "Couleur", "motorisation",
	 * "Boite de vitesse", "Prix HT")
	 * 
	 * @param table
	 * @throws SQLException
	 */
	public void printTableAffichage(JTable table) throws SQLException {
		affichage.graphicGetAllModele(table);
	}

	/**
	 * method that verify every variables used to update / created a 'modele' using
	 * pattern if one of the variable is wrong, verification is "true", the user
	 * will need to correct his mistakes otherwise the data are saved in the
	 * database
	 * 
	 * @param error
	 * @param type
	 * @return error
	 */
	private boolean Verification(boolean error, String type) {
		errorFrame = new JFrame();
		if (type.equals("add") || type.equals("update")) {
			if (type.equals("update")) {
				if (idString == "") {
					JOptionPane.showMessageDialog(errorFrame, "ERREUR, ID INVALIDE");
					error = true;
				}
			}
			if (idMarqueString.equalsIgnoreCase("")) {
				JOptionPane.showMessageDialog(errorFrame, "ERREUR, MARQUE INVALIDE");
				error = true;
			}
			if (bvString.equalsIgnoreCase("")) {
				JOptionPane.showMessageDialog(errorFrame, "ERREUR, BOITE DE VITESSE INVALIDE");
				error = true;
			}
			if (moteurString.equalsIgnoreCase("")) {
				JOptionPane.showMessageDialog(errorFrame, "ERREUR, MOTORISATION INVALIDE");
				error = true;
			}

			if (Pattern.matches("[a-zA-Z0-9\\s]+", nomString) == false || nomString.equalsIgnoreCase("")) {
				JOptionPane.showMessageDialog(errorFrame, "ERREUR,NOM INVALIDE");
				error = true;
			}
			if (Pattern.matches("[a-zA-Z\\s]+", couleurString) == false || couleurString.equalsIgnoreCase("")) {
				JOptionPane.showMessageDialog(errorFrame, "ERREUR,COULEUR INVALIDE");
				error = true;
			}

			if (Pattern.matches("\\d+(\\.\\d{1,2})?", prixString) == false || prixString.equalsIgnoreCase("")) {
				JFrame errorFrame = new JFrame("error");
				JOptionPane.showMessageDialog(errorFrame, "erreur, PRIX invalide");
				error = true;
			}

		}
		return error;
	}

	/**
	 * Create the application.
	 * 
	 * @throws ParseException
	 * @throws SQLException
	 *  @param login : login of the Authentified User.
	 */
	public ModeleGUI(String login) throws ParseException, SQLException {
		initialize(login);
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * 'account.DatabaseConnexion' that will help for the authenticated to see all
	 * of his informations / disconnnect if the user is not in the database.
	 * 
	 * Table (table) with auto-refresh features (the table will auto-refresh with
	 * the database every 10 seconds (10000ms) ) and row selectable for updating an
	 * existing modele.
	 *
	 * Button (btnModifier) 'Modifier' that will update a selected 'modele' to the
	 * database using the ID (if the user works in admin) if the verification
	 * doesn't give any error
	 * 
	 * Button (btnAjouter) 'Ajouter' that will add a new 'modele' to the database
	 * (if the user works in admin) if the verification doesn't give any error
	 * 
	 * Dropdown (idDropdown) 'id' that shows all the existing id in the database
	 * 
	 * Dropdown (moteurDropdown) 'motorisation' that shows all the 'motorisation'
	 * 
	 * Dropdown (bvDropdown) 'B. de vitesse' that shows all the 'bv'
	 * 
	 * Dropdown (marqueDropdown) 'motorisation' that shows all the existing 'marque'
	 * in the database
	 *
	 * TextField (textFieldNom) 'nom' that will show the model name or let the user
	 * write a modele name
	 *
	 * TextField (textFieldCouleur) 'couleur' that will show the model color or let
	 * the user write a model color
	 * 
	 * TextField (textFieldPrix) 'prix' that will show the model price or let the
	 * user write a model price
	 * 
	 * Button (btnSupprimer) 'Supprimer' that will desactivate the 'modele' to the
	 * database using the ID (if the user works in admin and is a manager) if the
	 * verification doesn't give any error
	 *
	 * Button (btnAnnuler) 'Annuler' that will clear every inputs.
	 *
	 * Button (btnRetour) 'Retour' that will make the user return into the
	 * 'Dashboard' Page.
	 * 
	 * @SuppressWarnings("rawtypes") added for JcomboBoxs warning.
	 * 
	 * @param login : login of the Authentified User.
	 * 
	 * @throws ParseException.
	 * @throws SQLException.
	 */
	private void initialize(String login) throws ParseException, SQLException {

		account.DatabaseConnexion(login, null, null, frame);
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 1366, 768);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setBounds(459, 142, 878, 483);
		frame.getContentPane().add(scrollPane);
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				int row = table.rowAtPoint(e.getPoint());
				try {
					affichage.JcomboId(idDropdown, table, row, "update");
					affichage.JcomboMarque(marqueDropdown, table, row, "update");
					affichage.JTextFieldNom(textFieldNom, table, row);
					affichage.JTextFieldCouleur(textFieldCouleur, table, row);
					affichage.JcomboMoteur(moteurDropdown, table, row, "update");
					affichage.JcomboBV(bvDropdown, table, row, "update");
					affichage.JTextFieldPrix(textFieldPrix, table, row);

				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		table.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "ID", "Marque", "Modele", "Couleur", "motorisation", "Boite de vitesse", "Prix HT" }));
		table.getColumnModel().getColumn(0).setPreferredWidth(80);
		table.getColumnModel().getColumn(1).setPreferredWidth(150);
		table.getColumnModel().getColumn(2).setPreferredWidth(150);
		table.getColumnModel().getColumn(3).setPreferredWidth(150);
		table.getColumnModel().getColumn(4).setPreferredWidth(100);
		table.getColumnModel().getColumn(5).setPreferredWidth(100);
		table.getColumnModel().getColumn(6).setPreferredWidth(150);
		table.setEnabled(false);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setCellSelectionEnabled(true);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		scrollPane.setViewportView(table);

		timer = new Timer(0, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					printTableAffichage(table);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE D'ACTUALISER LA LISTE !!");
				}
			}
		});

		timer.setDelay(10000);
		timer.start();

		panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(12, 142, 435, 483);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		lblId = new JLabel("Id");
		lblId.setFont(new Font("Dialog", Font.BOLD, 15));
		lblId.setBounds(10, 59, 55, 21);
		panel.add(lblId);

		idDropdown = new JComboBox();
		idDropdown.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboId(idDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UN ID !!");
				}
			}
		});

		idDropdown.setBounds(121, 59, 300, 25);
		panel.add(idDropdown);

		marqueDropdown = new JComboBox();
		marqueDropdown.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboMarque(marqueDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UNE MARQUE !!");
				}
			}
		});

		marqueDropdown.setBounds(121, 109, 300, 25);
		panel.add(marqueDropdown);

		btnModifier = new JButton("Modifier");
		btnModifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					boolean error = false;
					idString = idDropdown.getSelectedItem().toString();
					bvString = bvDropdown.getSelectedItem().toString();
					moteurString = moteurDropdown.getSelectedItem().toString();
					marque = marqueDropdown.getSelectedItem().toString();
					String[] marqueArray = marque.split("-");
					idMarqueString = marqueArray[0];
					nomString = textFieldNom.getText();
					couleurString = textFieldCouleur.getText();
					prixString = textFieldPrix.getText();

					if (account.dept.contains("ADMIN")) {
						if (Verification(error, "update") == false) {
							DBUtilModele.updateModele(retrieveInputGUI(CRUDMode.UPDATE));
							retourFrame = new JFrame("retour");
							printTableAffichage(table);
							JOptionPane.showMessageDialog(retourFrame, "Modele modifié");
							affichage.JcomboId(idDropdown, table, 0, null);
							affichage.JcomboBV(bvDropdown, table, 0, null);
							affichage.JcomboMarque(marqueDropdown, table, 0, null);
							affichage.JcomboMoteur(moteurDropdown, table, 0, null);
							textFieldNom.setText("");
							textFieldCouleur.setText("");
							textFieldPrix.setText("");

						}
					} else {
						errorFrame = new JFrame("error");
						JOptionPane.showMessageDialog(errorFrame,
								"ERREUR, vous n'avez pas les privilèges de modifier un modele !!");
					}

				} catch (Exception E) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE MODIFIER CE MODELE");
				}
			}
		});
		btnModifier.setBounds(309, 410, 114, 26);
		panel.add(btnModifier);

		lblNouvelModele = new JLabel("Nouveau/modification Modele");
		lblNouvelModele.setFont(new Font("Dialog", Font.ITALIC, 15));
		lblNouvelModele.setHorizontalAlignment(SwingConstants.CENTER);
		lblNouvelModele.setBounds(31, 12, 392, 51);
		panel.add(lblNouvelModele);

		btnAnnuler = new JButton("Annuler");
		btnAnnuler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					affichage.JcomboId(idDropdown, table, 0, null);
					affichage.JcomboBV(bvDropdown, table, 0, null);
					affichage.JcomboMarque(marqueDropdown, table, 0, null);
					affichage.JcomboMoteur(moteurDropdown, table, 0, null);
					textFieldNom.setText("");
					textFieldCouleur.setText("");
					textFieldPrix.setText("");

				} catch (SQLException E) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR DE REINITIALISER LES CHAMPS");
				}
			}
		});
		btnAnnuler.setBounds(160, 447, 114, 26);
		panel.add(btnAnnuler);

		btnAjouter = new JButton("Ajouter");
		btnAjouter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					boolean error = false;
					bvString = bvDropdown.getSelectedItem().toString();
					moteurString = moteurDropdown.getSelectedItem().toString();
					marque = marqueDropdown.getSelectedItem().toString();
					String[] marqueArray = marque.split("-");
					idMarqueString = marqueArray[0];
					nomString = textFieldNom.getText();
					couleurString = textFieldCouleur.getText();
					prixString = textFieldPrix.getText();

					if (account.dept.contains("ADMIN")) {
						if (Verification(error, "add") == false) {
							DBUtilModele.addModele(retrieveInputGUI(CRUDMode.ADD));
							retourFrame = new JFrame("retour");
							printTableAffichage(table);
							JOptionPane.showMessageDialog(retourFrame, "Modele ajouté");
							affichage.JcomboId(idDropdown, table, 0, null);
							affichage.JcomboBV(bvDropdown, table, 0, null);
							affichage.JcomboMarque(marqueDropdown, table, 0, null);
							affichage.JcomboMoteur(moteurDropdown, table, 0, null);
							textFieldNom.setText("");
							textFieldCouleur.setText("");
							textFieldPrix.setText("");
						}
					} else {
						errorFrame = new JFrame("error");
						JOptionPane.showMessageDialog(errorFrame,
								"ERREUR, vous n'avez pas les privilèges d'ajouter un modele !!");
					}
				} catch (Exception E) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE D'AJOUTER CE MODELE");
				}

			}
		});
		btnAjouter.setBounds(160, 410, 114, 26);
		panel.add(btnAjouter);

		btnSupprimer = new JButton("Supprimer");
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					idString = idDropdown.getSelectedItem().toString();
					if (idString == "") {
						throw new EmptyStackException();
					}
					if (account.dept.contains("ADMIN") && account.getAccountType().contains("2")) {
						if (JOptionPane.showConfirmDialog(frame, "Voulez-vous reelement supprimer ce modele?",
								"Supercar", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
							DBUtilModele.deleteModele(retrieveInputGUI(CRUDMode.DELETE));
							retourFrame = new JFrame("retour");
							printTableAffichage(table);
							JOptionPane.showMessageDialog(retourFrame, "Modele Supprimé");
						}
					} else {
						errorFrame = new JFrame("error");
						JOptionPane.showMessageDialog(errorFrame,
								"ERREUR, vous n'avez pas les privilèges de supprimer un modele !!");
					}
				} catch (Exception E) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SUPPRIMER CE MODELE");
				}
			}
		});
		btnSupprimer.setBounds(10, 413, 114, 26);
		panel.add(btnSupprimer);

		lblMarque = new JLabel("Marque");
		lblMarque.setFont(new Font("Dialog", Font.BOLD, 15));
		lblMarque.setBounds(10, 109, 70, 21);
		panel.add(lblMarque);

		lblNom = new JLabel("Modele");
		lblNom.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNom.setBounds(10, 159, 70, 21);
		panel.add(lblNom);

		textFieldNom = new JTextField();
		textFieldNom.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNom.setBounds(121, 159, 302, 25);
		panel.add(textFieldNom);
		textFieldNom.setColumns(10);

		lblCouleur = new JLabel("Couleur");
		lblCouleur.setFont(new Font("Dialog", Font.BOLD, 15));
		lblCouleur.setBounds(10, 209, 70, 21);
		panel.add(lblCouleur);

		textFieldCouleur = new JTextField();
		textFieldCouleur.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldCouleur.setColumns(10);
		textFieldCouleur.setBounds(119, 209, 302, 25);
		panel.add(textFieldCouleur);

		lblMoteur = new JLabel("Moteur");
		lblMoteur.setFont(new Font("Dialog", Font.BOLD, 15));
		lblMoteur.setBounds(10, 259, 70, 21);
		panel.add(lblMoteur);

		moteurDropdown = new JComboBox();
		moteurDropdown.setBounds(121, 259, 300, 25);
		panel.add(moteurDropdown);

		lblBV = new JLabel("B. de vitesse");
		lblBV.setFont(new Font("Dialog", Font.BOLD, 15));
		lblBV.setBounds(10, 309, 101, 21);
		panel.add(lblBV);

		bvDropdown = new JComboBox();
		bvDropdown.setBounds(121, 309, 300, 25);
		panel.add(bvDropdown);

		lblPrix = new JLabel("Prix");
		lblPrix.setFont(new Font("Dialog", Font.BOLD, 15));
		lblPrix.setBounds(10, 359, 70, 21);
		panel.add(lblPrix);

		textFieldPrix = new JTextField();
		textFieldPrix.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldPrix.setColumns(10);
		textFieldPrix.setBounds(119, 359, 302, 25);
		panel.add(textFieldPrix);

		lblModele = new JLabel("Modele");
		lblModele.setFont(new Font("Dialog", Font.BOLD, 25));
		lblModele.setHorizontalAlignment(SwingConstants.CENTER);
		lblModele.setBounds(559, 67, 154, 48);
		frame.getContentPane().add(lblModele);

		btnRetour = new JButton("retour");
		btnRetour.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				ModeleGUI.this.frame.setVisible(false);
				Dashboard.main(login);
			}
		});
		btnRetour.setBounds(1238, 702, 99, 26);
		frame.getContentPane().add(btnRetour);
	}
}
