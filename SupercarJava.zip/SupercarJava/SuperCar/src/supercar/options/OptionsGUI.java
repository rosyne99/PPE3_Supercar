package supercar.options;

import java.awt.EventQueue;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.EmptyStackException;
import java.util.regex.Pattern;
import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JTable;
import supercar.constants.CRUDMode;
import supercar.login.AdminAccount;
import supercar.login.Dashboard;
import supercar.model.Options;
import supercar.utilities.DBUtilOptions;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.JTextPane;

/**
 * class OptionGUI : GUI for 'Options'
 * 
 * @SuppressWarnings("rawtypes") added for JcomboBox 'idDropdown' warning
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */

@SuppressWarnings("rawtypes")
public class OptionsGUI {

	private JFrame frame;
	private JFrame errorFrame;
	private JFrame retourFrame;
	private JTable table;
	private JLabel lblNomOptions;
	private JLabel lblTypeOptions;
	private JLabel lblId;
	private JLabel lblPrixOptions;
	private JLabel lblOptions;
	private JLabel lblDetailOptions;
	private JLabel lblNouvelOptions;
	private Timer timer;
	private JPanel panel;
	private boolean error;
	private JButton btnModifier;
	private JComboBox idDropdown;
	private JButton btnAjouter;
	private JButton btnAnnuler;
	private JButton btnSupprimer;
	private JButton btnRetour;
	private JTextField txtNomOptions;
	private JTextField txtTypeOptions;
	private JTextField txtPrixOptions;
	private JTextPane txtDetails;
	private static String idOptionString;
	private static String nomOptionString;
	private static String detailOptionString;
	private static String prixOptionString;
	private static String typeOptionString;
	private DBUtilOptions affichage = new DBUtilOptions();
	private AdminAccount account = new AdminAccount();
	private JScrollPane scrollPane;
	private JScrollPane detailsOptionsScrollPane;

	/**
	 * Launch the application.
	 * 
	 * @param login : login of the Authentified User.
	 */
	public static void main(String login) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OptionsGUI window = new OptionsGUI(login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Method that put all the information into the variables of the model.Options
	 * Class for insertion or update in the Database
	 * 
	 * @param mode
	 * @return marque : Model object of class Options
	 */
	private static Options retrieveInputGUI(CRUDMode mode) {
		Options option = new Options();
		if (mode.equals(CRUDMode.ADD) || mode.equals(CRUDMode.UPDATE)) {
			if (mode.equals(CRUDMode.UPDATE)) {
				option.setID_OPTIONS(idOptionString);
			}
			option.setNomOptions(nomOptionString);
			option.setTypeOptions(typeOptionString);
			option.setDetailOptions(detailOptionString);
			option.setPrixOptions(prixOptionString);
		} else if (mode.equals(CRUDMode.DELETE)) {
			option.setID_OPTIONS(idOptionString);
		}
		return option;

	}

	/**
	 * Import options database data in the table model using DBUtilOptions's method
	 * 'graphicGetAllOptions'
	 * 
	 * Table composed of ("ID", "Nom Options", "Type Options", "Details", "Prix HT"
	 * )
	 * 
	 * @param table
	 * @throws SQLException
	 */
	public void printTableAffichage(JTable table) throws SQLException {
		affichage.graphicGetAllOptions(table);
	}

	/**
	 * method that verify every variables used to update / created a 'options' using
	 * pattern if one of the variable is wrong, verification is "true", the user
	 * will need to correct his mistakes otherwise the data are saved in the
	 * database
	 * 
	 * @param error
	 * @param type
	 * @return error
	 */
	private boolean Verification(boolean error, String type) {
		frame = new JFrame();
		if (type.equals("add") || type.equals("update")) {
			if (type.equals("update")) {
				if (idOptionString == "") {
					JOptionPane.showMessageDialog(frame, "ERREUR, ID INVALIDE");
					error = true;
				}
			}
			if (Pattern.matches("[A-Za-zÀ-ȕ]([\\w -]*[A-Za-zÀ-ȕ])", nomOptionString) == false
					|| nomOptionString.equalsIgnoreCase("")) {
				txtNomOptions.setText("");
				JOptionPane.showMessageDialog(frame, "ERREUR, NOM INVALIDE");
				error = true;
			} else if (Pattern.matches("[A-Za-zÀ-ȕ]([\\w -]*[A-Za-zÀ-ȕ])", typeOptionString) == false
					|| typeOptionString.equalsIgnoreCase("")) {
				txtTypeOptions.setText("");
				JOptionPane.showMessageDialog(frame, "ERREUR, TYPE INVALIDE");
				error = true;
			} else if (Pattern.matches("\\d+(\\.\\d{1,2})?", prixOptionString) == false
					|| prixOptionString.equalsIgnoreCase("")) {
				txtPrixOptions.setText("");
				JOptionPane.showMessageDialog(frame, "ERREUR, PRIX INVALIDE");
				error = true;
			}
		}
		return error;
	}

	/**
	 * Create the application.
	 * 
	 * @throws ParseException
	 * @throws SQLException
	 * @param login : login of the Authentified User.
	 */
	public OptionsGUI(String login) throws ParseException, SQLException {
		initialize(login);
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * 'account.DatabaseConnexion' that will help for the authenticated to see all
	 * of his informations / disconnnect if the user is not in the database.
	 * 
	 * Table (table) with auto-refresh features (the table will auto-refresh with
	 * the database every 10 seconds (10000ms) ) and row selectable for updating an
	 * existing options.
	 *
	 * Button (btnModifier) 'Modifier' that will update a selected 'option' to the
	 * database using the ID (if the user works in admin) if the verification
	 * doesn't give any error
	 * 
	 * Button (btnAjouter) 'Ajouter' that will add a new 'option' to the database
	 * (if the user works in admin) if the verification doesn't give any error
	 * 
	 * Button (btnSupprimer) 'Supprimer' that will desactivate the 'option' to the
	 * database using the ID (if the user works in admin and is a manager) if the
	 * verification doesn't give any error
	 *
	 * Button (btnAnnuler) 'Annuler' that will clear every inputs.
	 *
	 * Button (btnRetour) 'Retour' that will make the user return into the
	 * 'Dashboard' Page.
	 * 
	 * @SuppressWarnings("rawtypes") added for JcomboBox 'idDropdown' warning.
	 * 
	 * @param login : login of the Authentified User.
	 * 
	 * @throws ParseException.
	 * @throws SQLException.
	 */

	private void initialize(String login) throws ParseException, SQLException {
		account.DatabaseConnexion(login, null, null, frame);
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 1366, 768);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setBounds(459, 142, 878, 538);
		frame.getContentPane().add(scrollPane);
		table = new JTable();
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				int row = table.rowAtPoint(e.getPoint());
				try {
					affichage.JcomboId(idDropdown, table, row, "update");
					affichage.JTextFieldNom(txtNomOptions, table, row);
					affichage.JTextFieldType(txtTypeOptions, table, row);
					affichage.JTextFieldDetail(txtDetails, table, row);
					affichage.JTextFieldPrix(txtPrixOptions, table, row);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UNE LIGNE !!");
				}
			}
		});
		table.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "ID", "Nom Options", "Type Options", "Details", "Prix HT" }));
		table.getColumnModel().getColumn(0).setPreferredWidth(70);
		table.getColumnModel().getColumn(1).setPreferredWidth(140);
		table.getColumnModel().getColumn(2).setPreferredWidth(150);
		table.getColumnModel().getColumn(3).setPreferredWidth(430);
		table.getColumnModel().getColumn(4).setPreferredWidth(120);
		table.setEnabled(false);
		table.setCellSelectionEnabled(true);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		scrollPane.setViewportView(table);

		timer = new Timer(0, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					printTableAffichage(table);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE D'ACTUALISER LA LISTE !!");
				}
			}
		});

		timer.setDelay(10000);
		timer.start();

		panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(12, 142, 435, 538);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		lblId = new JLabel("Id");
		lblId.setFont(new Font("Dialog", Font.BOLD, 15));
		lblId.setBounds(12, 75, 55, 21);
		panel.add(lblId);

		idDropdown = new JComboBox();
		idDropdown.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboId(idDropdown, table, 0, null);
					affichage.JTextFieldNom(txtNomOptions, table, 0);
					affichage.JTextFieldType(txtTypeOptions, table, 0);
					affichage.JTextFieldDetail(txtDetails, table, 0);
					affichage.JTextFieldPrix(txtPrixOptions, table, 0);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UN ID !!");
				}
			}
		});

		idDropdown.setBounds(85, 75, 338, 25);
		panel.add(idDropdown);

		lblNomOptions = new JLabel("Nom");
		lblNomOptions.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNomOptions.setBounds(12, 125, 55, 21);
		panel.add(lblNomOptions);

		lblTypeOptions = new JLabel("Type");
		lblTypeOptions.setFont(new Font("Dialog", Font.BOLD, 15));
		lblTypeOptions.setBounds(12, 175, 55, 21);
		panel.add(lblTypeOptions);

		lblPrixOptions = new JLabel("Prix");
		lblPrixOptions.setFont(new Font("Dialog", Font.BOLD, 15));
		lblPrixOptions.setBounds(12, 405, 55, 16);
		panel.add(lblPrixOptions);

		lblDetailOptions = new JLabel("Details");
		lblDetailOptions.setFont(new Font("Dialog", Font.BOLD, 15));
		lblDetailOptions.setBounds(12, 301, 66, 16);
		panel.add(lblDetailOptions);

		// UPDATE BUTTON
		btnModifier = new JButton("Modifier");
		btnModifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				error = false;
				idOptionString = idDropdown.getSelectedItem().toString();
				nomOptionString = txtNomOptions.getText();
				typeOptionString = txtTypeOptions.getText();
				detailOptionString = txtDetails.getText();
				prixOptionString = txtPrixOptions.getText();
				if (account.dept.contains("ADMIN")) {
					if (Verification(error, "update") == false) {
						try {
							DBUtilOptions.updateOptions(retrieveInputGUI(CRUDMode.UPDATE));
							retourFrame = new JFrame("retour");
							printTableAffichage(table);
							JOptionPane.showMessageDialog(retourFrame, "Options modifié");
							affichage.JcomboId(idDropdown, table, 0, null);
							txtNomOptions.setText("");
							txtTypeOptions.setText("");
							txtDetails.setText("");
							txtPrixOptions.setText("");
						} catch (Exception E) {
							errorFrame = new JFrame("error");
							JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE MODIFIER CETTE OPTION");
						}
					}
				} else {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame,
							"ERREUR, vous n'avez pas les privileges de modifier une option");
				}
			}
		});
		btnModifier.setBounds(309, 459, 114, 26);
		panel.add(btnModifier);

		lblNouvelOptions = new JLabel("Nouvelle/modification Options");
		lblNouvelOptions.setFont(new Font("Dialog", Font.ITALIC, 15));
		lblNouvelOptions.setHorizontalAlignment(SwingConstants.CENTER);
		lblNouvelOptions.setBounds(31, 12, 392, 51);
		panel.add(lblNouvelOptions);

		btnAnnuler = new JButton("Annuler");
		btnAnnuler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					affichage.JcomboId(idDropdown, table, 0, null);
					txtNomOptions.setText("");
					txtTypeOptions.setText("");
					txtDetails.setText("");
					txtPrixOptions.setText("");

				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE REINITIALISER LES CHAMPS !!");
				}
			}
		});
		btnAnnuler.setBounds(162, 500, 114, 26);
		panel.add(btnAnnuler);

		// ADD BUTTON
		btnAjouter = new JButton("Ajouter");
		btnAjouter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean error = false;
				nomOptionString = txtNomOptions.getText();
				typeOptionString = txtTypeOptions.getText();
				detailOptionString = txtDetails.getText();
				prixOptionString = txtPrixOptions.getText();
				if (account.dept.contains("ADMIN")) {
					if (Verification(error, "add") == false) {
						try {
							DBUtilOptions.addOptions(retrieveInputGUI(CRUDMode.ADD));
							retourFrame = new JFrame("retour");
							printTableAffichage(table);
							JOptionPane.showMessageDialog(retourFrame, "Options ajouté");
							affichage.JcomboId(idDropdown, table, 0, null);
							txtNomOptions.setText("");
							txtTypeOptions.setText("");
							txtDetails.setText("");
							txtPrixOptions.setText("");
						} catch (Exception E) {
							errorFrame = new JFrame("error");
							JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE D'AJOUTER CETTE OPTION");
						}
					}
				} else {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame,
							"ERREUR, vous n'avez pas les privileges d'ajouter une option");
				}

			}
		});
		btnAjouter.setBounds(162, 459, 114, 26);
		panel.add(btnAjouter);

		txtNomOptions = new JTextField();
		txtNomOptions.setBounds(85, 126, 338, 20);
		panel.add(txtNomOptions);
		txtNomOptions.setColumns(10);

		txtTypeOptions = new JTextField();
		txtTypeOptions.setColumns(10);
		txtTypeOptions.setBounds(85, 176, 338, 20);
		panel.add(txtTypeOptions);

		txtPrixOptions = new JTextField();
		txtPrixOptions.setColumns(10);
		txtPrixOptions.setBounds(85, 404, 338, 20);
		panel.add(txtPrixOptions);

		detailsOptionsScrollPane = new JScrollPane();
		detailsOptionsScrollPane.setBounds(95, 218, 328, 168);
		panel.add(detailsOptionsScrollPane);

		txtDetails = new JTextPane();
		detailsOptionsScrollPane.setViewportView(txtDetails);

		btnSupprimer = new JButton("Supprimer");
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (account.dept.contains("ADMIN") && account.getAccountType().contains("2")) {
					try {
						idOptionString = idDropdown.getSelectedItem().toString();
						if (idOptionString == "") {
							throw new EmptyStackException();
						}
						if (JOptionPane.showConfirmDialog(frame, "Voulez-vous reelement supprimer cette option?",
								"Supercar", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
							DBUtilOptions.deleteOptions(retrieveInputGUI(CRUDMode.DELETE));
							retourFrame = new JFrame("retour");
							printTableAffichage(table);
							JOptionPane.showMessageDialog(retourFrame, "Option Supprimé");
							affichage.JcomboId(idDropdown, table, 0, null);
							txtNomOptions.setText("");
							txtTypeOptions.setText("");
							txtDetails.setText("");
							txtPrixOptions.setText("");
						}
					} catch (Exception E) {
						errorFrame = new JFrame("error");
						JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SUPPRIMER CETTE OPTION");
					}
				} else {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame,
							"ERREUR, vous n'avez pas les privilges de supprimer une option");
				}
			}
		});
		btnSupprimer.setBounds(12, 459, 114, 26);
		panel.add(btnSupprimer);

		lblOptions = new JLabel("Options");
		lblOptions.setFont(new Font("Dialog", Font.BOLD, 25));
		lblOptions.setHorizontalAlignment(SwingConstants.CENTER);
		lblOptions.setBounds(559, 67, 154, 48);
		frame.getContentPane().add(lblOptions);

		btnRetour = new JButton("retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OptionsGUI.this.frame.setVisible(false);
				Dashboard.main(login);
			}
		});
		btnRetour.setBounds(1238, 702, 99, 26);
		frame.getContentPane().add(btnRetour);
	}
}
