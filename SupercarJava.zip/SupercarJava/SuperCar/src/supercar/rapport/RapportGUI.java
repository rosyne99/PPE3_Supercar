package supercar.rapport;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import supercar.login.Dashboard;
import supercar.login.AdminAccount;
import supercar.utilities.DBUtilRapport;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.MessageFormat;
import java.awt.event.ActionEvent;

/**
 * class RapportGUI : GUI for 'Rapport Financier'
 *
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
public class RapportGUI {

	private JFrame frame;
	private JFrame errorFrame;
	private JTable table;
	private JLabel lblRapportMensuel;
	private Double salaire;
	private Double vente;
	private Double commande;
	private String total;
	private JLabel lblTotal;
	private JLabel lblTotalSum;
	private JLabel lblDate;
	private JButton btnImprimer;
	private JButton btnRetour;
	private DBUtilRapport affichage = new DBUtilRapport();
	private AdminAccount account = new AdminAccount();
	private JScrollPane scrollPane;
	private DefaultTableModel model;
	private MessageFormat header;
	private MessageFormat footer;

	/**
	 * Launch the application.
	 *  @param login : login of the Authentified User.
	 */
	public static void main(String login) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RapportGUI window = new RapportGUI(login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 *  @param login : login of the Authentified User.
	 * @throws Exception
	 */
	public RapportGUI(String login) throws Exception {
		initialize(login);
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * Button (btnImprimer) 'Imprimer/PDF' that will let the user print/generate PDF
	 * of current month's finance report
	 * 
	 * Button (btnRetour) 'Retour' that will make the user return into the
	 * 'Dashboard' Page.
	 * @param login : login of the Authentified User.
	 * @throws Exception
	 */
	private void initialize(String login) throws Exception {
		account.DatabaseConnexion(login, null, null, frame);
		frame = new JFrame();
		frame.setBounds(100, 100, 759, 690);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		salaire = affichage.sumSalaire();
		vente = affichage.sumVente();
		commande = affichage.sumCommande();
		total = affichage.totalSum();

		lblRapportMensuel = new JLabel("Rapport Financier Mensuel - ");
		lblRapportMensuel.setHorizontalAlignment(SwingConstants.CENTER);
		lblRapportMensuel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblRapportMensuel.setBounds(159, 58, 283, 59);
		frame.getContentPane().add(lblRapportMensuel);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 127, 725, 426);
		frame.getContentPane().add(scrollPane);

		table = new JTable();
		table.setFont(new Font("Tahoma", Font.PLAIN, 15));
		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Intitu\u00E9", "montant" }));
		scrollPane.setViewportView(table);

		model = (DefaultTableModel) table.getModel();
		model.addRow(new Object[] { "Total des Commandes en cours", commande });
		model.addRow(new Object[] { "Total des Salaires", salaire });
		model.addRow(new Object[] { "Total des Ventes réalisé", vente });
		model.addRow(new Object[] { "Total en MUR", total });

		lblTotal = new JLabel("Total en MUR");
		lblTotal.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTotal.setBounds(439, 579, 91, 23);
		frame.getContentPane().add(lblTotal);

		lblTotalSum = new JLabel("");
		lblTotalSum.setHorizontalAlignment(SwingConstants.CENTER);
		lblTotalSum.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTotalSum.setText(affichage.totalSum());
		lblTotalSum.setBounds(540, 578, 195, 24);
		frame.getContentPane().add(lblTotalSum);

		lblDate = new JLabel("");
		lblDate.setText(affichage.getDate());
		lblDate.setHorizontalAlignment(SwingConstants.LEFT);
		lblDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDate.setBounds(452, 58, 283, 59);
		frame.getContentPane().add(lblDate);

		btnImprimer = new JButton("Imprimer/PDF");
		btnImprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					header = new MessageFormat("Rapport financier - " + affichage.getDate());
					footer = new MessageFormat("Page{0,number,integer}");
					try {
						table.print(JTable.PrintMode.NORMAL, header, footer);
					} catch (Exception E) {
						errorFrame = new JFrame("error");
						JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPRESSION IMPOSSIBLE...");
					}
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPRESSION IMPOSSIBLE...");
				}
			}
		});
		btnImprimer.setBounds(496, 622, 85, 21);
		frame.getContentPane().add(btnImprimer);

		btnRetour = new JButton("Retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RapportGUI.this.frame.setVisible(false);
				Dashboard.main(login);
			}
		});
		btnRetour.setBounds(214, 622, 85, 21);
		frame.getContentPane().add(btnRetour);
	}
}
