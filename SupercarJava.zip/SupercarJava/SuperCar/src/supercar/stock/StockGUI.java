package supercar.stock;

import java.awt.EventQueue;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.EmptyStackException;
import java.util.regex.Pattern;
import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JTable;
import supercar.constants.CRUDMode;
import supercar.login.AdminAccount;
import supercar.login.Dashboard;
import supercar.model.Stock;
import supercar.utilities.DBUtilStock;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;

/**
 * class MarqueGUI : GUI for 'Stock'
 * 
 * @SuppressWarnings("rawtypes") added for JcomboBoxs warning
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
@SuppressWarnings("rawtypes")
public class StockGUI {

	private JFrame frame;
	private JFrame errorFrame;
	private JFrame retourFrame;
	private JTable table;
	private JLabel lblId;
	private JLabel lblStock;
	private JLabel lblNouvelStock;
	private JLabel lblEntrepot;
	private JLabel lblNoVhicule;
	private JLabel lblStaut;
	private Timer timer;
	private JPanel panel;
	private boolean error;
	private int stock;
	private JButton btnAjouter;
	private JButton btnSupprimer;
	private JButton btnModifer;
	private JButton btnAnnuler;
	private JButton btnRetour;
	private JComboBox idDropdown;
	private JComboBox modeleDropdown;
	private JComboBox statutDropdown;
	private JComboBox entrepotDropdown;
	private JTextField txtNoVehicule;
	private String modele;
	private String statut;
	private String entrepot;
	private JLabel lblModele;
	private static String idString;
	private static String idModeleString;
	private static String idDeptString;
	private static String statutString;
	private static String stockString;
	private JScrollPane scrollPane;
	private String[] modeleArray;
	private String[] EntrepotArray;
	private DBUtilStock affichage = new DBUtilStock();
	private AdminAccount account = new AdminAccount();

	/**
	 * Launch the application.
	 *  @param login : login of the Authentified User.
	 */
	public static void main(String login) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StockGUI window = new StockGUI(login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Method that put all the information into the variables of the model.Stock
	 * Class for insertion or update in the Database
	 * 
	 * @param mode
	 * @return stock : Model object of class Stock
	 */

	private static Stock retrieveInputGUI(CRUDMode mode) {
		Stock stock = new Stock();
		if (mode.equals(CRUDMode.ADD) || mode.equals(CRUDMode.UPDATE)) {
			if (mode.equals(CRUDMode.UPDATE)) {
				stock.setID_STOCK(idString);
			}
			stock.setID_MODELE(idModeleString);
			stock.setID_DEPT(idDeptString);
			stock.setSTOCK(stockString);
			stock.setSTATUT(statutString);

		} else if (mode.equals(CRUDMode.DELETE)) {
			stock.setID_STOCK(idString);
		}
		return stock;

	}

	/**
	 * Import stock database data in the table model using DBUtilStock's method
	 * 'graphicGetAllStock'
	 * 
	 * Table composed of ("ID", "Modele", "Entrepot", "Nombre de véhicule", "Statut"
	 * )
	 * 
	 * @param table table of data
	 * @throws SQLException
	 */
	public void printTableAffichage(JTable table) throws SQLException {
		affichage.graphicGetAllStock(table);
	}

	/**
	 * method that verify every variables used to update / created a 'marque' using
	 * pattern if one of the variable is wrong, verification is "true", the user
	 * will need to correct his mistakes otherwise the data are saved in the
	 * database
	 * 
	 * @param error
	 * @param type
	 * @return error
	 */
	private boolean Verification(boolean error, String type) {
		frame = new JFrame();
		if (type.equals("add") || type.equals("update")) {
			if (type.equals("update")) {
				if (idString == "") {
					JOptionPane.showMessageDialog(frame, "ERREUR, ID INVALIDE");
					error = true;
				}
			}
			if (idModeleString == "") {
				JOptionPane.showMessageDialog(frame, "ERREUR, ID MODELE INVALIDE");
				error = true;
			}
			if (idDeptString == "") {
				JOptionPane.showMessageDialog(frame, "ERREUR, ID DEPT INVALIDE");
				error = true;
			}
			if (Pattern.matches("[0-9]*", stockString) == false || stockString.equalsIgnoreCase("")) {
				JOptionPane.showMessageDialog(frame, "ERREUR, STOCK INVALIDE");
				error = true;
			}
			if (statutString == "") {
				JOptionPane.showMessageDialog(frame, "ERREUR, STATUT INVALIDE");
				error = true;
			}
			if (stockString == "0") {
				statutString = "0";
			}

		}
		return error;
	}

	/**
	 * Create the application.
	 *  @param login : login of the Authentified User.
	 * @throws ParseException
	 * @throws SQLException
	 */
	public StockGUI(String login) throws ParseException, SQLException {
		initialize(login);
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * 'account.DatabaseConnexion' that will help for the authenticated to see all
	 * of his informations / disconnnect if the user is not in the database.
	 * 
	 * Table (table) with auto-refresh features (the table will auto-refresh with
	 * the database every 10 seconds (10000ms) ) and row selectable for updating an
	 * existing modele.
	 *
	 * Button (btnModifier) 'Modifier' that will update a selected 'modele' to the
	 * database using the ID (if the user works in admin or stock) if the verification
	 * doesn't give any error
	 * 
	 * Button (btnAjouter) 'Ajouter' that will add a new 'modele' to the database
	 * (if the user works in admin or stock) if the verification doesn't give any error
	 * 
	 * Dropdown (idDropdown) 'id' that shows all the existing id in the database
	 * 
	 * Dropdown (modeleDropdown) 'modele' that shows all the 'modele' in the
	 * database
	 * 
	 * Dropdown (entrepotDropdown) that shows all the existing 'entrepot' in the
	 * database
	 * 
	 * Dropdown (statutDropdown) 'statut' that shows all statut
	 *
	 * TextField (txtNoVehicule) 'No Vehicule' that will show the number of vehicle
	 * or let the user write a number of vehicle
	 *
	 * 
	 * Button (btnSupprimer) 'Supprimer' that will desactivate the 'modele' to the
	 * database using the ID (if the user works in admin or stock and is a manager) if the
	 * verification doesn't give any error
	 *
	 * Button (btnAnnuler) 'Annuler' that will clear every inputs.
	 *
	 * Button (btnRetour) 'Retour' that will make the user return into the
	 * 'Dashboard' Page.
	 * 
	 * @SuppressWarnings("rawtypes") added for JcomboBoxs warning.
	 * 
	 * @param login : login of the Authentified User.
	 * 
	 * @throws ParseException.
	 * @throws SQLException.
	 */
	private void initialize(String login) throws ParseException, SQLException {

		account.DatabaseConnexion(login, null, null, frame);
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 1366, 768);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setBounds(459, 142, 878, 483);
		frame.getContentPane().add(scrollPane);
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				int row = table.rowAtPoint(e.getPoint());
				try {
					affichage.JcomboId(idDropdown, table, row, "update");
					affichage.JcomboEntrepot(entrepotDropdown, table, row, "update");
					affichage.JcomboModele(modeleDropdown, table, row, "update");
					affichage.JTextFieldStock(txtNoVehicule, table, row);
					affichage.JcomboStatut(statutDropdown, table, row, "update");

				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER LA LIGNE !!");
				}
			}
		});
		table.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "ID", "Modele", "Entrepot", "Nombre de véhicule", "Statut" }));
		table.getColumnModel().getColumn(0).setPreferredWidth(80);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(2).setPreferredWidth(200);
		table.getColumnModel().getColumn(3).setPreferredWidth(200);
		table.getColumnModel().getColumn(4).setPreferredWidth(200);
		table.setEnabled(false);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setCellSelectionEnabled(true);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		scrollPane.setViewportView(table);

		timer = new Timer(0, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					printTableAffichage(table);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE D'ACTUALISER LA LISTE !!");
				}
			}
		});

		timer.setDelay(10000);
		timer.start();

		panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(12, 142, 435, 483);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		lblId = new JLabel("Id");
		lblId.setFont(new Font("Dialog", Font.BOLD, 15));
		lblId.setBounds(12, 116, 55, 21);
		panel.add(lblId);

		idDropdown = new JComboBox();
		idDropdown.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboId(idDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UN ID !!");
				}
			}
		});

		idDropdown.setBounds(123, 116, 300, 25);
		panel.add(idDropdown);

		// UPDATE BUTTON
		btnModifer = new JButton("Modifier");
		btnModifer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					error = false;
					idString = idDropdown.getSelectedItem().toString();
					stockString = txtNoVehicule.getText();
					modele = modeleDropdown.getSelectedItem().toString();
					statut = statutDropdown.getSelectedItem().toString();
					entrepot = entrepotDropdown.getSelectedItem().toString();
					if (modele == "" || statut == "" || entrepot == "" || idString == "" || stockString == "") {
						throw new EmptyStackException();
					}
					modeleArray = modele.split("-");
					idModeleString = modeleArray[0];
					EntrepotArray = entrepot.split("-");
					idDeptString = EntrepotArray[0];
					if (statut.contains("Indisponible")) {
						statutString = "0";
					} else if (statut.contains("En cours")) {
						statutString = "1";
					} else if (statut.contains("Disponible")) {
						statutString = "2";
					}
					stock = Integer.valueOf(stockString);
					if (stock == 0) {
						statutString = "0";
					} else if (stock > 0 && statutString == "Indisponible") {
						statutString = "";
					}
					if (account.dept.contains("ADMIN") || account.dept.contains("ENTREPOT")) {

						if (Verification(error, "update") == false) {
							DBUtilStock.updateStock(retrieveInputGUI(CRUDMode.UPDATE));
							retourFrame = new JFrame("retour");
							printTableAffichage(table);
							JOptionPane.showMessageDialog(retourFrame, "Stock modifié");
							affichage.JcomboId(idDropdown, table, 0, null);
							affichage.JcomboEntrepot(entrepotDropdown, table, 0, null);
							affichage.JcomboModele(modeleDropdown, table, 0, null);
							affichage.JcomboStatut(statutDropdown, table, 0, null);
							txtNoVehicule.setText("");
						}
					} else {
						errorFrame = new JFrame("error");
						JOptionPane.showMessageDialog(errorFrame,
								"ERREUR, vous n'avez pas les privilèges de modifier un stock !!");
					}
				} catch (Exception E) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE MODIFIER CE STOCK");
				}
			}
		});
		btnModifer.setBounds(309, 410, 114, 26);
		panel.add(btnModifer);

		lblNouvelStock = new JLabel("Nouveau/modification Stock");
		lblNouvelStock.setFont(new Font("Dialog", Font.ITALIC, 15));
		lblNouvelStock.setHorizontalAlignment(SwingConstants.CENTER);
		lblNouvelStock.setBounds(31, 12, 392, 51);
		panel.add(lblNouvelStock);

		btnAnnuler = new JButton("Annuler");
		btnAnnuler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					affichage.JcomboId(idDropdown, table, 0, null);
					affichage.JcomboEntrepot(entrepotDropdown, table, 0, null);
					affichage.JcomboModele(modeleDropdown, table, 0, null);
					affichage.JcomboStatut(statutDropdown, table, 0, null);
					txtNoVehicule.setText("");

				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE REINITIALISER LES CHAMPS");
				}
			}
		});
		btnAnnuler.setBounds(160, 447, 114, 26);
		panel.add(btnAnnuler);

		lblModele = new JLabel("Modèle");
		lblModele.setFont(new Font("Dialog", Font.BOLD, 15));
		lblModele.setBounds(10, 166, 57, 13);
		panel.add(lblModele);

		modeleDropdown = new JComboBox();
		modeleDropdown.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboModele(modeleDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONER UN MODELE");
				}
			}
		});
		modeleDropdown.setBounds(123, 164, 302, 21);
		panel.add(modeleDropdown);

		lblEntrepot = new JLabel("Entrepot");
		lblEntrepot.setFont(new Font("Dialog", Font.BOLD, 15));
		lblEntrepot.setBounds(12, 216, 74, 19);
		panel.add(lblEntrepot);

		entrepotDropdown = new JComboBox();
		entrepotDropdown.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboEntrepot(entrepotDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UN ENTREPOT");
				}
			}
		});
		entrepotDropdown.setBounds(123, 214, 302, 21);
		panel.add(entrepotDropdown);

		lblNoVhicule = new JLabel("No Véhicule");
		lblNoVhicule.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNoVhicule.setBounds(12, 266, 91, 13);
		panel.add(lblNoVhicule);

		txtNoVehicule = new JTextField();
		txtNoVehicule.setBounds(123, 265, 300, 25);
		panel.add(txtNoVehicule);
		txtNoVehicule.setColumns(10);

		lblStaut = new JLabel("Statut");
		lblStaut.setFont(new Font("Dialog", Font.BOLD, 15));
		lblStaut.setBounds(12, 318, 64, 13);
		panel.add(lblStaut);

		statutDropdown = new JComboBox();
		statutDropdown.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboStatut(statutDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UN STATUT");
				}
			}
		});
		statutDropdown.setBounds(123, 316, 300, 21);
		panel.add(statutDropdown);

		// ADD BUTTON
		btnAjouter = new JButton("Ajouter");
		btnAjouter.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				try {
					error = false;
					modele = modeleDropdown.getSelectedItem().toString();
					statut = statutDropdown.getSelectedItem().toString();
					entrepot = entrepotDropdown.getSelectedItem().toString();
					stockString = txtNoVehicule.getText();
					if (modele == "" || statut == "" || entrepot == "" || stockString == "") {
						throw new EmptyStackException();
					}
					modeleArray = modele.split("-");
					idModeleString = modeleArray[0];
					EntrepotArray = entrepot.split("-");
					idDeptString = EntrepotArray[0];
					if (statut.contains("Indisponible")) {
						statutString = "0";
					} else if (statut.contains("En cours")) {
						statutString = "1";
					} else if (statut.contains("Disponible")) {
						statutString = "2";
					}
					stock = Integer.valueOf(stockString);
					if (stock == 0) {
						statutString = "0";
					} else if (stock > 0 && statutString == "Indisponible") {
						statutString = "";
					}
					if (account.dept.contains("ADMIN") || account.dept.contains("ENTREPOT")) {
						if (Verification(error, "add") == false) {
							DBUtilStock.addStock(retrieveInputGUI(CRUDMode.ADD));
							retourFrame = new JFrame("retour");
							printTableAffichage(table);
							JOptionPane.showMessageDialog(retourFrame, "Stock ajouté");
							affichage.JcomboId(idDropdown, table, 0, null);
							affichage.JcomboEntrepot(entrepotDropdown, table, 0, null);
							affichage.JcomboModele(modeleDropdown, table, 0, null);
							affichage.JcomboStatut(statutDropdown, table, 0, null);
							txtNoVehicule.setText("");
						}
					} else {
						errorFrame = new JFrame("error");
						JOptionPane.showMessageDialog(errorFrame,
								"ERREUR, vous n'avez pas les privilèges d'ajouter un stock !!");
					}
				} catch (Exception E) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE D'AJOUTER CE STOCK");
				}

			}
		});
		btnAjouter.setBounds(160, 410, 114, 26);
		panel.add(btnAjouter);

		btnSupprimer = new JButton("Supprimer");
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					idString = idDropdown.getSelectedItem().toString();
					if (idString == "") {
						throw new EmptyStackException();
					}
					if (account.dept.contains("ADMIN") && account.getAccountType().contains("2")) {
						if (JOptionPane.showConfirmDialog(frame, "Voulez-vous reelement supprimer ce stock?",
								"Supercar", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
							DBUtilStock.deleteStock(retrieveInputGUI(CRUDMode.DELETE));
							retourFrame = new JFrame("retour");
							printTableAffichage(table);
							JOptionPane.showMessageDialog(retourFrame, "Stock Supprimé");
						}
					} else {
						errorFrame = new JFrame("error");
						JOptionPane.showMessageDialog(errorFrame,
								"ERREUR, vous n'avez pas les privilèges de supprimer un stock !!");
					}
				} catch (Exception E) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SUPPRIMER CE STOCK");
				}
			}
		});
		btnSupprimer.setBounds(10, 413, 114, 26);
		panel.add(btnSupprimer);

		lblStock = new JLabel("Stock");
		lblStock.setFont(new Font("Dialog", Font.BOLD, 25));
		lblStock.setHorizontalAlignment(SwingConstants.CENTER);
		lblStock.setBounds(559, 67, 154, 48);
		frame.getContentPane().add(lblStock);

		btnRetour = new JButton("retour");
		btnRetour.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				StockGUI.this.frame.setVisible(false);
				Dashboard.main(login);
			}
		});
		btnRetour.setBounds(1238, 702, 99, 26);
		frame.getContentPane().add(btnRetour);
	}
}
