package supercar.test;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.Scanner;
import org.junit.jupiter.api.Test;
import supercar.login.AdminAccount;

/**
 * Class LoginTest : Junit login
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */

public class LoginTest {
	public AdminAccount test = new AdminAccount();
	String res;
	String pwdTest;
	String loginTest;

	@Test
	void test() throws SQLException {
		try (Scanner Scan = new Scanner(System.in)) {

			System.out.print("Saisissez le login (xxxxx@xxxxxxx.com) : ");
			loginTest = Scan.next();

			System.out.print("Saisissez le mot de passe : ");
			pwdTest = Scan.next();

			res = test.connectionTest(loginTest, pwdTest);
			assertEquals("user exist", res);
		}
	}
}
