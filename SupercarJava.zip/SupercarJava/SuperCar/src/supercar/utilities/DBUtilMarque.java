package supercar.utilities;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import supercar.db.ConnectionFactory;
import supercar.constants.QueryStatement;
import supercar.model.Marque;

/**
 * Class DBUTILMarque: connection to database to add, update, delete or show
 * data of supercar Supplier
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
public class DBUtilMarque {

	private static Connection connection;
	private static PreparedStatement preparedStatement;
	private static ResultSet resultSet = null;

	/**
	 * add a new supplier into the database
	 * 
	 * @param marque
	 * @throws SQLException
	 */
	public static void addMarque(Marque marque) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.ADD_MARQUE_QUERY);

		setPreparedStatementProperties(marque.getNom(), marque.getOrigine(), marque.getFournisseur(),
				marque.getContact(), marque.getEmail());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * update a selected supplier into the database
	 * 
	 * @param marque
	 * @throws SQLException
	 */
	public static void updateMarque(Marque marque) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.UPDATE_MARQUE_QUERY);

		setPreparedStatementProperties(marque.getNom(), marque.getOrigine(), marque.getFournisseur(),
				marque.getContact(), marque.getEmail(), marque.getID_MARQUE());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * update a selected supplier into the database from active (1) into inactive
	 * (0)
	 * 
	 * @param marque
	 * @throws SQLException
	 */
	public static void deleteMarque(Marque marque) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.DELETE_MARQUE_QUERY);
		setPreparedStatementProperties(marque.getID_MARQUE());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * close connection to the database
	 * 
	 * @throws SQLException
	 */
	private static void closeConnections() throws SQLException {
		if (resultSet != null) {
			resultSet.close();
		}
		if (preparedStatement != null) {
			preparedStatement.close();
		}
		if (connection != null) {
			connection.close();
		}
	}

	private static void setPreparedStatementProperties(String... strArgs) throws SQLException {
		for (int i = 0; i < strArgs.length; i++) {
			preparedStatement.setString(i + 1, strArgs[i]);
		}
	}

	/**
	 * method that will fetch and insert the mysql database data of active suppliers
	 * into a Jtable
	 * 
	 * @param table
	 * @throws SQLException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void graphicGetAllMarque(JTable table) throws SQLException {
		int CC;
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_MARQUE_QUERY);
		resultSet = preparedStatement.executeQuery();

		java.sql.ResultSetMetaData RSMD = resultSet.getMetaData();
		CC = RSMD.getColumnCount();
		DefaultTableModel DFT = (DefaultTableModel) table.getModel();
		DFT.setRowCount(0);

		while (resultSet.next()) {
			Vector v2 = new Vector();

			for (int ii = 1; ii <= CC; ii++) {
				v2.add(resultSet.getString("ID_MARQUE"));
				v2.add(resultSet.getString("MARQUE"));
				v2.add(resultSet.getString("ORIGINE"));
				v2.add(resultSet.getString("FOURNISSEUR"));
				v2.add(resultSet.getString("CONTACT_PERSON"));
				v2.add(resultSet.getString("CONTACT_PERSON_MAIL"));
			}
			DFT.addRow(v2);
		}
	}

	/**
	 * method that will fetch and insert the mysql database data of active suppliers
	 * ID into a JComboBox or fetch data from a specific row in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboId(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		preparedStatement = connection.prepareStatement(QueryStatement.DROPDOWN_MARQUE_QUERY);
		resultSet = preparedStatement.executeQuery();
		theModel.removeAllElements();
		// for update
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 0));
		}
		theModel.addElement("");
		while (resultSet.next()) {
			theModel.addElement(resultSet.getString("ID_MARQUE"));
		}

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch brand name data from a specific row in the table and
	 * insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */
	public JTextField JTextFieldNom(JTextField jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 1).toString()));
		return jc;
	}

	/**
	 * method that will fetch brand country origin data from a specific row in the
	 * table and insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */
	public JTextField JTextFieldOrigine(JTextField jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 2).toString()));
		return jc;
	}

	/**
	 * method that will fetch supplier name data from a specific row in the table
	 * and insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */
	public JTextField JTextFieldFournisseur(JTextField jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 3).toString()));
		return jc;
	}

	/**
	 * method that will fetch supplier contact person data from a specific row in
	 * the table and insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */
	public JTextField JTextFieldContact(JTextField jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 4).toString()));
		return jc;
	}

	/**
	 * method that will fetch supplier mail address data from a specific row in the
	 * table and insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */
	public JTextField JTextFieldEmail(JTextField jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 5).toString()));
		return jc;
	}
}