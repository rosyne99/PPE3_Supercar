/**
 * 
 */
package supercar.utilities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import supercar.constants.QueryStatement;
import supercar.db.ConnectionFactory;
import supercar.model.Modele;

/**
 * Class DBUTILModele: connection to database to add, update, delete or show
 * data of supercar car model
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
public class DBUtilModele {
	private static Connection connection;
	private static PreparedStatement preparedStatement;
	private static ResultSet resultSet = null;

	/**
	 * add a new car model into the database
	 * 
	 * @param modele
	 * @throws SQLException
	 */

	public static void addModele(Modele modele) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.ADD_MODELE_QUERY);

		setPreparedStatementProperties(modele.getID_MARQUE(), modele.getNOM(), modele.getCOULEUR(), modele.getMOTEUR(),
				modele.getBV(), modele.getPRIX());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * update a selected car model into the database
	 * 
	 * @param modele
	 * @throws SQLException
	 */
	public static void updateModele(Modele modele) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.UPDATE_MODELE_QUERY);

		setPreparedStatementProperties(modele.getID_MARQUE(), modele.getNOM(), modele.getCOULEUR(), modele.getMOTEUR(),
				modele.getBV(), modele.getPRIX(), modele.getID_MODELE());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * update a selected car model into the database from active (1) into inactive
	 * (0)
	 * 
	 * @param modele
	 * @throws SQLException
	 */
	public static void deleteModele(Modele modele) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.DELETE_MODELE_QUERY);

		setPreparedStatementProperties(modele.getID_MODELE());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * close connection to the database
	 * 
	 * @throws SQLException
	 */
	private static void closeConnections() throws SQLException {
		if (resultSet != null) {
			resultSet.close();
		}
		if (preparedStatement != null) {
			preparedStatement.close();
		}
		if (connection != null) {
			connection.close();
		}
	}

	private static void setPreparedStatementProperties(String... strArgs) throws SQLException {
		for (int i = 0; i < strArgs.length; i++) {
			preparedStatement.setString(i + 1, strArgs[i]);
		}
	}

	/**
	 * method that will insert the mysql database data of active car model into a
	 * Jtable
	 * 
	 * @param table
	 * @throws SQLException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void graphicGetAllModele(JTable table) throws SQLException {
		int CC;
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_MODELE_QUERY);
		resultSet = preparedStatement.executeQuery();

		java.sql.ResultSetMetaData RSMD = resultSet.getMetaData();
		CC = RSMD.getColumnCount();
		DefaultTableModel DFT = (DefaultTableModel) table.getModel();
		DFT.setRowCount(0);

		while (resultSet.next()) {
			Vector v2 = new Vector();

			for (int ii = 1; ii <= CC; ii++) {
				v2.add(resultSet.getString("MODELE.ID_MODELE"));
				v2.add(resultSet.getString("VOITURE.ID_MARQUE") + " - " + resultSet.getString("VOITURE.MARQUE"));
				v2.add(resultSet.getString("MODELE.NOM"));
				v2.add(resultSet.getString("COULEUR"));
				v2.add(resultSet.getString("MOTEUR"));
				v2.add(resultSet.getString("BV"));
				v2.add(resultSet.getString("PRIX"));
			}

			DFT.addRow(v2);
		}
	}

	/**
	 * method that will fetch and insert the mysql database data of car model ID
	 * into a JComboBox or fetch data from a specific row in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboId(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_MODELE_QUERY);
		resultSet = preparedStatement.executeQuery();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 0));
		}
		theModel.addElement("");
		while (resultSet.next()) {
			theModel.addElement(resultSet.getString("ID_MODELE"));
		}

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch and insert the mysql database data of supplier ID and
	 * brand name into a JComboBox or fetch data from a specific row in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboMarque(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		preparedStatement = connection.prepareStatement(QueryStatement.DROPDOWN_MARQUE_QUERY);
		resultSet = preparedStatement.executeQuery();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 1));
			theModel.addElement("");
			while (resultSet.next()) {
				theModel.addElement(
						resultSet.getString("VOITURE.ID_MARQUE") + " - " + resultSet.getString("VOITURE.MARQUE"));
			}
		} else {
			theModel.addElement("");
			while (resultSet.next()) {
				theModel.addElement(
						resultSet.getString("VOITURE.ID_MARQUE") + " - " + resultSet.getString("VOITURE.MARQUE"));

			}
		}
		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch car model name data from a specific row in the table
	 * and insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */
	public JTextField JTextFieldNom(JTextField jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 2).toString()));
		return jc;
	}

	/**
	 * method that will fetch car model color data from a specific row in the table
	 * and insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */
	public JTextField JTextFieldCouleur(JTextField jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 3).toString()));
		return jc;
	}

	/**
	 * method that will fetch and insert the mysql database data of car model motor
	 * data into a JComboBox or fetch data from a specific row in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboMoteur(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 4));
		}
		theModel.addElement("");
		theModel.addElement("Diesel");
		theModel.addElement("Essence");
		theModel.addElement("Electrique");
		theModel.addElement("Hydrogene");

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch and insert the mysql database data of car model
	 * gearbox data into a JComboBox or fetch data from a specific row in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboBV(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_MODELE_QUERY);
		resultSet = preparedStatement.executeQuery();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 5));
		}
		theModel.addElement("");
		theModel.addElement("Automatique");
		theModel.addElement("Manuel");
		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch car model color data from a specific row in the table
	 * and insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */
	public JTextField JTextFieldPrix(JTextField jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 6).toString()));
		return jc;
	}
}
