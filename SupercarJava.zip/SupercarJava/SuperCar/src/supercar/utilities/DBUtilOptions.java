package supercar.utilities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.table.DefaultTableModel;
import supercar.db.ConnectionFactory;
import supercar.constants.QueryStatement;
import supercar.model.Options;

/**
 * Class DBUTILModele: connection to database to add, update, delete or show
 * data of supercar car options
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
public class DBUtilOptions {

	private static Connection connection;
	private static PreparedStatement preparedStatement;
	private static ResultSet resultSet = null;

	/**
	 * add a new car option into the database
	 * 
	 * @param options
	 * @throws SQLException
	 */

	public static void addOptions(Options options) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.ADD_OPTIONS_QUERY);

		setPreparedStatementProperties(options.getNomOptions(), options.getTypeOptions(), options.getDetailOptions(),
				options.getPrixOptions());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * update a selected car option into the database
	 * 
	 * @param options
	 * @throws SQLException
	 */

	public static void updateOptions(Options options) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.UPDATE_OPTIONS_QUERY);

		setPreparedStatementProperties(options.getNomOptions(), options.getTypeOptions(), options.getDetailOptions(),
				options.getPrixOptions(), options.getID_OPTIONS());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * update a selected car option into the database from active (1) into inactive
	 * (0)
	 * 
	 * @param options
	 * @throws SQLException
	 */

	public static void deleteOptions(Options options) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.DELETE_OPTIONS_QUERY);

		setPreparedStatementProperties(options.getID_OPTIONS());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * close connection to the database
	 * 
	 * @throws SQLException
	 */
	private static void closeConnections() throws SQLException {
		if (resultSet != null) {
			resultSet.close();
		}
		if (preparedStatement != null) {
			preparedStatement.close();
		}
		if (connection != null) {
			connection.close();
		}
	}

	private static void setPreparedStatementProperties(String... strArgs) throws SQLException {
		for (int i = 0; i < strArgs.length; i++) {
			preparedStatement.setString(i + 1, strArgs[i]);
		}
	}

	/**
	 * method that will insert the mysql database data of active car options into a
	 * Jtable
	 * 
	 * @param table
	 * @throws SQLException
	 */

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void graphicGetAllOptions(JTable table) throws SQLException {
		int CC;
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_OPTIONS_QUERY);
		resultSet = preparedStatement.executeQuery();

		java.sql.ResultSetMetaData RSMD = resultSet.getMetaData();
		CC = RSMD.getColumnCount();
		DefaultTableModel DFT = (DefaultTableModel) table.getModel();
		DFT.setRowCount(0);

		while (resultSet.next()) {
			Vector v2 = new Vector();

			for (int ii = 1; ii <= CC; ii++) {
				v2.add(resultSet.getString("ID_OPTIONS"));
				v2.add(resultSet.getString("NOM_OPTIONS"));
				v2.add(resultSet.getString("TYPE_OPTIONS"));
				v2.add(resultSet.getString("DETAIL_OPTIONS"));
				v2.add(resultSet.getString("PRIX_OPTIONS_HT"));
			}
			DFT.addRow(v2);
		}
	}

	/**
	 * method that will fetch and insert the mysql database data of car options ID
	 * into a JComboBox or fetch data from a specific row in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboId(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		preparedStatement = connection.prepareStatement(QueryStatement.DROPDOWN_OPTIONS_QUERY);
		resultSet = preparedStatement.executeQuery();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 0));
		}
		theModel.addElement("");
		while (resultSet.next()) {
			theModel.addElement(resultSet.getString("ID_OPTIONS"));
		}

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch car option name data from a specific row in the table
	 * and insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */

	public JTextField JTextFieldNom(JTextField jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 1).toString()));
		return jc;
	}

	/**
	 * method that will fetch car option type data from a specific row in the table
	 * and insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */

	public JTextField JTextFieldType(JTextField jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 2).toString()));
		return jc;
	}

	/**
	 * method that will fetch car option price from a specific row in the table and
	 * insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */
	public JTextField JTextFieldPrix(JTextField jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 4).toString()));
		return jc;
	}

	/**
	 * method that will fetch car option details data from a specific row in the
	 * table and insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */
	public JTextPane JTextFieldDetail(JTextPane jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 3).toString()));
		return jc;
	}
}
