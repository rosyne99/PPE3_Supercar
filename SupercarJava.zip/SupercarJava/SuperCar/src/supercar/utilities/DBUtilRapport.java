package supercar.utilities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.crypto.SecretKey;
import supercar.db.ConnectionFactory;
import supercar.constants.QueryStatement;
import supercar.security.*;

/**
 * Class DBUTILRapport: connection to database to show data of supercar vente,
 * salaire, stock
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */

public class DBUtilRapport {
	private static Connection connection;
	private static PreparedStatement preparedStatement;
	private static ResultSet resultSet = null;
	private SecretKey key;

	/**
	 * get current date (mm-aaaa)
	 * 
	 * @return
	 * @throws SQLException
	 */
	public String getDate() throws SQLException {
		String date;
		date = getMonth() + "/" + getYear();
		return date;
	}

	/**
	 * get current month (mm) using the database
	 * 
	 * @return
	 * @throws SQLException
	 */
	public static String getMonth() throws SQLException {
		String month = null;
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.CURRENT_MONTH);
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			month = resultSet.getString("DATE");
		}
		return month;
	}

	/**
	 * get current year (aaaa) using the database
	 * 
	 * @return
	 * @throws SQLException
	 */
	public static String getYear() throws SQLException {
		String year = null;
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.CURRENT_YEAR);
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			year = resultSet.getString("DATE");
		}
		return year;
	}

	/**
	 * sum current month sales price
	 * 
	 * @return
	 * @throws Exception
	 */
	public double sumVente() throws Exception {
		key = Blowfish.decryptKey();
		float sumVente = 0;
		String vente = "";
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_SUM_VENTE);
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			vente = resultSet.getString("VENTE");
			if (vente == null) {
				return sumVente;

			} else {
				sumVente = Float.valueOf(vente);
			}
			sumVente = Float.valueOf(vente);
		}

		return sumVente;

	}

	/**
	 * sum current car model order price
	 * 
	 * @return
	 * @throws Exception
	 */
	public double sumCommande() throws Exception {
		key = Blowfish.decryptKey();
		float sumCommande = 0;
		String commande = "";
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_SUM_COMMANDE);
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			commande = resultSet.getString("COMMANDE");
			if (commande == null) {
				return -sumCommande;
			} else {
				sumCommande = Float.valueOf(commande);
			}
		}
		return -sumCommande;
	}

	/**
	 * sum all salary and commission
	 * 
	 * @return
	 * @throws Exception
	 */

	public double sumSalaire() throws Exception {
		key = Blowfish.decryptKey();
		double sumSalaire = 0;
		String salaire = "";
		String salaireEncrypt;
		String commission;
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_SUM_SALAIRE);

		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			salaire = resultSet.getString("SALAIRE");
			if (salaire == null) {
				return -sumSalaire;
			} else {
				salaireEncrypt = Blowfish.decryptInString(salaire, key);
				sumSalaire = Double.valueOf(salaireEncrypt) + sumSalaire;
			}
		}
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_SUM_COMMISSION);
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			commission = resultSet.getString("COMMISSION");
			if (commission == null) {
				return -sumSalaire;
			} else {
				sumSalaire = sumSalaire + Double.valueOf(resultSet.getString("COMMISSION"));
			}
		}
		return -sumSalaire;
	}

	/**
	 * sum salary, commission, sales and orders
	 * 
	 * @return
	 * @throws Exception
	 */
	public String totalSum() throws Exception {
		String total;
		double sum = 0;
		sum = sumSalaire() + sumVente() + sumCommande();
		total = String.valueOf(sum);
		return total;
	}
}
