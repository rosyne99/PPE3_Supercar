package supercar.utilities;
/* name : DB UTIL Stock.java
 * @authors FSociety Group
 date : 19/11/2020
program that : connect to database and do CREATE,READ,UPDATE,DELETE stock and show in an GUI INTERFACE
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import supercar.db.ConnectionFactory;
import supercar.constants.QueryStatement;
import supercar.model.Stock;

/**
 * Class DBUtilStock: connection to database to show data of supercar stock
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */

public class DBUtilStock {

	private static Connection connection;
	private static PreparedStatement preparedStatement;
	private static ResultSet resultSet = null;

	/**
	 * add a new car stock into the database
	 * 
	 * @param stock
	 * @throws SQLException
	 */

	public static void addStock(Stock stock) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.ADD_STOCK_QUERY);

		setPreparedStatementProperties(stock.getID_MODELE(), stock.getID_DEPT(), stock.getSTOCK(), stock.getSTATUT());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * update a selected car stock into the database
	 * 
	 * @param stock
	 * @throws SQLException
	 */

	public static void updateStock(Stock stock) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.UPDATE_STOCK_QUERY);

		setPreparedStatementProperties(stock.getID_MODELE(), stock.getID_DEPT(), stock.getSTOCK(), stock.getSTATUT(),
				stock.getID_STOCK());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * update a selected car stock into the database from active (1) into inactive
	 * (0)
	 * 
	 * @param stock
	 * @throws SQLException
	 */

	public static void deleteStock(Stock stock) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.DELETE_STOCK_QUERY);

		setPreparedStatementProperties(stock.getID_STOCK());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * close connection to the database
	 * 
	 * @throws SQLException
	 */
	private static void closeConnections() throws SQLException {
		if (resultSet != null) {
			resultSet.close();
		}
		if (preparedStatement != null) {
			preparedStatement.close();
		}
		if (connection != null) {
			connection.close();
		}
	}

	private static void setPreparedStatementProperties(String... strArgs) throws SQLException {
		for (int i = 0; i < strArgs.length; i++) {
			preparedStatement.setString(i + 1, strArgs[i]);
		}
	}

	/**
	 * method that will insert the mysql database data of active car stock into a
	 * Jtable
	 * 
	 * statut = 0 : 'en indisponible'
	 * 
	 * statut = 1 : 'en cours de livraison'
	 * 
	 * statut = 2 : 'disponible'
	 * 
	 * @param table
	 * @throws SQLException
	 */

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void graphicGetAllStock(JTable table) throws SQLException {
		int CC;
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_STOCK_QUERY);
		resultSet = preparedStatement.executeQuery();

		java.sql.ResultSetMetaData RSMD = resultSet.getMetaData();
		CC = RSMD.getColumnCount();
		DefaultTableModel DFT = (DefaultTableModel) table.getModel();
		DFT.setRowCount(0);

		while (resultSet.next()) {
			Vector v2 = new Vector();

			for (int ii = 1; ii <= CC; ii++) {
				v2.add(resultSet.getString("STOCK.ID_STOCK"));
				v2.add(resultSet.getString("MODELE.ID_MODELE") + " - " + resultSet.getString("VOITURE.MARQUE") + " "
						+ resultSet.getString("MODELE.NOM"));
				v2.add(resultSet.getString("DEPT.ID_DEPT") + " - " + resultSet.getString("DEPT.NOM"));
				v2.add(resultSet.getString("STOCK"));
				String STATUT_DB = resultSet.getString("STOCK.STATUT");
				String STATUT_TEXT = null;

				if (STATUT_DB.contains("0")) {
					STATUT_TEXT = "Indisponible";
					v2.add(STATUT_TEXT);
				} else if (STATUT_DB.contains("1")) {
					STATUT_TEXT = "En cours de livraison";
					v2.add(STATUT_TEXT);

				} else if (STATUT_DB.contains("2")) {
					STATUT_TEXT = "Disponible";
					v2.add(STATUT_TEXT);

				}
			}
			DFT.addRow(v2);
		}
	}

	/**
	 * sum price of all order
	 * 
	 * @param label
	 * @throws SQLException
	 */
	public void getTotalCommandes(JLabel label) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_TOTAL_COMMANDES_QUERY);
		resultSet = preparedStatement.executeQuery();

		while (resultSet.next()) {
			label.setText(resultSet.getString("TOTAL_PRIX"));
		}
	}

	/**
	 * method that will insert the mysql database data of order into a Jtable
	 * 
	 * @param table
	 * @throws SQLException
	 */

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void graphicGetAllCommandes(JTable table) throws SQLException {
		int CC;
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_COMMANDES_QUERY);
		resultSet = preparedStatement.executeQuery();

		java.sql.ResultSetMetaData RSMD = resultSet.getMetaData();
		CC = RSMD.getColumnCount();
		DefaultTableModel DFT = (DefaultTableModel) table.getModel();
		DFT.setRowCount(0);

		while (resultSet.next()) {
			Vector v2 = new Vector();

			for (int ii = 1; ii <= CC; ii++) {
				v2.add(resultSet.getString("STOCK.ID_STOCK"));
				v2.add(resultSet.getString("MODELE.ID_MODELE") + " - " + resultSet.getString("VOITURE.MARQUE") + " "
						+ resultSet.getString("MODELE.NOM"));
				v2.add(resultSet.getString("DEPT.ID_DEPT") + " - " + resultSet.getString("DEPT.NOM"));
				String stock = resultSet.getString("STOCK");
				String prix = resultSet.getString("MODELE.PRIX");
				double prixInt = Double.valueOf(prix);
				double stockInt = Double.valueOf(stock);
				double prixTotal = prixInt * stockInt;
				String prixString = String.valueOf(prixTotal);
				v2.add(stock);

				v2.add(String.valueOf(prixString));
			}
			DFT.addRow(v2);
		}
	}

	/**
	 * method that will fetch and insert the mysql database data of car stock ID
	 * into a JComboBox or fetch data from a specific row in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboId(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		preparedStatement = connection.prepareStatement(QueryStatement.DROPDOWN_STOCK_QUERY);
		resultSet = preparedStatement.executeQuery();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 0));
		}
		theModel.addElement("");
		while (resultSet.next()) {
			theModel.addElement(resultSet.getString("ID_STOCK"));
		}

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will insert all car stock status data into a JComboBox or fetch
	 * data from a specific row in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboStatut(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 4));
		}
		theModel.addElement("");
		theModel.addElement("Indisponible");
		theModel.addElement("En cours de livraison");
		theModel.addElement("Disponible");

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch and insert the mysql database data of car model ID,
	 * brand name, and model name into a JComboBox or fetch data from a specific row
	 * in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboModele(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_MODELE_QUERY);
		resultSet = preparedStatement.executeQuery();
		theModel.removeAllElements();

		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 1));
			theModel.addElement("");
			while (resultSet.next()) {
				theModel.addElement(resultSet.getString("MODELE.ID_MODELE") + " - "
						+ resultSet.getString("VOITURE.MARQUE") + " " + resultSet.getString("MODELE.NOM"));
			}
		} else {
			theModel.addElement("");
			while (resultSet.next()) {
				theModel.addElement(resultSet.getString("MODELE.ID_MODELE") + " - "
						+ resultSet.getString("VOITURE.MARQUE") + " " + resultSet.getString("MODELE.NOM"));
			}
		}

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch and insert the mysql database data of a warehouse ID
	 * and warehouse name into a JComboBox or fetch data from a specific row in the
	 * table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboEntrepot(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_ENTREPOT_QUERY);
		resultSet = preparedStatement.executeQuery();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 2));
		}
		theModel.addElement("");
		while (resultSet.next()) {
			theModel.addElement(resultSet.getString("ID_DEPT") + " - " + resultSet.getString("NOM"));
		}

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch car model stock number data from a specific row in the
	 * table and insert into a TextField
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @return
	 */

	public JTextField JTextFieldStock(JTextField jc, JTable table, int row) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		jc.setText((model.getValueAt(row, 3).toString()));
		return jc;
	}

}