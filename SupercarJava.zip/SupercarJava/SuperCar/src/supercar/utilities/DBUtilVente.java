package supercar.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import supercar.db.ConnectionFactory;
import supercar.constants.QueryStatement;
import supercar.model.Vente;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Class DBUTILVente: connection to database to add, update, delete or show data
 * of supercar sale
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
public class DBUtilVente {

	private static Connection connection;
	private static PreparedStatement preparedStatement;
	private static ResultSet resultSet = null;
	private String TotalVente;
	private String TotalEnCours;
	private String TotalNoVente;
	private String TotalNoEnCours;
	private String TotalDelivree;
	private String TotalNoDelivree;

	/**
	 * get Cuurent month date (aaaa-mm) into the database
	 * 
	 * @throws SQLException
	 */
	public String getMonth() throws SQLException {
		String month = null;
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.CURRENT_MONTH);
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			month = resultSet.getString("DATE");
		}
		return month;
	}

	/**
	 * get Cuurent year date (aaaa) into the database
	 * 
	 * @throws SQLException
	 */

	public String getYear() throws SQLException {
		String year = null;
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.CURRENT_YEAR);
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			year = resultSet.getString("DATE");
		}
		return year;
	}

	/**
	 * get Cuurent day date (aaaa-mm-dd) into the database
	 * 
	 * @throws SQLException
	 */

	public String getDay() throws SQLException {
		String day = null;
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.CURRENT_DAY);
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			day = resultSet.getString("DATE");
		}
		return day;
	}

	/**
	 * add a new sale into the database
	 * 
	 * @param vente
	 * @throws SQLException
	 */
	public static void addVente(Vente vente) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.ADD_VENTE_QUERY);

		setPreparedStatementProperties(vente.getPrix_Vente(), vente.getID_CLIENT(), vente.getID_EMPLOYE(),
				vente.getID_MODELE(), vente.getID_OPTIONS(), vente.getStatut(), vente.getCommission());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * update a selected sale into the database
	 * 
	 * @param vente
	 * @throws SQLException
	 */
	public static void updateVente(Vente vente) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.UPDATE_VENTE_QUERY);

		setPreparedStatementProperties(vente.getPrix_Vente(), vente.getID_CLIENT(), vente.getID_EMPLOYE(),
				vente.getID_MODELE(), vente.getID_OPTIONS(), vente.getStatut(), vente.getCommission(),
				vente.getID_VENTE());
		preparedStatement.executeUpdate();

		closeConnections();
	}

	/**
	 * reduce the supercar stock if a sale is confirmed
	 * 
	 * @param vente
	 * @throws SQLException
	 */
	public static void reduceStock(Vente vente) throws SQLException {
		connection = ConnectionFactory.getConnection();
		preparedStatement = connection.prepareStatement(QueryStatement.REDUCE_STOCK_QUERY);
		setPreparedStatementProperties(vente.getID_VENTE(), vente.getID_MODELE());
		preparedStatement.executeUpdate();
		closeConnections();
	}

	/**
	 * close connection to the database
	 * 
	 * @throws SQLException
	 */
	private static void closeConnections() throws SQLException {
		if (resultSet != null) {
			resultSet.close();
		}
		if (preparedStatement != null) {
			preparedStatement.close();
		}
		if (connection != null) {
			connection.close();
		}
	}

	private static void setPreparedStatementProperties(String... strArgs) throws SQLException {
		for (int i = 0; i < strArgs.length; i++) {
			preparedStatement.setString(i + 1, strArgs[i]);
		}
	}

	/**
	 * method for chooseing the appropriate resquest if type = day,week,month or all
	 * 
	 * @param type
	 * @throws SQLException
	 */
	public void chooseQuery(String type) throws SQLException {
		if (type == "ALL") {
			preparedStatement = connection.prepareStatement(QueryStatement.SELECT_VENTE_QUERY);
		}
		if (type == "DAY") {
			preparedStatement = connection.prepareStatement(QueryStatement.SELECT_VENTE_QUERY_DAY);
		}
		if (type == "WEEK") {
			preparedStatement = connection.prepareStatement(QueryStatement.SELECT_VENTE_QUERY_WEEK);
		}
		if (type == "MONTH") {
			preparedStatement = connection.prepareStatement(QueryStatement.SELECT_VENTE_QUERY_MONTH);
		}
	}

	/**
	 * method that show the sum of prices, number of sales if type = day,week,month
	 * or all
	 * 
	 * @param type
	 * @param statut
	 * @param priceornumber
	 * @return
	 * @throws SQLException
	 */
	public String chooseSales(String type, String statut, String priceornumber) throws SQLException {
		if (statut == "En cours") {
			statut = "1";
		}
		if (statut == "Vendu") {
			statut = "2";
		}

		if (statut == "Délivrée") {
			statut = "3";
		}

		String sql = "";
		String numorprice = "";
		if (type == "ALL") {
			sql = "SELECT SUM(PRIX_VENTE) AS PRIX,COUNT(*) AS NO FROM VENTE WHERE YEAR(DATE_VENTE) = YEAR(CURRENT_DATE()) AND STATUT = "
					+ statut + "";
		}
		if (type == "DAY") {
			sql = "SELECT SUM(PRIX_VENTE) AS PRIX,COUNT(*) AS NO FROM VENTE WHERE DATE(DATE_VENTE) = CURDATE() AND STATUT = "
					+ statut + "";
		}
		if (type == "WEEK") {
			sql = "SELECT SUM(PRIX_VENTE) AS PRIX,COUNT(*) AS NO FROM VENTE WHERE YEARWEEK(DATE_VENTE) = YEARWEEK(NOW()) AND STATUT = "
					+ statut + "";
		}
		if (type == "MONTH") {
			sql = "SELECT SUM(PRIX_VENTE) AS PRIX,COUNT(*) AS NO FROM VENTE WHERE MONTH(DATE_VENTE) = MONTH(CURRENT_DATE()) AND YEAR(DATE_VENTE) = YEAR(CURRENT_DATE()) AND STATUT = "
					+ statut + "";
		}

		preparedStatement = connection.prepareStatement(sql);
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			if (priceornumber == "price") {
				numorprice = resultSet.getString("PRIX");
			} else if (priceornumber == "NoofSales") {
				numorprice = resultSet.getString("NO");
			}
		}
		return numorprice;

	}

	/**
	 * method that will insert the mysql database data of active sales into a Jtable
	 * for the day, week, month or year
	 * 
	 * Statut = 1 : en cours
	 * 
	 * Statut = 2 : termine
	 * 
	 * @param table
	 * @throws SQLException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void graphicGetAllVente(JTable table, String type) throws SQLException {
		int CC;
		connection = ConnectionFactory.getConnection();
		chooseQuery(type);
		resultSet = preparedStatement.executeQuery();

		java.sql.ResultSetMetaData RSMD = resultSet.getMetaData();
		CC = RSMD.getColumnCount();
		DefaultTableModel DFT = (DefaultTableModel) table.getModel();
		DFT.setRowCount(0);

		while (resultSet.next()) {
			Vector v2 = new Vector();

			for (int ii = 1; ii <= CC; ii++) {
				v2.add(resultSet.getString("ID_VENTE"));
				v2.add(resultSet.getString("DATE_VENTE"));
				v2.add(resultSet.getString("PRIX_VENTE"));
				v2.add(resultSet.getString("CLIENT.ID_CLIENT") + " - " + resultSet.getString("CLIENT.PRENOM") + " "
						+ resultSet.getString("CLIENT.NOM"));
				v2.add(resultSet.getString("EMPLOYE.PRENOM") + " " + resultSet.getString("EMPLOYE.NOM"));
				v2.add(resultSet.getString("MODELE.ID_MODELE") + " - " + resultSet.getString("VOITURE.MARQUE") + " "
						+ resultSet.getString("MODELE.NOM"));
				v2.add(resultSet.getString("OPTIONS.ID_OPTIONS") + " - " + resultSet.getString("OPTIONS.NOM_OPTIONS"));
				String STATUT_DB = resultSet.getString("STATUT");
				String STATUT_TEXT = null;

				if (STATUT_DB.contains("1")) {
					STATUT_TEXT = "En cours";
					v2.add(STATUT_TEXT);

				} else if (STATUT_DB.contains("2")) {
					STATUT_TEXT = "Vendu";
					v2.add(STATUT_TEXT);

				} else if (STATUT_DB.contains("3")) {
					STATUT_TEXT = "Délivrée";
					v2.add(STATUT_TEXT);

				}
			}
			DFT.addRow(v2);
		}
		this.TotalEnCours = chooseSales(type, "En cours", "price");
		this.TotalVente = chooseSales(type, "Vendu", "price");
		this.TotalNoEnCours = chooseSales(type, "En cours", "NoofSales");
		this.TotalNoVente = chooseSales(type, "Vendu", "NoofSales");
		this.TotalDelivree = chooseSales(type, "Délivrée", "price");
		this.TotalNoDelivree = chooseSales(type, "Délivrée", "NoofSales");
	}

	/**
	 * method for choosing a type in JcomboBox typeDropdown (tout,aujourd'hui,cette
	 * semaine, ce mois-ci)
	 * 
	 * @param jc
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboAffichage(JComboBox jc) {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		theModel.addElement("Tout");
		theModel.addElement("Aujourd'hui");
		theModel.addElement("Cette Semaine");
		theModel.addElement("Ce Mois-ci");
		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch and insert the mysql database data of client ID,
	 * client name and client surname into a JComboBox or fetch data from a specific
	 * row in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboClient(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_CLIENT_QUERY);
		resultSet = preparedStatement.executeQuery();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 3));
		}
		theModel.addElement("");
		while (resultSet.next()) {
			theModel.addElement(resultSet.getString("ID_CLIENT") + " - " + resultSet.getString("PRENOM") + " "
					+ resultSet.getString("NOM"));
		}

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch and insert the mysql database data of sales ID into a
	 * JComboBox or fetch data from a specific row in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboId(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		preparedStatement = connection.prepareStatement(QueryStatement.DROPDOWN_VENTE_QUERY);
		resultSet = preparedStatement.executeQuery();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 0));
		}
		theModel.addElement("");
		while (resultSet.next()) {
			theModel.addElement(resultSet.getString("ID_VENTE"));
		}

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch and insert the mysql database data of car model ID,
	 * car brand, car model and avalaibility into a JComboBox or fetch data from a
	 * specific row in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboModele(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_AVALAIBLE_MODELE_QUERY);
		resultSet = preparedStatement.executeQuery();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 5));
			theModel.addElement("");
			while (resultSet.next()) {
				int statut = Integer.valueOf(resultSet.getString("STOCK.STATUT"));
				if (statut == 2) {
					theModel.addElement(resultSet.getString("MODELE.ID_MODELE") + " - "
							+ resultSet.getString("VOITURE.MARQUE") + " " + resultSet.getString("MODELE.NOM") + " | "
							+ resultSet.getString("STOCK.STOCK") + " disponible(s)");
				} else if (statut == 1) {
					theModel.addElement(resultSet.getString("MODELE.ID_MODELE") + " - "
							+ resultSet.getString("VOITURE.MARQUE") + " " + resultSet.getString("MODELE.NOM") + " | "
							+ resultSet.getString("STOCK.STOCK") + " bientot disponible(s)");
				} else {
					theModel.addElement(
							resultSet.getString("MODELE.ID_MODELE") + " - " + resultSet.getString("VOITURE.MARQUE")
									+ " " + resultSet.getString("MODELE.NOM") + " |  indisponible");
				}

			}
		} else {
			theModel.addElement("");
			while (resultSet.next()) {
				int statut = Integer.valueOf(resultSet.getString("STOCK.STATUT"));
				if (statut == 2) {
					theModel.addElement(resultSet.getString("MODELE.ID_MODELE") + " - "
							+ resultSet.getString("VOITURE.MARQUE") + " " + resultSet.getString("MODELE.NOM") + " | "
							+ resultSet.getString("STOCK.STOCK") + " disponible(s)");
				} else if (statut == 1) {
					theModel.addElement(resultSet.getString("MODELE.ID_MODELE") + " - "
							+ resultSet.getString("VOITURE.MARQUE") + " " + resultSet.getString("MODELE.NOM") + " | "
							+ resultSet.getString("STOCK.STOCK") + " bientot disponible(s)");
				} else {
					theModel.addElement(
							resultSet.getString("MODELE.ID_MODELE") + " - " + resultSet.getString("VOITURE.MARQUE")
									+ " " + resultSet.getString("MODELE.NOM") + " |  indisponible");
				}
			}
		}

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will fetch and insert the mysql database data of options ID, and
	 * option name into a JComboBox or fetch data from a specific row in the table
	 * 
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboOptions(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		preparedStatement = connection.prepareStatement(QueryStatement.SELECT_OPTIONS_QUERY);
		resultSet = preparedStatement.executeQuery();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 6));
			theModel.addElement("");
			while (resultSet.next()) {
				theModel.addElement(
						resultSet.getString("OPTIONS.ID_OPTIONS") + " - " + resultSet.getString("OPTIONS.NOM_OPTIONS"));
			}
		} else {
			theModel.addElement("");
			while (resultSet.next()) {
				theModel.addElement(
						resultSet.getString("OPTIONS.ID_OPTIONS") + " - " + resultSet.getString("OPTIONS.NOM_OPTIONS"));
			}
		}

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * method that will insert all car stock status data into a JComboBox or fetch
	 * data from a specific row in the table
	 * 
	 * @param jc
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 * @throws SQLException
	 */

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JComboBox JcomboStatut(JComboBox jc, JTable table, int row, String type) throws SQLException {
		DefaultComboBoxModel theModel = (DefaultComboBoxModel) jc.getModel();
		theModel.removeAllElements();
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			jc.addItem(model.getValueAt(row, 7));
		}
		theModel.addElement("");
		theModel.addElement("En cours");
		theModel.addElement("Annulé");
		theModel.addElement("Vendu");
		theModel.addElement("Délivrée");

		jc.setModel(theModel);
		return jc;
	}

	/**
	 * get current status of a row
	 * 
	 * @param stat
	 * @param table
	 * @param row
	 * @param type
	 * @return
	 */
	public String getStatut(String stat, JTable table, int row, String type) {
		if (type == "update") {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			stat = model.getValueAt(row, 7).toString();
		}
		return stat;
	}

	/**
	 * method that will calculate the price of a car and options added with vat
	 * 
	 * 
	 * @param ID_MODELE
	 * @param ID_OPTIONS
	 * @return
	 * @throws SQLException
	 */
	public String GetPrixSelected(String ID_MODELE, String ID_OPTIONS) throws SQLException {
		String prixHtVoiture = "";
		String prixHtOptions = "";
		String prixTTC = "";
		float prixHtFloatOptions = 0;
		float prixHtFloatVoiture = 0;
		float prixFloatTotal = 0;
		String sqlVoiture = "SELECT * FROM MODELE WHERE ID_MODELE = " + ID_MODELE + "";
		String sqlOptions = "SELECT * FROM OPTIONS WHERE ID_OPTIONS = " + ID_OPTIONS + "";
		preparedStatement = connection.prepareStatement(sqlVoiture);
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			prixHtVoiture = resultSet.getString("PRIX");
			prixHtFloatVoiture = Float.parseFloat(prixHtVoiture);

		}
		preparedStatement = connection.prepareStatement(sqlOptions);
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			prixHtOptions = resultSet.getString("PRIX_OPTIONS_HT");
			prixHtFloatOptions = Float.parseFloat(prixHtOptions);

		}
		prixFloatTotal = (float) (1.15 * (prixHtFloatOptions) + (1.15 * (prixHtFloatVoiture)));
		prixTTC = String.valueOf(prixFloatTotal);
		return prixTTC;
	}

	/**
	 * generate an invoice pdf of a car sale using sales id for a client
	 * 
	 * @param id
	 * @throws Exception
	 */
	public void pdfInvoice(String id) throws Exception {
		Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/supercarjava", "root",
				"");

		PreparedStatement st = (PreparedStatement) connection.prepareStatement(
				"Select * from client,vente,modele,voiture,options where vente.ID_VENTE = ? AND client.ID_CLIENT = vente.ID_CLIENT AND modele.ID_MODELE = vente.ID_MODELE AND modele.ID_MARQUE = voiture.ID_MARQUE AND vente.ID_OPTIONS = options.ID_OPTIONS");
		st.setString(1, id);
		ResultSet rs = st.executeQuery();
		if (rs.next()) {

			String nom_client = rs.getString("client.PRENOM") + " " + rs.getString("client.NOM");
			String pdf_nom = rs.getString("client.PRENOM") + "_" + rs.getString("client.NOM") + "_"
					+ rs.getString("vente.ID_VENTE") + "-Invoice" + ".pdf";
			String adresse_client = rs.getString("client.ADRESSE");
			String mail_client = rs.getString("client.EMAIL");
			String tel_client = rs.getString("client.TEL");

			String voiture_vente = rs.getString("VOITURE.MARQUE") + " " + rs.getString("MODELE.NOM");
			String couleur_voiture = rs.getString("MODELE.COULEUR");
			String moteur_voiture = rs.getString("MODELE.MOTEUR");
			String bv_voiture = rs.getString("MODELE.BV");
			String prix_voiture = rs.getString("MODELE.PRIX");

			String nom_option_vente = rs.getString("OPTIONS.NOM_OPTIONS");
			String details_options_vente = rs.getString("OPTIONS.DETAIL_OPTIONS");
			String prix_options_vente = rs.getString("OPTIONS.PRIX_OPTIONS_HT");

			String date_vente = rs.getString("VENTE.DATE_VENTE");
			String prix_vente = rs.getString("VENTE.PRIX_VENTE");

			JFileChooser dialog = new JFileChooser();
			dialog.setSelectedFile(new File(pdf_nom));
			int dialogResult = dialog.showSaveDialog(null);
			if (dialogResult == JFileChooser.APPROVE_OPTION) {
				String filePath = dialog.getSelectedFile().getPath();

				try {
					Document invoice = new Document();
					PdfWriter myWriter = PdfWriter.getInstance(invoice, new FileOutputStream(filePath));
					invoice.open();
					//
					Paragraph smallSpace = new Paragraph(" ", FontFactory.getFont(FontFactory.TIMES_BOLD, 10));
					Paragraph title = new Paragraph("Invoice No. " + id,
							FontFactory.getFont(FontFactory.TIMES_BOLD, 25));
					Paragraph date = new Paragraph("Date : " + date_vente,
							FontFactory.getFont(FontFactory.TIMES_BOLD, 11));
					//
					title.setAlignment(Element.ALIGN_CENTER);
					date.setAlignment(Element.ALIGN_RIGHT);
					//
					Paragraph nomComp = new Paragraph("Corporate name : Supercar LTD",
							FontFactory.getFont(FontFactory.TIMES, 9));
					Paragraph addComp = new Paragraph("Corporate Address : Pailles, Motorway, M1, Port Louis",
							FontFactory.getFont(FontFactory.TIMES, 9));
					Paragraph mailComp = new Paragraph("Corporate Mail Address : contact@supercar.com",
							FontFactory.getFont(FontFactory.TIMES, 9));
					Paragraph telComp = new Paragraph("Corporate Phone Number : 601 2000",
							FontFactory.getFont(FontFactory.TIMES, 9));
					//
					Paragraph nomClient = new Paragraph("Client name : " + nom_client,
							FontFactory.getFont(FontFactory.TIMES, 9));
					Paragraph addClient = new Paragraph("Client Address : " + adresse_client,
							FontFactory.getFont(FontFactory.TIMES, 9));
					Paragraph mailClient = new Paragraph("Client Mail Address : " + mail_client,
							FontFactory.getFont(FontFactory.TIMES, 9));
					Paragraph telClient = new Paragraph("Client Phone Number : " + tel_client,
							FontFactory.getFont(FontFactory.TIMES, 9));
					//
					nomClient.setAlignment(Element.ALIGN_RIGHT);
					addClient.setAlignment(Element.ALIGN_RIGHT);
					mailClient.setAlignment(Element.ALIGN_RIGHT);
					telClient.setAlignment(Element.ALIGN_RIGHT);
					//
					Paragraph summary = new Paragraph("SUMMARY", FontFactory.getFont(FontFactory.TIMES_BOLDITALIC, 12));
					//
					summary.setAlignment(Element.ALIGN_CENTER);
					//
					Paragraph voiture_title = new Paragraph("-------------------- CAR --------------------",
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph voiture = new Paragraph("Car model : " + voiture_vente,
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph couleur = new Paragraph("Color : " + couleur_voiture,
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph moteur = new Paragraph("Motor : " + moteur_voiture,
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph bv = new Paragraph("GearBox : " + bv_voiture, FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph prix_voiture_ht = new Paragraph("Car Price (duty free) : " + prix_voiture + " MUR",
							FontFactory.getFont(FontFactory.TIMES, 11));
					//
					voiture_title.setAlignment(Element.ALIGN_CENTER);
					prix_voiture_ht.setAlignment(Element.ALIGN_RIGHT);
					//
					Paragraph option_title = new Paragraph("------------------ OPTIONS ------------------",
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph optionNom = new Paragraph("Option Name : " + nom_option_vente,
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph optionDetailName = new Paragraph("List of options : ",
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph optionDetail = new Paragraph(details_options_vente,
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph optionPrix = new Paragraph("Option Price (duty free) : " + prix_options_vente + " MUR",
							FontFactory.getFont(FontFactory.TIMES, 11));
					//
					option_title.setAlignment(Element.ALIGN_CENTER);
					optionPrix.setAlignment(Element.ALIGN_RIGHT);
					//
					Paragraph price_title = new Paragraph("------------------- TOTAL -------------------",
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph voiturePriceVat = new Paragraph(
							"Car Price (Duty Paid) : " + String.valueOf(1.15 * Double.valueOf(prix_voiture)) + " MUR",
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph voitureVat = new Paragraph(
							"Car VAT (15%) : " + String.valueOf(0.15 * Double.valueOf(prix_voiture)) + " MUR",
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph optionPriceVat = new Paragraph("Option Price (Duty Paid) : "
							+ String.valueOf(1.15 * Double.valueOf(prix_options_vente)) + " MUR",
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph optionVat = new Paragraph(
							"Option VAT (15%) : " + String.valueOf(0.15 * Double.valueOf(prix_options_vente)) + " MUR",
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph priceTotal = new Paragraph("Total Price (duty paid) : " + prix_vente + " MUR",
							FontFactory.getFont(FontFactory.TIMES, 11));
					Paragraph taxTotal = new Paragraph(
							"Total VAT (15%) : " + String.valueOf(0.15 * Double.valueOf(prix_vente)) + " MUR",
							FontFactory.getFont(FontFactory.TIMES, 11));
					//
					price_title.setAlignment(Element.ALIGN_CENTER);
					voiturePriceVat.setAlignment(Element.ALIGN_RIGHT);
					voitureVat.setAlignment(Element.ALIGN_RIGHT);
					optionPriceVat.setAlignment(Element.ALIGN_RIGHT);
					optionVat.setAlignment(Element.ALIGN_RIGHT);
					priceTotal.setAlignment(Element.ALIGN_RIGHT);
					taxTotal.setAlignment(Element.ALIGN_RIGHT);
					//
					invoice.add(title);
					invoice.add(smallSpace);
					invoice.add(date);
					invoice.add(smallSpace);
					invoice.add(nomComp);
					invoice.add(addComp);
					invoice.add(mailComp);
					invoice.add(telComp);
					invoice.add(nomClient);
					invoice.add(addClient);
					invoice.add(mailClient);
					invoice.add(telClient);
					invoice.add(smallSpace);
					invoice.add(summary);
					invoice.add(smallSpace);
					invoice.add(voiture_title);
					invoice.add(voiture);
					invoice.add(couleur);
					invoice.add(moteur);
					invoice.add(bv);
					invoice.add(prix_voiture_ht);
					invoice.add(smallSpace);
					invoice.add(option_title);
					invoice.add(optionNom);
					invoice.add(optionDetailName);
					invoice.add(optionDetail);
					invoice.add(optionPrix);
					invoice.add(price_title);
					invoice.add(voiturePriceVat);
					invoice.add(voitureVat);
					invoice.add(optionPriceVat);
					invoice.add(optionVat);
					invoice.add(smallSpace);
					invoice.add(priceTotal);
					invoice.add(taxTotal);
					invoice.close();
					myWriter.close();
					JOptionPane.showMessageDialog(null, "devis généré pour " + nom_client);
				} catch (Exception e) {
					e.printStackTrace();
					JOptionPane.showMessageDialog(null, "impossible de génerer un devis...");
				}
			}
		}
	}

	/**
	 * get sum of confirmed sales price
	 * 
	 * @return
	 */

	public String getTotalVente() {
		return this.TotalVente;
	}

	/**
	 * get sum of in progress sales price
	 * 
	 * @return
	 */
	public String getTotalEnCours() {
		return this.TotalEnCours;
	}

	/**
	 * get sum of number of confirmed sales
	 * 
	 * @return
	 */
	public String getNoTotalVente() {
		return this.TotalNoVente;
	}

	/**
	 * get sum of number of in progress sales
	 * 
	 * @return
	 */
	public String getNoTotalEnCours() {
		return this.TotalNoEnCours;
	}

	/**
	 * get sum of in delivered sales price
	 * 
	 * @return
	 */
	public String getTotalDelivre() {
		return this.TotalDelivree;
	}

	/**
	 * get sum of number of in delivered sales
	 * 
	 * @return
	 */
	public String getNoTotalDelivre() {
		return this.TotalNoDelivree;
	}

}