package supercar.vente;

import java.awt.EventQueue;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.EmptyStackException;
import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JTable;
import supercar.constants.CRUDMode;
import supercar.model.Vente;
import supercar.login.*;
import supercar.utilities.DBUtilVente;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * class MarqueGUI : GUI for 'Marque' && 'Fournisseurs'
 * 
 * @SuppressWarnings("rawtypes") added for JcomboBoxs warning
 * 
 * @version 15.1
 * @since Feb 22,2021
 * @author gregb
 *
 */
@SuppressWarnings("rawtypes")
public class VenteGUI {

	private JFrame frame;
	private JTable table;
	private JLabel lblPrixEnCours;
	private JLabel lblPrixTotal;
	private JLabel lblClient;
	private JLabel lblModele;
	private JLabel lblId;
	private JLabel lblStatut;
	private JLabel lblNouvelVente;
	private JLabel lblVente;
	private Timer timer;
	private JPanel panel;
	private JScrollPane scrollPane;
	private JButton btnModifier;
	private JComboBox clientDropdown;
	private JComboBox modeleDropdown;
	private JComboBox statutDropdown;
	private JComboBox idDropdown;
	private JComboBox tableDropdown;
	private static String idString;
	private static String idClientString;
	private static String idEmployeString;
	private static String idModeleString;
	private static String idOptionsString;
	private static String statutString;
	private static String prixString;
	private static String commissionString;
	private String ID_EMPLOYE;
	private JLabel lblNoEncours;
	private JLabel lblNoVendu;
	private String Id;
	private String Modele;
	private String Client;
	private String Options;
	private String Statut;
	private JButton btnAjouter;
	private JComboBox optionDropdown;
	private JLabel lblOptions;
	private JButton btnRetour;
	private DBUtilVente affichage = new DBUtilVente();
	private AdminAccount account = new AdminAccount();
	private JFrame errorFrame;
	private JFrame retourFrame;
	private String[] modeleArray;
	private String[] optionsArray;
	private String[] clientArray;
	private JButton btnAnnuler;
	private JButton btnPdf;
	private JButton btnImprimer;
	private MessageFormat header;
	private MessageFormat footer;
	private JLabel lblNombreTotalDelivree;
	private JLabel lblNoPrixDelivree;
	private String statUpdate;

	/**
	 * Launch the application.
	 * 
	 * @param login : login of the Authentified User.
	 * 
	 */
	public static void main(String login) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VenteGUI window = new VenteGUI(login);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Method that put all the information into the variables of the model.Vente
	 * Class for insertion or update in the Database
	 * 
	 * @param mode
	 * @return marque : Model object of class Vente
	 */
	private static Vente retrieveInputGUI(CRUDMode mode) {
		Vente vente = new Vente();
		if (mode.equals(CRUDMode.ADD) || mode.equals(CRUDMode.UPDATE)) {
			if (mode.equals(CRUDMode.UPDATE)) {
				vente.setID_VENTE(idString);
			}
			if (prixString != "") {
				vente.setPrix_Vente(prixString);
			}

			if (idClientString != "") {
				vente.setID_CLIENT(idClientString);
			}

			if (idEmployeString != "") {
				vente.setID_EMPLOYE(idEmployeString);
			}

			if (idModeleString != "") {
				vente.setID_MODELE(idModeleString);
			}
			if (idOptionsString != "") {
				vente.setID_OPTIONS(idOptionsString);
			}
			if (statutString != "") {
				vente.setStatut(statutString);
			}

			if (commissionString != "") {
				vente.setCommission(commissionString);
			}
		} else if (mode.equals(CRUDMode.REDUCE)) {
			vente.setID_VENTE(idString);
			vente.setID_MODELE(idModeleString);
		}

		return vente;

	}

	/**
	 * Import vente database data in the table model using DBUtilVente's method
	 * 'graphicGetAllVente'
	 * 
	 * Import sum price of 'en cours' status 'vente' in 'lblPrixEnCours'
	 * 
	 * Import sum price of 'termine' status 'vente' in 'lblPrixTotal'
	 * 
	 * Import sum number of 'en cours' status 'vente' in 'lblNoEnCours'
	 * 
	 * Import sum number of 'termine' status 'vente' in 'lblNoTotal'
	 * 
	 * Table composed of ("ID", "Date", "Prix (TTC)", "Nom du client", "Nom de
	 * l'employe", "Modele", "Option", "Statut" )
	 * 
	 * @param table
	 * @param type  : day,week,month,year
	 * 
	 * @throws SQLException
	 */
	public void setTableAffichage(JTable table, String type) throws SQLException {
		affichage.graphicGetAllVente(table, type);
		lblPrixEnCours.setText("");
		lblPrixTotal.setText("");
		lblPrixEnCours.setText("| Total Vente En Cours : " + String.valueOf(affichage.getTotalEnCours()) + " €");
		lblPrixTotal.setText("| Total Vente Terminé : " + String.valueOf(affichage.getTotalVente()) + " €");
		lblNoEncours.setText("Nombre Total En cours : " + String.valueOf(affichage.getNoTotalEnCours()));
		lblNoVendu.setText(String.valueOf("Nombre Total Vendu : " + affichage.getNoTotalVente()));
		lblNombreTotalDelivree.setText(String.valueOf("Nombre Total Livraison : " + affichage.getNoTotalDelivre()));
		lblNoPrixDelivree.setText("| Total Livraison Terminé : " + String.valueOf(affichage.getTotalDelivre()) + " €");

		if (lblPrixEnCours.getText().toString().contains("null")) {
			lblPrixEnCours.setText("| Total Vente En Cours : 0 €");
		}
		if (lblPrixTotal.getText().toString().contains("null")) {
			lblPrixTotal.setText("| Total Vente Terminé : 0 €");
		}
		if (lblNoPrixDelivree.getText().toString().contains("null")) {
			lblNoPrixDelivree.setText("| Total Livraison Terminé : 0 €");
		}
	}

	/**
	 * Choose to print the right table using setTableAffichage method and
	 * tableDropdown for a type (all,day,week,month)
	 * 
	 * @param type : day,month,year
	 */
	public void printTableAffichage(String type) {

		if (type.equals("Tout")) {
			try {
				setTableAffichage(table, "ALL");
			} catch (SQLException e1) {
				errorFrame = new JFrame("error");
				JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE D'AFFICHER LA LISTE 'ANNÉE' !!");
			}
		}

		if (type.equals("Aujourd'hui")) {
			try {
				setTableAffichage(table, "DAY");
			} catch (SQLException e1) {
				errorFrame = new JFrame("error");
				JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE D'AFFICHER LA LISTE 'JOUR' !!");
			}
		}

		if (type.equals("Cette Semaine")) {
			try {
				setTableAffichage(table, "WEEK");
			} catch (SQLException e1) {
				errorFrame = new JFrame("error");
				JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE D'AFFICHER LA LISTE 'SEMAINE' !!");
			}
		}

		if (type.equals("Ce Mois-ci")) {
			try {
				setTableAffichage(table, "MONTH");
			} catch (SQLException e1) {
				errorFrame = new JFrame("error");
				JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE D'AFFICHER LA LISTE 'MOIS' !!");
			}
		}
	}

	/**
	 * Create the application.
	 * 
	 * @param login : login of the Authentified User.
	 * 
	 * @throws ParseException
	 * @throws SQLException
	 */
	public VenteGUI(String login) throws ParseException, SQLException {
		initialize(login);
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * 'account.DatabaseConnexion' that will help for the authenticated to see all
	 * of his informations / disconnnect if the user is not in the database, use his
	 * id for insert a new 'vente'
	 * 
	 * Table (table) with auto-refresh features (the table will auto-refresh with
	 * the database every 10 seconds (10000ms) ) and row selectable for updating an
	 * existing vente.
	 *
	 * Button (btnModifier) 'Modifier' that will update a selected 'vente' to the
	 * database using the ID (if the user works in vente) if the verification
	 * doesn't give any error
	 * 
	 * Button (btnAjouter) 'Ajouter' that will add a new 'vente' to the database (if
	 * the user works in vente) if the verification doesn't give any error
	 * 
	 * * Dropdown (tableDropdown) 'all' by default that will let the user choose the
	 * differant type (year,day,week,month)
	 * 
	 * Dropdown (idDropdown) 'id' that shows all the existing id or choosen id in
	 * database
	 * 
	 * Dropdown (ClientDropdown) 'client' that shows all the existing client or
	 * choosen client in database with the selected id
	 * 
	 * Dropdown (modeleDropdown) 'modele' that shows all the existing modele or
	 * choosen model in database with the selected id
	 * 
	 * Dropdown (statutDropdown) 'id' that shows all the status or choosen status in
	 * database with the selected id
	 * 
	 * Dropdown (optionDropdown) 'id' that shows all the option or choosen option in
	 * database with the selected id
	 * 
	 * 
	 * Button (btnPDF) 'Generer PDF' that will generate an invoice of a selected
	 * 'vente'
	 * 
	 * Button (btnImprimer) 'Generer PDF' that will generate an PDF of 'vente'
	 * report (if the account type is manager or the account dept is 'finance'
	 *
	 * Button (btnAnnuler) 'Annuler' that will clear every inputs.
	 *
	 * Button (btnRetour) 'Retour' that will make the user return into the
	 * 'Dashboard' Page.
	 * 
	 * @SuppressWarnings("rawtypes") added for JcomboBoxs warning.
	 * 
	 * @param login : login of the Authentified User.
	 * 
	 * @throws ParseException.
	 * @throws SQLException.
	 */

	@SuppressWarnings("unchecked")
	private void initialize(String login) throws ParseException, SQLException {

		account.DatabaseConnexion(login, null, null, frame);
		ID_EMPLOYE = account.getId();
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 1366, 768);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setBounds(459, 142, 878, 438);
		frame.getContentPane().add(scrollPane);
		table = new JTable();
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				int row = table.rowAtPoint(e.getPoint());
				try {
					affichage.JcomboId(idDropdown, table, row, "update");
					affichage.JcomboClient(clientDropdown, table, row, "update");
					affichage.JcomboModele(modeleDropdown, table, row, "update");
					affichage.JcomboStatut(statutDropdown, table, row, "update");
					affichage.JcomboOptions(optionDropdown, table, row, "update");
					statUpdate = affichage.getStatut(statUpdate, table, row, "update");
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER LA LIGNE !!");
				}
			}
		});
		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "ID", "Date", "Prix (TTC)",
				"Nom du client", "Nom de l'employe", "Modele", "Option", "Statut" }));
		table.getColumnModel().getColumn(0).setPreferredWidth(60);
		table.getColumnModel().getColumn(1).setPreferredWidth(120);
		table.getColumnModel().getColumn(2).setPreferredWidth(80);
		table.getColumnModel().getColumn(3).setPreferredWidth(200);
		table.getColumnModel().getColumn(4).setPreferredWidth(200);
		table.getColumnModel().getColumn(5).setPreferredWidth(130);
		table.getColumnModel().getColumn(6).setPreferredWidth(110);
		table.getColumnModel().getColumn(7).setPreferredWidth(60);
		table.setEnabled(false);
		table.setCellSelectionEnabled(true);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		scrollPane.setViewportView(table);
		lblPrixTotal = new JLabel("");
		lblPrixTotal.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPrixTotal.setBounds(906, 625, 382, 25);
		frame.getContentPane().add(lblPrixTotal);

		lblPrixEnCours = new JLabel("");
		lblPrixEnCours.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPrixEnCours.setBounds(906, 595, 392, 27);
		frame.getContentPane().add(lblPrixEnCours);

		tableDropdown = new JComboBox();
		affichage.JcomboAffichage(tableDropdown);

		timer = new Timer(0, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				printTableAffichage(tableDropdown.getSelectedItem().toString());
			}
		});

		timer.setDelay(10000);
		timer.start();

		tableDropdown.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				printTableAffichage(tableDropdown.getSelectedItem().toString());
			}
		});
		tableDropdown.setBounds(1160, 113, 177, 21);
		frame.getContentPane().add(tableDropdown);

		panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(12, 142, 435, 478);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		lblId = new JLabel("Id");
		lblId.setFont(new Font("Dialog", Font.BOLD, 15));
		lblId.setBounds(12, 116, 55, 21);
		panel.add(lblId);

		idDropdown = new JComboBox();
		idDropdown.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboId(idDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UN ID !!");
				}
			}
		});

		idDropdown.setBounds(85, 116, 338, 25);
		panel.add(idDropdown);

		lblClient = new JLabel("Client");
		lblClient.setFont(new Font("Dialog", Font.BOLD, 15));
		lblClient.setBounds(12, 166, 55, 21);
		panel.add(lblClient);

		clientDropdown = new JComboBox();
		clientDropdown.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboClient(clientDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UN CLIENT !!");
				}
			}
		});
		clientDropdown.setBounds(85, 166, 338, 25);
		panel.add(clientDropdown);

		lblModele = new JLabel("Modele");
		lblModele.setFont(new Font("Dialog", Font.BOLD, 15));
		lblModele.setBounds(12, 216, 55, 21);
		panel.add(lblModele);

		modeleDropdown = new JComboBox();
		modeleDropdown.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboModele(modeleDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UN MODELE !!");
				}
			}
		});

		modeleDropdown.setBounds(85, 216, 338, 25);
		panel.add(modeleDropdown);

		statutDropdown = new JComboBox();
		statutDropdown.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboStatut(statutDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UN STATUT !!");
				}
			}
		});
		statutDropdown.setBounds(85, 316, 338, 25);
		panel.add(statutDropdown);
		statutDropdown.addItem("");

		lblStatut = new JLabel("Statut");
		lblStatut.setFont(new Font("Dialog", Font.BOLD, 15));
		lblStatut.setBounds(12, 316, 55, 16);
		panel.add(lblStatut);

		optionDropdown = new JComboBox();
		optionDropdown.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					affichage.JcomboOptions(optionDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE SELECTIONNER UNE OPTION !!");
				}
			}
		});
		optionDropdown.setBounds(85, 266, 338, 25);
		panel.add(optionDropdown);

		lblOptions = new JLabel("Options");
		lblOptions.setFont(new Font("Dialog", Font.BOLD, 15));
		lblOptions.setBounds(12, 266, 66, 16);
		panel.add(lblOptions);

		btnModifier = new JButton("Modifier");
		btnModifier.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				try {
					Id = idDropdown.getSelectedItem().toString();
					Modele = modeleDropdown.getSelectedItem().toString();
					Client = clientDropdown.getSelectedItem().toString();
					Statut = statutDropdown.getSelectedItem().toString();
					Options = optionDropdown.getSelectedItem().toString();
					idEmployeString = ID_EMPLOYE;
					idString = Id;
					if (Id == "" || Modele == "" || Statut == "" || Options == "" || Modele.contains("indisponible")) {
						throw new EmptyStackException();
					}
					modeleArray = Modele.split("-");
					idModeleString = modeleArray[0];
					optionsArray = Options.split("-");
					idOptionsString = optionsArray[0];
					prixString = affichage.GetPrixSelected(idModeleString, idOptionsString);
					clientArray = Client.split("-");
					idClientString = clientArray[0];
					if (Statut.contains("Annulé")) {
						statutString = "0";
						commissionString = "0";
					} else if (Statut.contains("En cours")) {
						statutString = "1";
						commissionString = "0";
					} else if (Statut.contains("Vendu")) {
						statutString = "2";
						commissionString = "3500";
					} else if (Statut.contains("Délivrée")) {
						statutString = "3";
						commissionString = "3500";
					}
					if (account.getAccountType().contains("2") && account.dept.contains("VENTE") && statutString != "3"
							|| account.getAccountType().contains("1") && statutString != "0"
									&& account.dept.contains("VENTE") && statutString != "3") {

						DBUtilVente.updateVente(retrieveInputGUI(CRUDMode.UPDATE));
						retourFrame = new JFrame("retour");
						setTableAffichage(table, "ALL");
						JOptionPane.showMessageDialog(retourFrame, "Vente modifié");
					}

					else if (account.getAccountType().contains("2") && account.dept.contains("STOCK")
							&& statutString == "3" && statUpdate.contains("Vendu")) {
						DBUtilVente.updateVente(retrieveInputGUI(CRUDMode.UPDATE));
						DBUtilVente.reduceStock(retrieveInputGUI(CRUDMode.REDUCE));
						retourFrame = new JFrame("retour");
						setTableAffichage(table, "ALL");
						JOptionPane.showMessageDialog(retourFrame, "Voiture livrée");
					} else {
						errorFrame = new JFrame("error");
						JOptionPane.showMessageDialog(errorFrame,
								"ERREUR, vous n'avez pas les privileges de confirmer livraison d'un véhicule!! / voiture non vendu !!!");
					}

				} catch (Exception E) {
					System.out.print(E);
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame,
							"ERREUR IMPOSSIBLE DE MODIFIER LA VENTE (champ vides, modele indisponible)");
				}
			}
		});
		btnModifier.setBounds(309, 400, 114, 26);
		panel.add(btnModifier);

		lblNouvelVente = new JLabel("Nouvelle/modification Vente");
		lblNouvelVente.setFont(new Font("Dialog", Font.ITALIC, 15));
		lblNouvelVente.setHorizontalAlignment(SwingConstants.CENTER);
		lblNouvelVente.setBounds(31, 12, 392, 51);
		panel.add(lblNouvelVente);

		btnAnnuler = new JButton("Annuler");
		btnAnnuler.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				try {
					affichage.JcomboId(idDropdown, table, 0, null);
					affichage.JcomboClient(clientDropdown, table, 0, null);
					affichage.JcomboModele(modeleDropdown, table, 0, null);
					affichage.JcomboStatut(statutDropdown, table, 0, null);
					affichage.JcomboOptions(optionDropdown, table, 0, null);
				} catch (SQLException e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE REINITIALISER LES CHAMPS");
				}
			}
		});
		btnAnnuler.setBounds(12, 400, 114, 26);
		panel.add(btnAnnuler);

		btnAjouter = new JButton("Ajouter");
		btnAjouter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Modele = modeleDropdown.getSelectedItem().toString();
					Client = clientDropdown.getSelectedItem().toString();
					Options = optionDropdown.getSelectedItem().toString();
					idEmployeString = ID_EMPLOYE;
					if (Modele == "" || Statut == "" || Options == "" || Modele.contains("indisponible")) {
						throw new EmptyStackException();
					}
					modeleArray = Modele.split("-");
					idModeleString = modeleArray[0];
					optionsArray = Options.split("-");
					idOptionsString = optionsArray[0];
					prixString = affichage.GetPrixSelected(idModeleString, idOptionsString);
					clientArray = Client.split("-");
					idClientString = clientArray[0];
					statutString = "1";
					commissionString = "0";
					// System.out.println(idClientString+" "+idModeleString+" "+idOptionsString+"
					// "+statutString);
					if (account.dept.contains("VENTE")) {
						DBUtilVente.addVente(retrieveInputGUI(CRUDMode.ADD));
						retourFrame = new JFrame("retour");
						setTableAffichage(table, "ALL");
						JOptionPane.showMessageDialog(retourFrame, "Vente ajouté");
					} else {
						errorFrame = new JFrame("error");
						JOptionPane.showMessageDialog(errorFrame,
								"ERREUR, vous n'avez pas les privileges d'ajouter une vente !!");
					}
				} catch (Exception E) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame,
							"ERREUR IMPOSSIBLE D'AJOUTER LA VENTE (champ vides ou modele indisponible)");
				}

			}
		});
		btnAjouter.setBounds(158, 400, 114, 26);
		panel.add(btnAjouter);

		btnPdf = new JButton("Génerer PDF");
		btnPdf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (account.dept != "VENTE") {
					throw new EmptyStackException();
				}
				Id = idDropdown.getSelectedItem().toString();
				try {
					affichage.pdfInvoice(Id);
				} catch (Exception e1) {
					errorFrame = new JFrame("error");
					JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPOSSIBLE DE GENERER UN DEVIS");

				}
			}
		});
		btnPdf.setBounds(158, 440, 114, 26);
		panel.add(btnPdf);

		lblVente = new JLabel("VENTE");
		lblVente.setFont(new Font("Dialog", Font.BOLD, 25));
		lblVente.setHorizontalAlignment(SwingConstants.CENTER);
		lblVente.setBounds(559, 67, 154, 48);
		frame.getContentPane().add(lblVente);

		lblNoEncours = new JLabel("");
		lblNoEncours.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNoEncours.setBounds(480, 595, 421, 27);
		frame.getContentPane().add(lblNoEncours);

		lblNoVendu = new JLabel("");
		lblNoVendu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNoVendu.setBounds(480, 625, 421, 27);
		frame.getContentPane().add(lblNoVendu);

		btnRetour = new JButton("retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				Dashboard.main(login);
			}
		});
		btnRetour.setBounds(1238, 702, 99, 26);
		frame.getContentPane().add(btnRetour);

		lblNombreTotalDelivree = new JLabel("");
		lblNombreTotalDelivree.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNombreTotalDelivree.setBounds(480, 655, 414, 25);
		frame.getContentPane().add(lblNombreTotalDelivree);

		lblNoPrixDelivree = new JLabel("");
		lblNoPrixDelivree.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNoPrixDelivree.setBounds(906, 655, 382, 25);
		frame.getContentPane().add(lblNoPrixDelivree);

		if (account.getAccountType().contains("2") && account.dept.contains("VENTE")
				|| account.dept.contains("FINANCE")) {
			btnImprimer = new JButton("Imprimer/PDF");
			btnImprimer.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						header = null;
						if (tableDropdown.getSelectedItem().toString().equals("Tout")) {
							header = new MessageFormat("Rapport financier annuel - " + affichage.getYear());
						}
						if (tableDropdown.getSelectedItem().toString().equals("Aujourd'hui")) {
							header = new MessageFormat("Rapport financier quotidien - " + affichage.getDay());
						}
						if (tableDropdown.getSelectedItem().toString().equals("Ce mois-ci")) {
							header = new MessageFormat("Rapport financier mensuel - " + affichage.getMonth());
						}
						if (tableDropdown.getSelectedItem().toString().equals("Ce mois-ci")) {
							header = new MessageFormat("Rapport financier de la semaine du - " + affichage.getDay());
						}

						footer = new MessageFormat("Page{0,number,integer}");
						try {
							table.print(JTable.PrintMode.NORMAL, header, footer);
						} catch (Exception E) {
							errorFrame = new JFrame("error");
							JOptionPane.showMessageDialog(errorFrame, "ERREUR IMPRESSION IMPOSSIBLE...");
						}
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			});
			btnImprimer.setBounds(1093, 702, 111, 26);
			frame.getContentPane().add(btnImprimer);
		}
	}
}
